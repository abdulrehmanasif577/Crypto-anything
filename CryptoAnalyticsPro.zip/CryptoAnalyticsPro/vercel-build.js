// This script runs during Vercel build

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

console.log('Running Vercel build preparation...');

// Ensure directories exist
const ensureDir = (dir) => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
    console.log(`Created directory: ${dir}`);
  }
};

ensureDir('./api');
ensureDir('./dist');

// Check if index.html exists at root level
if (!fs.existsSync('./index.html')) {
  console.log('Copying index.html to root...');
  if (fs.existsSync('./client/index.html')) {
    fs.copyFileSync('./client/index.html', './index.html');
  }
}

// Run the normal build process
console.log('Building application...');
try {
  execSync('npm run build', { stdio: 'inherit' });
  console.log('Build completed successfully!');
} catch (error) {
  console.error('Build failed:', error);
  process.exit(1);
}