import { coins, type Coin, type InsertCoin, tradingPairs, type TradingPair, type InsertTradingPair, newsArticles, type NewsArticle, type InsertNewsArticle, marketStats, type MarketStats, type InsertMarketStats, userFavorites, type UserFavorite, type InsertUserFavorite } from "@shared/schema";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  // User operations
  getUser(id: number): Promise<any | undefined>;
  getUserByUsername(username: string): Promise<any | undefined>;
  createUser(user: any): Promise<any>;
  
  // Coin operations
  getAllCoins(): Promise<Coin[]>;
  getTopCoins(limit: number): Promise<Coin[]>;
  getCoinById(coinId: string): Promise<Coin | undefined>;
  upsertCoin(coin: InsertCoin): Promise<Coin>;
  
  // Trading pair operations
  getAllTradingPairs(): Promise<TradingPair[]>;
  getPopularTradingPairs(): Promise<TradingPair[]>;
  addTradingPair(tradingPair: InsertTradingPair): Promise<TradingPair>;
  
  // News operations
  getLatestNews(limit: number): Promise<NewsArticle[]>;
  addNewsArticle(article: InsertNewsArticle): Promise<NewsArticle>;
  
  // Market stats operations
  getLatestMarketStats(): Promise<MarketStats | undefined>;
  updateMarketStats(stats: InsertMarketStats): Promise<MarketStats>;
  
  // User favorites operations
  getFavoritesByIp(ipAddress: string): Promise<UserFavorite[]>;
  addFavorite(favorite: InsertUserFavorite): Promise<UserFavorite>;
  removeFavorite(id: number): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<number, any>;
  private coinsMap: Map<string, Coin>;
  private tradingPairsMap: Map<number, TradingPair>;
  private newsArticlesMap: Map<number, NewsArticle>;
  private marketStatsMap: Map<number, MarketStats>;
  private userFavoritesMap: Map<number, UserFavorite>;
  
  private currentUserId: number;
  private currentCoinId: number;
  private currentTradingPairId: number;
  private currentNewsArticleId: number;
  private currentMarketStatsId: number;
  private currentUserFavoriteId: number;

  constructor() {
    this.users = new Map();
    this.coinsMap = new Map();
    this.tradingPairsMap = new Map();
    this.newsArticlesMap = new Map();
    this.marketStatsMap = new Map();
    this.userFavoritesMap = new Map();
    
    this.currentUserId = 1;
    this.currentCoinId = 1;
    this.currentTradingPairId = 1;
    this.currentNewsArticleId = 1;
    this.currentMarketStatsId = 1;
    this.currentUserFavoriteId = 1;
    
    // Initialize with some sample data
    this.initializeData();
  }

  // Initialize with sample data
  private initializeData() {
    // Sample coins
    const sampleCoins: InsertCoin[] = [
      {
        coinId: "bitcoin",
        symbol: "btc",
        name: "Bitcoin",
        image: "https://assets.coingecko.com/coins/images/1/thumb/bitcoin.png",
        currentPrice: 54324.89,
        marketCap: 1050000000000,
        marketCapRank: 1,
        priceChange24h: 1280.45,
        priceChangePercentage24h: 2.4,
        priceChangePercentage7d: 11.2,
        sparklineData: Array(20).fill(0).map((_, i) => 50000 + Math.random() * 5000)
      },
      {
        coinId: "ethereum",
        symbol: "eth",
        name: "Ethereum",
        image: "https://assets.coingecko.com/coins/images/279/thumb/ethereum.png",
        currentPrice: 2856.41,
        marketCap: 342500000000,
        marketCapRank: 2,
        priceChange24h: 50.67,
        priceChangePercentage24h: 1.8,
        priceChangePercentage7d: 8.9,
        sparklineData: Array(20).fill(0).map((_, i) => 2800 + Math.random() * 200)
      },
      {
        coinId: "binancecoin",
        symbol: "bnb",
        name: "BNB",
        image: "https://assets.coingecko.com/coins/images/825/thumb/bnb-icon2_2x.png",
        currentPrice: 412.22,
        marketCap: 63400000000,
        marketCapRank: 3,
        priceChange24h: -2.47,
        priceChangePercentage24h: -0.6,
        priceChangePercentage7d: 3.2,
        sparklineData: Array(20).fill(0).map((_, i) => 410 + Math.random() * 15)
      },
      {
        coinId: "cardano",
        symbol: "ada",
        name: "Cardano",
        image: "https://assets.coingecko.com/coins/images/975/thumb/cardano.png",
        currentPrice: 0.594,
        marketCap: 20800000000,
        marketCapRank: 4,
        priceChange24h: 0.019,
        priceChangePercentage24h: 3.2,
        priceChangePercentage7d: -2.1,
        sparklineData: Array(20).fill(0).map((_, i) => 0.58 + Math.random() * 0.04)
      },
      {
        coinId: "tether",
        symbol: "usdt",
        name: "Tether",
        image: "https://assets.coingecko.com/coins/images/325/thumb/Tether.png",
        currentPrice: 1.001,
        marketCap: 83200000000,
        marketCapRank: 5,
        priceChange24h: 0.0001,
        priceChangePercentage24h: 0.01,
        priceChangePercentage7d: 0.01,
        sparklineData: Array(20).fill(0).map((_, i) => 1 + Math.random() * 0.001)
      },
      {
        coinId: "solana",
        symbol: "sol",
        name: "Solana",
        image: "https://assets.coingecko.com/coins/images/4128/thumb/solana.png",
        currentPrice: 172.35,
        marketCap: 74560000000,
        marketCapRank: 6,
        priceChange24h: 5.78,
        priceChangePercentage24h: 3.47,
        priceChangePercentage7d: 15.4,
        sparklineData: Array(20).fill(0).map((_, i) => 165 + Math.random() * 15)
      },
      {
        coinId: "xrp",
        symbol: "xrp",
        name: "XRP",
        image: "https://assets.coingecko.com/coins/images/44/thumb/xrp-symbol-white-128.png",
        currentPrice: 0.561,
        marketCap: 30540000000,
        marketCapRank: 7,
        priceChange24h: -0.02,
        priceChangePercentage24h: -3.45,
        priceChangePercentage7d: -2.3,
        sparklineData: Array(20).fill(0).map((_, i) => 0.55 + Math.random() * 0.03)
      },
      {
        coinId: "dogecoin",
        symbol: "doge",
        name: "Dogecoin",
        image: "https://assets.coingecko.com/coins/images/5/thumb/dogecoin.png",
        currentPrice: 0.124,
        marketCap: 17820000000,
        marketCapRank: 8,
        priceChange24h: 0.006,
        priceChangePercentage24h: 5.1,
        priceChangePercentage7d: 9.7,
        sparklineData: Array(20).fill(0).map((_, i) => 0.12 + Math.random() * 0.01)
      },
      {
        coinId: "polkadot",
        symbol: "dot",
        name: "Polkadot",
        image: "https://assets.coingecko.com/coins/images/12171/thumb/polkadot.png",
        currentPrice: 7.84,
        marketCap: 10380000000,
        marketCapRank: 9,
        priceChange24h: -0.12,
        priceChangePercentage24h: -1.51,
        priceChangePercentage7d: 2.4,
        sparklineData: Array(20).fill(0).map((_, i) => 7.75 + Math.random() * 0.25)
      },
      {
        coinId: "matic-network",
        symbol: "matic",
        name: "Polygon",
        image: "https://assets.coingecko.com/coins/images/4713/thumb/matic-token-icon.png",
        currentPrice: 0.89,
        marketCap: 8570000000,
        marketCapRank: 10,
        priceChange24h: 0.04,
        priceChangePercentage24h: 4.7,
        priceChangePercentage7d: 6.3,
        sparklineData: Array(20).fill(0).map((_, i) => 0.86 + Math.random() * 0.06)
      }
    ];

    sampleCoins.forEach(coin => this.upsertCoin(coin));

    // Sample trading pairs
    const sampleTradingPairs: InsertTradingPair[] = [
      { baseSymbol: 'BTC', quoteSymbol: 'USD', displayName: 'Bitcoin / US Dollar', isPopular: true },
      { baseSymbol: 'ETH', quoteSymbol: 'USD', displayName: 'Ethereum / US Dollar', isPopular: true },
      { baseSymbol: 'BNB', quoteSymbol: 'USD', displayName: 'BNB / US Dollar', isPopular: true },
      { baseSymbol: 'XRP', quoteSymbol: 'USD', displayName: 'XRP / US Dollar', isPopular: true },
      { baseSymbol: 'ADA', quoteSymbol: 'USD', displayName: 'Cardano / US Dollar', isPopular: false },
      { baseSymbol: 'SOL', quoteSymbol: 'USD', displayName: 'Solana / US Dollar', isPopular: false },
      { baseSymbol: 'DOT', quoteSymbol: 'USD', displayName: 'Polkadot / US Dollar', isPopular: false },
      { baseSymbol: 'DOGE', quoteSymbol: 'USD', displayName: 'Dogecoin / US Dollar', isPopular: false },
      { baseSymbol: 'ETH', quoteSymbol: 'BTC', displayName: 'Ethereum / Bitcoin', isPopular: true },
      { baseSymbol: 'BNB', quoteSymbol: 'BTC', displayName: 'BNB / Bitcoin', isPopular: false }
    ];

    sampleTradingPairs.forEach(pair => this.addTradingPair(pair));

    // Sample news articles
    const sampleNews: InsertNewsArticle[] = [
      {
        title: "SEC Approves Spot Bitcoin ETF Applications",
        summary: "The U.S. Securities and Exchange Commission has approved multiple spot Bitcoin ETF applications, marking a significant milestone for cryptocurrency adoption.",
        url: "https://example.com/news/1",
        imageUrl: "https://images.unsplash.com/photo-1605792657660-596af9009e82",
        source: "CryptoNews",
        category: "Bitcoin",
        publishedAt: new Date(Date.now() - 10800000) // 3 hours ago
      },
      {
        title: "Ethereum Layer 2 Solutions See Record Growth",
        summary: "Ethereum scaling solutions like Arbitrum and Optimism have seen unprecedented growth in both transaction volume and user adoption in recent months.",
        url: "https://example.com/news/2",
        imageUrl: "https://images.unsplash.com/photo-1622630998477-20aa696ecb05",
        source: "DeFi Pulse",
        category: "Ethereum",
        publishedAt: new Date(Date.now() - 28800000) // 8 hours ago
      },
      {
        title: "New Crypto Regulatory Framework Proposed in EU",
        summary: "The European Union has proposed a comprehensive regulatory framework for cryptocurrencies, aiming to provide clarity for businesses and protect investors.",
        url: "https://example.com/news/3",
        imageUrl: "https://images.unsplash.com/photo-1639762681057-408e52192e55",
        source: "EU Regulatory Watch",
        category: "Regulation",
        publishedAt: new Date(Date.now() - 86400000) // 1 day ago
      },
      {
        title: "Bitcoin Mining Hash Rate Reaches All-Time High",
        summary: "The Bitcoin network hash rate has reached an all-time high, suggesting increased network security and miner confidence despite market volatility.",
        url: "https://example.com/news/4",
        imageUrl: "https://images.unsplash.com/photo-1516245834210-c4c142787335",
        source: "Mining Weekly",
        category: "Bitcoin",
        publishedAt: new Date(Date.now() - 172800000) // 2 days ago
      },
      {
        title: "Major Bank Launches Cryptocurrency Custody Service",
        summary: "One of the world's largest banks has announced a new cryptocurrency custody service for institutional clients, highlighting growing mainstream interest.",
        url: "https://example.com/news/5",
        imageUrl: "https://images.unsplash.com/photo-1551288049-bebda4e38f71",
        source: "Banking Insight",
        category: "Adoption",
        publishedAt: new Date(Date.now() - 259200000) // 3 days ago
      }
    ];

    sampleNews.forEach(article => this.addNewsArticle(article));

    // Sample market stats
    const sampleMarketStats: InsertMarketStats = {
      totalMarketCap: 2250000000000, // $2.25T
      totalVolume24h: 78500000000, // $78.5B
      btcDominance: 52.3,
      ethDominance: 15.2,
      totalCryptocurrencies: 10482,
      totalExchanges: 526
    };

    this.updateMarketStats(sampleMarketStats);
  }

  // User operations
  async getUser(id: number): Promise<any | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<any | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(user: any): Promise<any> {
    const id = this.currentUserId++;
    const newUser = { ...user, id };
    this.users.set(id, newUser);
    return newUser;
  }
  
  // Coin operations
  async getAllCoins(): Promise<Coin[]> {
    return Array.from(this.coinsMap.values()).sort((a, b) => a.marketCapRank - b.marketCapRank);
  }
  
  async getTopCoins(limit: number): Promise<Coin[]> {
    return Array.from(this.coinsMap.values())
      .sort((a, b) => a.marketCapRank - b.marketCapRank)
      .slice(0, limit);
  }
  
  async getCoinById(coinId: string): Promise<Coin | undefined> {
    return Array.from(this.coinsMap.values()).find(coin => coin.coinId === coinId);
  }
  
  async upsertCoin(coin: InsertCoin): Promise<Coin> {
    const existingCoin = Array.from(this.coinsMap.values()).find(c => c.coinId === coin.coinId);
    
    if (existingCoin) {
      const updatedCoin = { ...existingCoin, ...coin, lastUpdated: new Date() };
      this.coinsMap.set(existingCoin.id, updatedCoin);
      return updatedCoin;
    } else {
      const id = this.currentCoinId++;
      const newCoin = { ...coin, id, lastUpdated: new Date() };
      this.coinsMap.set(id, newCoin);
      return newCoin;
    }
  }
  
  // Trading pair operations
  async getAllTradingPairs(): Promise<TradingPair[]> {
    return Array.from(this.tradingPairsMap.values());
  }
  
  async getPopularTradingPairs(): Promise<TradingPair[]> {
    return Array.from(this.tradingPairsMap.values()).filter(pair => pair.isPopular);
  }
  
  async addTradingPair(tradingPair: InsertTradingPair): Promise<TradingPair> {
    const id = this.currentTradingPairId++;
    const newPair = { ...tradingPair, id };
    this.tradingPairsMap.set(id, newPair);
    return newPair;
  }
  
  // News operations
  async getLatestNews(limit: number): Promise<NewsArticle[]> {
    return Array.from(this.newsArticlesMap.values())
      .sort((a, b) => b.publishedAt.getTime() - a.publishedAt.getTime())
      .slice(0, limit);
  }
  
  async addNewsArticle(article: InsertNewsArticle): Promise<NewsArticle> {
    const id = this.currentNewsArticleId++;
    const newArticle = { ...article, id, createdAt: new Date() };
    this.newsArticlesMap.set(id, newArticle);
    return newArticle;
  }
  
  // Market stats operations
  async getLatestMarketStats(): Promise<MarketStats | undefined> {
    const allStats = Array.from(this.marketStatsMap.values());
    if (allStats.length === 0) return undefined;
    
    return allStats.sort((a, b) => b.lastUpdated.getTime() - a.lastUpdated.getTime())[0];
  }
  
  async updateMarketStats(stats: InsertMarketStats): Promise<MarketStats> {
    const id = this.currentMarketStatsId++;
    const newStats = { ...stats, id, lastUpdated: new Date() };
    this.marketStatsMap.set(id, newStats);
    return newStats;
  }
  
  // User favorites operations
  async getFavoritesByIp(ipAddress: string): Promise<UserFavorite[]> {
    return Array.from(this.userFavoritesMap.values())
      .filter(fav => fav.ipAddress === ipAddress);
  }
  
  async addFavorite(favorite: InsertUserFavorite): Promise<UserFavorite> {
    // Check if favorite already exists
    const existingFavorite = Array.from(this.userFavoritesMap.values())
      .find(fav => fav.ipAddress === favorite.ipAddress && fav.coinId === favorite.coinId);
    
    if (existingFavorite) {
      return existingFavorite;
    }
    
    const id = this.currentUserFavoriteId++;
    const newFavorite = { ...favorite, id, createdAt: new Date() };
    this.userFavoritesMap.set(id, newFavorite);
    return newFavorite;
  }
  
  async removeFavorite(id: number): Promise<void> {
    this.userFavoritesMap.delete(id);
  }
}

export const storage = new MemStorage();
