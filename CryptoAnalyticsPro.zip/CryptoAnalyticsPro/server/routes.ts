import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import axios from "axios";
import { insertCoinSchema, insertMarketStatsSchema, insertNewsArticleSchema, insertTradingPairSchema, insertUserFavoriteSchema } from "@shared/schema";

interface CoinGeckoMarket {
  id: string;
  symbol: string;
  name: string;
  image: string;
  current_price: number;
  market_cap: number;
  market_cap_rank: number;
  price_change_24h: number;
  price_change_percentage_24h: number;
  price_change_percentage_7d_in_currency?: number;
  sparkline_in_7d?: { price: number[] };
}

interface CoinGeckoGlobal {
  data: {
    total_market_cap: { usd: number };
    total_volume: { usd: number };
    market_cap_percentage: { 
      btc: number;
      eth: number;
    };
    active_cryptocurrencies: number;
    markets: number;
  };
}

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes
  app.get("/api/coins", async (req, res) => {
    try {
      const coins = await storage.getAllCoins();
      res.json(coins);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch coins" });
    }
  });

  app.get("/api/coins/top", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const coins = await storage.getTopCoins(limit);
      res.json(coins);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch top coins" });
    }
  });

  app.get("/api/market-stats", async (req, res) => {
    try {
      const stats = await storage.getLatestMarketStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch market stats" });
    }
  });

  app.get("/api/news", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 3;
      const news = await storage.getLatestNews(limit);
      res.json(news);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch news" });
    }
  });

  app.get("/api/trading-pairs", async (req, res) => {
    try {
      const pairs = await storage.getAllTradingPairs();
      res.json(pairs);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch trading pairs" });
    }
  });

  app.post("/api/favorites", async (req, res) => {
    try {
      const ipAddress = req.ip;
      const validatedData = insertUserFavoriteSchema.parse({
        ...req.body,
        ipAddress
      });
      
      const favorite = await storage.addFavorite(validatedData);
      res.status(201).json(favorite);
    } catch (error) {
      res.status(400).json({ error: "Invalid request data" });
    }
  });

  app.get("/api/favorites", async (req, res) => {
    try {
      const ipAddress = req.ip;
      const favorites = await storage.getFavoritesByIp(ipAddress);
      res.json(favorites);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch favorites" });
    }
  });

  // Cron job endpoint to fetch and update data from CoinGecko
  app.post("/api/cron/update-data", async (req, res) => {
    try {
      // Fetch top coins from CoinGecko
      const coinsResponse = await axios.get("https://api.coingecko.com/api/v3/coins/markets", {
        params: {
          vs_currency: "usd",
          order: "market_cap_desc",
          per_page: 100,
          page: 1,
          sparkline: true,
          price_change_percentage: "7d"
        }
      });

      const coinData = coinsResponse.data as CoinGeckoMarket[];
      
      // Insert or update coins
      for (const coin of coinData) {
        const validCoin = insertCoinSchema.parse({
          coinId: coin.id,
          symbol: coin.symbol,
          name: coin.name,
          image: coin.image,
          currentPrice: coin.current_price,
          marketCap: coin.market_cap,
          marketCapRank: coin.market_cap_rank,
          priceChange24h: coin.price_change_24h,
          priceChangePercentage24h: coin.price_change_percentage_24h,
          priceChangePercentage7d: coin.price_change_percentage_7d_in_currency,
          sparklineData: coin.sparkline_in_7d?.price || []
        });
        
        await storage.upsertCoin(validCoin);
      }

      // Fetch global market stats
      const globalResponse = await axios.get<CoinGeckoGlobal>("https://api.coingecko.com/api/v3/global");
      const globalData = globalResponse.data;
      
      const marketStats = insertMarketStatsSchema.parse({
        totalMarketCap: globalData.data.total_market_cap.usd,
        totalVolume24h: globalData.data.total_volume.usd,
        btcDominance: globalData.data.market_cap_percentage.btc,
        ethDominance: globalData.data.market_cap_percentage.eth,
        totalCryptocurrencies: globalData.data.active_cryptocurrencies,
        totalExchanges: globalData.data.markets
      });
      
      await storage.updateMarketStats(marketStats);
      
      res.json({ success: true, message: "Data updated successfully" });
    } catch (error) {
      console.error("Error updating data:", error);
      res.status(500).json({ error: "Failed to update data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
