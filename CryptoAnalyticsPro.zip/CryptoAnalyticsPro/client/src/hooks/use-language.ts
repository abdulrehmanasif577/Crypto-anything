import { useContext } from 'react';
import { LanguageContext } from '../context/LanguageContext';

// Custom hook to access the language context
export const useLanguage = () => {
  // This will never be undefined since we provide a default value in createContext
  const context = useContext(LanguageContext);
  return context;
};
