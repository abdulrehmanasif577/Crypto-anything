import i18n from "i18next";
import { initReactI18next } from "react-i18next";

// English translations
const enTranslations = {
  common: {
    loading: "Loading...",
    error: "An error occurred",
    retry: "Retry",
    save: "Save",
    cancel: "Cancel",
    close: "Close",
    back: "Back",
    next: "Next",
    submit: "Submit",
    search: "Search"
  },
  languages: {
    en: "English",
    ar: "العربية"
  },
  navigation: {
    dashboard: "Dashboard",
    charts: "Charts",
    tools: "Tools",
    analytics: "Analytics",
    learn: "Learn",
    about: "About"
  },
  dashboard: {
    marketOverview: "Market Overview",
    globalMarketCap: "Global Market Cap",
    volume24h: "24h Volume",
    btcDominance: "BTC Dominance",
    topCryptos: "Top Cryptocurrencies",
    viewAll: "View All",
    marketInsights: "Market Insights",
    featuredChart: "Featured Chart",
    topPerformers: "Top Performers",
    topGainers: "Top Gainers (24h)",
    topLosers: "Top Losers (24h)",
    trendingSearches: "Trending Searches"
  },
  charts: {
    liveCharts: "Live Charts",
    tradingPairs: "Trading Pairs",
    popular: "Popular",
    allPairs: "All Pairs",
    timeframes: {
      "15m": "15m",
      "1h": "1h",
      "4h": "4h",
      "1d": "1d",
      "1w": "1w",
      "1m": "1m"
    }
  },
  tools: {
    availableTools: "Available Tools",
    profitLossCalculator: {
      title: "Profit/Loss Calculator",
      selectCrypto: "Select Cryptocurrency",
      investmentAmount: "Investment Amount",
      entryPrice: "Entry Price",
      exitPrice: "Exit Price",
      calculate: "Calculate Profit/Loss",
      results: "Results",
      coinsPurchased: "Coins Purchased",
      initialInvestment: "Initial Investment",
      currentValue: "Current Value",
      profitLoss: "Profit/Loss",
      profitLossPercentage: "Profit/Loss (%)"
    },
    cryptoConverter: {
      title: "Crypto Converter",
      cryptoToFiat: "Crypto to Fiat",
      cryptoToCrypto: "Crypto to Crypto",
      amount: "Amount",
      fromCrypto: "From Cryptocurrency",
      toFiat: "To Fiat Currency",
      toCrypto: "To Cryptocurrency",
      result: "Result",
      exchangeRate: "Exchange Rate"
    },
    roiCalculator: {
      title: "ROI Calculator",
      selectCrypto: "Select Cryptocurrency",
      initialInvestment: "Initial Investment",
      investmentDate: "Investment Date",
      exitDate: "Exit Date",
      additionalInvestment: "Additional Investment",
      frequency: "Investment Frequency",
      results: "ROI Results",
      holdingPeriod: "Holding Period",
      totalInvestment: "Total Investment",
      finalValue: "Final Value",
      profit: "Profit / Loss",
      roiPercentage: "ROI Percentage",
      annualizedReturn: "Annualized Return",
      coinAmount: "Coin Amount"
    },
    gasFeeEstimator: {
      title: "Gas Fee Estimator",
      currentGasPrices: "Current Gas Prices",
      slow: "Slow",
      average: "Average",
      fast: "Fast",
      baseFee: "Base Fee",
      transactionType: "Transaction Type",
      priority: "Transaction Priority",
      gasLimit: "Gas Limit",
      useCustomGasPrice: "Use custom gas price",
      customGasPrice: "Custom Gas Price (Gwei)",
      estimatedFee: "Estimated Transaction Fee",
      maxFee: "Max Fee",
      tips: "Tips to reduce gas fees"
    }
  },
  analytics: {
    title: "Analytics & Insights",
    timeframe: "Timeframe",
    export: "Export Data",
    tabs: {
      gainersLosers: "Gainers & Losers",
      whaleTracker: "Whale Tracker",
      defiStats: "DeFi Stats",
      correlation: "Correlation",
      icoCalendar: "ICO & Airdrop"
    }
  },
  learn: {
    searchArticles: "Search articles...",
    latestArticles: "Latest Articles",
    categories: {
      basics: "Crypto Basics",
      trading: "Trading",
      defi: "DeFi",
      security: "Security"
    },
    readTime: "min read",
    joinCommunity: "Join Our Crypto Learning Community",
    subscribe: "Subscribe"
  },
  about: {
    aboutMarketPro: "About MarketPro",
    tabs: {
      aboutUs: "About Us",
      features: "Features",
      team: "Our Team",
      faq: "FAQ",
      contact: "Contact"
    },
    mission: "Our Mission",
    whyChoose: "Why Choose MarketPro",
    vision: "Our Vision",
    values: "Our Values",
    lookingForward: "Looking Forward",
    technologyStack: "Our Technology Stack",
    joinTeam: "Join Our Team",
    stillQuestions: "Still have questions?",
    getInTouch: "Get in Touch",
    messageSent: "Message Sent!",
    contactInfo: "Contact Information"
  },
  footer: {
    quickLinks: "Quick Links",
    resources: "Resources",
    contactUs: "Contact Us",
    reportIssue: "Report an Issue",
    language: "Language",
    copyright: "All rights reserved.",
    privacy: "Privacy Policy",
    terms: "Terms of Service",
    cookies: "Cookie Policy"
  }
};

// Arabic translations
const arTranslations = {
  common: {
    loading: "جاري التحميل...",
    error: "حدث خطأ",
    retry: "إعادة المحاولة",
    save: "حفظ",
    cancel: "إلغاء",
    close: "إغلاق",
    back: "رجوع",
    next: "التالي",
    submit: "إرسال",
    search: "بحث"
  },
  languages: {
    en: "English",
    ar: "العربية"
  },
  navigation: {
    dashboard: "لوحة التحكم",
    charts: "الرسوم البيانية",
    tools: "الأدوات",
    analytics: "التحليلات",
    learn: "تعلم",
    about: "عن الموقع"
  },
  dashboard: {
    marketOverview: "نظرة عامة على السوق",
    globalMarketCap: "القيمة السوقية العالمية",
    volume24h: "حجم التداول 24 ساعة",
    btcDominance: "هيمنة البيتكوين",
    topCryptos: "أعلى العملات المشفرة",
    viewAll: "عرض الكل",
    marketInsights: "رؤى السوق",
    featuredChart: "الرسم البياني المميز",
    topPerformers: "أفضل الأداء",
    topGainers: "أعلى الرابحين (24 ساعة)",
    topLosers: "أكبر الخاسرين (24 ساعة)",
    trendingSearches: "عمليات البحث الشائعة"
  },
  charts: {
    liveCharts: "الرسوم البيانية المباشرة",
    tradingPairs: "أزواج التداول",
    popular: "الشائع",
    allPairs: "جميع الأزواج",
    timeframes: {
      "15m": "15 د",
      "1h": "1 س",
      "4h": "4 س",
      "1d": "1 ي",
      "1w": "1 أ",
      "1m": "1 ش"
    }
  },
  tools: {
    availableTools: "الأدوات المتاحة",
    profitLossCalculator: {
      title: "حاسبة الربح/الخسارة",
      selectCrypto: "اختر العملة المشفرة",
      investmentAmount: "مبلغ الاستثمار",
      entryPrice: "سعر الدخول",
      exitPrice: "سعر الخروج",
      calculate: "حساب الربح/الخسارة",
      results: "النتائج",
      coinsPurchased: "العملات المشتراة",
      initialInvestment: "الاستثمار الأولي",
      currentValue: "القيمة الحالية",
      profitLoss: "الربح/الخسارة",
      profitLossPercentage: "الربح/الخسارة (%)"
    },
    cryptoConverter: {
      title: "محول العملات المشفرة",
      cryptoToFiat: "من عملة مشفرة إلى عملة تقليدية",
      cryptoToCrypto: "من عملة مشفرة إلى عملة مشفرة",
      amount: "المبلغ",
      fromCrypto: "من العملة المشفرة",
      toFiat: "إلى العملة التقليدية",
      toCrypto: "إلى العملة المشفرة",
      result: "النتيجة",
      exchangeRate: "سعر الصرف"
    },
    roiCalculator: {
      title: "حاسبة العائد على الاستثمار",
      selectCrypto: "اختر العملة المشفرة",
      initialInvestment: "الاستثمار الأولي",
      investmentDate: "تاريخ الاستثمار",
      exitDate: "تاريخ الخروج",
      additionalInvestment: "استثمار إضافي",
      frequency: "تكرار الاستثمار",
      results: "نتائج العائد على الاستثمار",
      holdingPeriod: "فترة الاحتفاظ",
      totalInvestment: "إجمالي الاستثمار",
      finalValue: "القيمة النهائية",
      profit: "الربح / الخسارة",
      roiPercentage: "نسبة العائد على الاستثمار",
      annualizedReturn: "العائد السنوي",
      coinAmount: "كمية العملة"
    },
    gasFeeEstimator: {
      title: "مقدر رسوم الغاز",
      currentGasPrices: "أسعار الغاز الحالية",
      slow: "بطيء",
      average: "متوسط",
      fast: "سريع",
      baseFee: "الرسوم الأساسية",
      transactionType: "نوع المعاملة",
      priority: "أولوية المعاملة",
      gasLimit: "حد الغاز",
      useCustomGasPrice: "استخدام سعر غاز مخصص",
      customGasPrice: "سعر الغاز المخصص (Gwei)",
      estimatedFee: "رسوم المعاملة المقدرة",
      maxFee: "الحد الأقصى للرسوم",
      tips: "نصائح لتقليل رسوم الغاز"
    }
  },
  analytics: {
    title: "التحليلات والرؤى",
    timeframe: "الإطار الزمني",
    export: "تصدير البيانات",
    tabs: {
      gainersLosers: "الرابحون والخاسرون",
      whaleTracker: "متتبع الحيتان",
      defiStats: "إحصاءات DeFi",
      correlation: "الارتباط",
      icoCalendar: "تقويم ICO والتوزيعات المجانية"
    }
  },
  learn: {
    searchArticles: "البحث في المقالات...",
    latestArticles: "أحدث المقالات",
    categories: {
      basics: "أساسيات العملات المشفرة",
      trading: "التداول",
      defi: "التمويل اللامركزي",
      security: "الأمان"
    },
    readTime: "دقيقة قراءة",
    joinCommunity: "انضم إلى مجتمع تعلم العملات المشفرة",
    subscribe: "اشترك"
  },
  about: {
    aboutMarketPro: "عن ماركت برو",
    tabs: {
      aboutUs: "عن الشركة",
      features: "الميزات",
      team: "فريقنا",
      faq: "الأسئلة الشائعة",
      contact: "اتصل بنا"
    },
    mission: "مهمتنا",
    whyChoose: "لماذا تختار ماركت برو",
    vision: "رؤيتنا",
    values: "قيمنا",
    lookingForward: "نتطلع إلى المستقبل",
    technologyStack: "تقنياتنا",
    joinTeam: "انضم إلى فريقنا",
    stillQuestions: "هل لديك أسئلة؟",
    getInTouch: "تواصل معنا",
    messageSent: "تم إرسال الرسالة!",
    contactInfo: "معلومات الاتصال"
  },
  footer: {
    quickLinks: "روابط سريعة",
    resources: "موارد",
    contactUs: "اتصل بنا",
    reportIssue: "الإبلاغ عن مشكلة",
    language: "اللغة",
    copyright: "جميع الحقوق محفوظة.",
    privacy: "سياسة الخصوصية",
    terms: "شروط الخدمة",
    cookies: "سياسة ملفات تعريف الارتباط"
  }
};

// Initialize i18next
i18n
  .use(initReactI18next)
  .init({
    resources: {
      en: { translation: enTranslations },
      ar: { translation: arTranslations }
    },
    lng: "en", // Default language
    fallbackLng: "en",
    interpolation: {
      escapeValue: false // React already escapes values
    }
  });

// Function to change language
export const changeLanguage = (lng: string) => {
  return i18n.changeLanguage(lng);
};

// Translation function
export const t = (key: string, options?: any) => {
  return i18n.t(key, options);
};

export default i18n;
