import axios from 'axios';

// Base API configuration
const api = axios.create({
  baseURL: '',
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 10000, // 10 seconds
});

// API endpoints for CoinGecko
const coinGeckoApi = {
  getCoins: async (params = {}) => {
    try {
      const response = await axios.get('/api/coins', { params });
      return response.data;
    } catch (error) {
      console.error('Error fetching coins:', error);
      throw error;
    }
  },

  getTopCoins: async (limit = 10) => {
    try {
      const response = await axios.get(`/api/coins/top?limit=${limit}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching top coins:', error);
      throw error;
    }
  },

  getCoinDetail: async (coinId: string) => {
    try {
      const response = await axios.get(`/api/coins/${coinId}`);
      return response.data;
    } catch (error) {
      console.error(`Error fetching coin detail for ${coinId}:`, error);
      throw error;
    }
  },

  getMarketStats: async () => {
    try {
      const response = await axios.get('/api/market-stats');
      return response.data;
    } catch (error) {
      console.error('Error fetching market stats:', error);
      throw error;
    }
  },
};

// API endpoints for news
const newsApi = {
  getLatestNews: async (limit = 3) => {
    try {
      const response = await axios.get(`/api/news?limit=${limit}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching latest news:', error);
      throw error;
    }
  },
};

// API endpoints for trading
const tradingApi = {
  getTradingPairs: async () => {
    try {
      const response = await axios.get('/api/trading-pairs');
      return response.data;
    } catch (error) {
      console.error('Error fetching trading pairs:', error);
      throw error;
    }
  },
};

// API endpoints for favorites
const favoritesApi = {
  getFavorites: async () => {
    try {
      const response = await axios.get('/api/favorites');
      return response.data;
    } catch (error) {
      console.error('Error fetching favorites:', error);
      throw error;
    }
  },

  addFavorite: async (coinId: string) => {
    try {
      const response = await axios.post('/api/favorites', { coinId });
      return response.data;
    } catch (error) {
      console.error('Error adding favorite:', error);
      throw error;
    }
  },

  removeFavorite: async (coinId: string) => {
    try {
      const response = await axios.delete(`/api/favorites/${coinId}`);
      return response.data;
    } catch (error) {
      console.error('Error removing favorite:', error);
      throw error;
    }
  },
};

// Gas fee estimator API
const gasApi = {
  getGasFees: async () => {
    try {
      const response = await axios.get('/api/gas-fees');
      return response.data;
    } catch (error) {
      console.error('Error fetching gas fees:', error);
      throw error;
    }
  },
};

export {
  api,
  coinGeckoApi,
  newsApi,
  tradingApi,
  favoritesApi,
  gasApi,
};
