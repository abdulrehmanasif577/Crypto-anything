import React, { createContext, useState, useEffect, ReactNode } from 'react';
// Import correctly from i18n.ts
import i18next from '../lib/i18n';
import { changeLanguage as changeLang, t as translate } from '../lib/i18n';

// Define the context type
interface LanguageContextType {
  currentLanguage: string;
  changeLanguage: (lang: string) => void;
  t: (key: string, options?: any) => any; // Using 'any' to accommodate i18next's return type
  isRTL: boolean;
}

// Create default values for the context
export const defaultLanguageContextValue: LanguageContextType = {
  currentLanguage: 'en',
  changeLanguage: (lang: string) => {
    console.warn('Language context not fully initialized');
  },
  t: (key: string, options?: any) => key,
  isRTL: false
};

// Create the context with the default value
export const LanguageContext = createContext<LanguageContextType>(defaultLanguageContextValue);

interface LanguageProviderProps {
  children: ReactNode;
}

export const LanguageProvider: React.FC<LanguageProviderProps> = ({ children }) => {
  const [currentLanguage, setCurrentLanguage] = useState('en');
  const [isRTL, setIsRTL] = useState(false);

  // Initialize language from localStorage if available
  useEffect(() => {
    try {
      const savedLanguage = localStorage.getItem('language') || 'en';
      setCurrentLanguage(savedLanguage);
      setIsRTL(savedLanguage === 'ar');
      changeLang(savedLanguage);
      
      // Set document direction
      document.documentElement.dir = savedLanguage === 'ar' ? 'rtl' : 'ltr';
      document.documentElement.lang = savedLanguage;
    } catch (error) {
      console.error('Error initializing language:', error);
    }
  }, []);

  // Function to change language
  const handleChangeLanguage = (lang: string) => {
    try {
      setCurrentLanguage(lang);
      setIsRTL(lang === 'ar');
      changeLang(lang);
      localStorage.setItem('language', lang);
      
      // Set document direction
      document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
      document.documentElement.lang = lang;
    } catch (error) {
      console.error('Error changing language:', error);
    }
  };

  // Create a wrapper function for translate to ensure consistent typing
  const translationFunction = (key: string, options?: any): any => {
    return translate(key, options);
  };

  return (
    <LanguageContext.Provider
      value={{
        currentLanguage,
        changeLanguage: handleChangeLanguage,
        t: translationFunction,
        isRTL
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
};
