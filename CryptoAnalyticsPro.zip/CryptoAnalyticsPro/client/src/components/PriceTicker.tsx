import { useQuery } from "@tanstack/react-query";
import { useState, useEffect } from "react";

const PriceTicker = () => {
  const { data: coins, isLoading, error } = useQuery({
    queryKey: ['/api/coins/top'],
    staleTime: 60000 // 1 minute
  });

  // Auto-refresh every minute
  const [refresh, setRefresh] = useState(0);
  
  useEffect(() => {
    const timer = setInterval(() => {
      setRefresh(prev => prev + 1);
    }, 60000);
    
    return () => clearInterval(timer);
  }, []);
  
  if (isLoading) {
    return (
      <div className="overflow-hidden bg-secondary rounded-lg p-3 mb-6 border border-border flex justify-center items-center h-14">
        <div className="loader"></div>
      </div>
    );
  }
  
  if (error || !coins) {
    return (
      <div className="overflow-hidden bg-secondary rounded-lg p-3 mb-6 border border-border">
        <div className="text-center text-sm text-gray-400">
          Unable to load price data
        </div>
      </div>
    );
  }
  
  return (
    <div className="overflow-hidden bg-secondary rounded-lg p-3 mb-6 border border-border">
      <div className="relative whitespace-nowrap ticker-wrap">
        <div className="ticker-item">
          {coins.map((coin: any) => (
            <span key={coin.id} className="inline-flex items-center mr-8">
              <img 
                src={coin.image} 
                alt={coin.symbol.toUpperCase()} 
                className="w-5 h-5 mr-2"
                onError={(e) => {
                  e.currentTarget.onerror = null;
                  e.currentTarget.src = 'https://assets.coingecko.com/coins/images/1/thumb/bitcoin.png';
                }}
              />
              <span className="font-medium">{coin.symbol.toUpperCase()}</span>
              <span className="mx-2 font-mono">${coin.currentPrice?.toLocaleString(undefined, { maximumFractionDigits: 8 })}</span>
              <span className={coin.priceChangePercentage24h > 0 ? "text-success text-sm" : 
                             coin.priceChangePercentage24h < 0 ? "text-danger text-sm" : "text-gray-400 text-sm"}>
                {coin.priceChangePercentage24h > 0 ? (
                  <svg xmlns="http://www.w3.org/2000/svg" className="inline mr-1" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="m18 15-6-6-6 6"/>
                  </svg>
                ) : coin.priceChangePercentage24h < 0 ? (
                  <svg xmlns="http://www.w3.org/2000/svg" className="inline mr-1" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="m6 9 6 6 6-6"/>
                  </svg>
                ) : (
                  <svg xmlns="http://www.w3.org/2000/svg" className="inline mr-1" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M8 12h8"/>
                  </svg>
                )}
                {Math.abs(coin.priceChangePercentage24h).toFixed(2)}%
              </span>
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};

export default PriceTicker;
