import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";

const LatestNews = () => {
  const { data: news, isLoading, error } = useQuery({
    queryKey: ['/api/news'],
    staleTime: 300000 // 5 minutes
  });
  
  if (isLoading) {
    return (
      <div className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold">Latest News</h2>
          <Link href="/news" className="text-sm text-accent hover:underline">
            More News 
            <svg xmlns="http://www.w3.org/2000/svg" className="inline ml-1" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M5 12h14"/>
              <path d="m12 5 7 7-7 7"/>
            </svg>
          </Link>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-secondary rounded-lg overflow-hidden border border-border animate-pulse h-96">
              <div className="w-full h-48 bg-muted"></div>
              <div className="p-4">
                <div className="h-4 bg-muted rounded mb-4 w-24"></div>
                <div className="h-6 bg-muted rounded mb-3 w-full"></div>
                <div className="h-4 bg-muted rounded mb-3 w-full"></div>
                <div className="h-4 bg-muted rounded mb-3 w-3/4"></div>
                <div className="h-3 bg-muted rounded mt-6 w-32"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }
  
  if (error || !news || news.length === 0) {
    return (
      <div className="mb-8">
        <h2 className="text-xl font-bold mb-4">Latest News</h2>
        <div className="bg-secondary rounded-lg p-4 border border-border">
          <p className="text-center text-gray-400">Unable to load news articles</p>
        </div>
      </div>
    );
  }
  
  // Default news articles if API doesn't return any
  const defaultNews = [
    {
      id: 1,
      title: "SEC Approves Spot Bitcoin ETF Applications",
      summary: "The U.S. Securities and Exchange Commission has approved multiple spot Bitcoin ETF applications, marking a significant milestone...",
      imageUrl: "https://images.unsplash.com/photo-1605792657660-596af9009e82",
      category: "Bitcoin",
      source: "CryptoNews",
      publishedAt: new Date(Date.now() - 10800000).toISOString() // 3 hours ago
    },
    {
      id: 2,
      title: "Ethereum Layer 2 Solutions See Record Growth",
      summary: "Ethereum scaling solutions like Arbitrum and Optimism have seen unprecedented growth in both transaction volume and user adoption...",
      imageUrl: "https://images.unsplash.com/photo-1622630998477-20aa696ecb05",
      category: "Ethereum",
      source: "DeFi Pulse",
      publishedAt: new Date(Date.now() - 28800000).toISOString() // 8 hours ago
    },
    {
      id: 3,
      title: "New Crypto Regulatory Framework Proposed in EU",
      summary: "The European Union has proposed a comprehensive regulatory framework for cryptocurrencies, aiming to provide clarity for businesses...",
      imageUrl: "https://images.unsplash.com/photo-1639762681057-408e52192e55",
      category: "Regulation",
      source: "EU Regulatory Watch",
      publishedAt: new Date(Date.now() - 86400000).toISOString() // 1 day ago
    }
  ];
  
  // Use either API data or default news
  const articlesToDisplay = news.length > 0 ? news : defaultNews;
  
  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      'Bitcoin': 'accent',
      'Ethereum': 'blue-500',
      'Regulation': 'amber-500',
      'DeFi': 'purple-500',
      'NFT': 'green-500',
      'Altcoin': 'red-500'
    };
    
    return colors[category] || 'accent';
  };
  
  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffSec = Math.round(diffMs / 1000);
    const diffMin = Math.round(diffSec / 60);
    const diffHr = Math.round(diffMin / 60);
    const diffDays = Math.round(diffHr / 24);
    
    if (diffSec < 60) return `${diffSec} seconds ago`;
    if (diffMin < 60) return `${diffMin} minutes ago`;
    if (diffHr < 24) return `${diffHr} hours ago`;
    if (diffDays === 1) return '1 day ago';
    return `${diffDays} days ago`;
  };
  
  return (
    <div className="mb-8">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold">Latest News</h2>
        <Link href="/news" className="text-sm text-accent hover:underline">
          More News 
          <svg xmlns="http://www.w3.org/2000/svg" className="inline ml-1" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M5 12h14"/>
            <path d="m12 5 7 7-7 7"/>
          </svg>
        </Link>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {articlesToDisplay.map((article: any) => (
          <div key={article.id} className="bg-secondary rounded-lg overflow-hidden border border-border card">
            <img 
              src={article.imageUrl} 
              alt={article.title} 
              className="w-full h-48 object-cover"
              onError={(e) => {
                e.currentTarget.onerror = null;
                e.currentTarget.src = 'https://images.unsplash.com/photo-1621761191319-c6fb62004040'; // fallback image
              }}
            />
            <div className="p-4">
              <span className={`inline-block bg-${getCategoryColor(article.category)} bg-opacity-20 text-${getCategoryColor(article.category)} text-xs px-2 py-1 rounded-md mb-2`}>
                {article.category}
              </span>
              <h3 className="font-medium text-lg mb-2">{article.title}</h3>
              <p className="text-gray-400 text-sm mb-3 line-clamp-2">{article.summary}</p>
              <div className="flex justify-between items-center text-xs text-gray-500">
                <span>{formatTimeAgo(article.publishedAt)}</span>
                <span>{article.source}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default LatestNews;
