import { Link, useLocation } from "wouter";
import { useState } from "react";
import { useLanguage } from "../hooks/use-language";

interface HeaderProps {
  onMenuToggle: () => void;
}

const Header = ({ onMenuToggle }: HeaderProps) => {
  const [location] = useLocation();
  const { currentLanguage, changeLanguage } = useLanguage();
  const [langDropdownOpen, setLangDropdownOpen] = useState(false);
  
  const toggleLangDropdown = () => {
    setLangDropdownOpen(!langDropdownOpen);
  };
  
  const handleClickOutside = (e: React.MouseEvent) => {
    if (langDropdownOpen) {
      setLangDropdownOpen(false);
    }
  };
  
  return (
    <header className="sticky top-0 z-50 bg-secondary border-b border-border">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <button 
              onClick={onMenuToggle} 
              className="lg:hidden text-gray-300 p-2"
              aria-label="Open menu"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <line x1="4" x2="20" y1="12" y2="12"/>
                <line x1="4" x2="20" y1="6" y2="6"/>
                <line x1="4" x2="20" y1="18" y2="18"/>
              </svg>
            </button>
            <Link href="/" className="flex items-center space-x-2">
              <span className="text-accent text-2xl font-bold">Market<span className="text-white">Pro</span></span>
            </Link>
          </div>
          
          <nav className="hidden lg:flex items-center space-x-6 text-sm text-gray-300">
            <Link 
              href="/" 
              className={`py-2 ${location === '/' ? 'text-white font-medium border-b-2 border-accent' : 'hover:text-white'}`}
            >
              Dashboard
            </Link>
            <Link 
              href="/charts" 
              className={`py-2 ${location === '/charts' ? 'text-white font-medium border-b-2 border-accent' : 'hover:text-white'}`}
            >
              Charts
            </Link>

            <Link 
              href="/analytics" 
              className={`py-2 ${location === '/analytics' ? 'text-white font-medium border-b-2 border-accent' : 'hover:text-white'}`}
            >
              Analytics
            </Link>
            <Link 
              href="/learn" 
              className={`py-2 ${location === '/learn' ? 'text-white font-medium border-b-2 border-accent' : 'hover:text-white'}`}
            >
              Learn
            </Link>
            <Link 
              href="/about" 
              className={`py-2 ${location === '/about' ? 'text-white font-medium border-b-2 border-accent' : 'hover:text-white'}`}
            >
              About
            </Link>
          </nav>
          
          <div className="flex items-center space-x-4">
            <button 
              id="languageToggle" 
              className="flex items-center space-x-1 text-sm text-gray-300 py-1 px-2 rounded-md hover:bg-gray-800"
              onClick={toggleLangDropdown}
            >
              <span id="currentLang">{currentLanguage === 'en' ? 'EN' : 'AR'}</span>
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                width="12" 
                height="12" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round"
              >
                <path d="m6 9 6 6 6-6"/>
              </svg>
            </button>
            
            {langDropdownOpen && (
              <div 
                className="absolute top-14 right-4 bg-secondary border border-border rounded-md shadow-lg p-2 z-50"
                onClick={handleClickOutside}
              >
                <button 
                  className="block px-4 py-2 text-sm hover:bg-primary rounded w-full text-left"
                  onClick={() => {
                    changeLanguage('en');
                    setLangDropdownOpen(false);
                  }}
                >
                  English
                </button>
                <button 
                  className="block px-4 py-2 text-sm hover:bg-primary rounded w-full text-left"
                  onClick={() => {
                    changeLanguage('ar');
                    setLangDropdownOpen(false);
                  }}
                >
                  العربية
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
