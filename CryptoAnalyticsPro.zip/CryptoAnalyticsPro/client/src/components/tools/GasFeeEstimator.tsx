import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useLanguage } from '@/hooks/use-language';

const GasFeeEstimator = () => {
  const { t, isRTL } = useLanguage();
  const [activeTab, setActiveTab] = useState('ethereum');
  const [isLoading, setIsLoading] = useState(true);
  
  // Gas fee data (simulated - would be fetched from an API in production)
  const [gasData, setGasData] = useState({
    ethereum: {
      slow: { price: 20, time: '5+ min' },
      average: { price: 35, time: '2-5 min' },
      fast: { price: 50, time: '< 1 min' },
      baseFee: 15.2,
      ethPrice: 3400
    },
    polygon: {
      slow: { price: 40, time: '5+ min' },
      average: { price: 90, time: '2-5 min' },
      fast: { price: 130, time: '< 1 min' },
      baseFee: 35.5,
      maticPrice: 0.98
    },
    arbitrum: {
      slow: { price: 0.10, time: '5+ min' },
      average: { price: 0.25, time: '2-5 min' },
      fast: { price: 0.40, time: '< 1 min' },
      baseFee: 0.05,
      ethPrice: 3400
    }
  });
  
  // Form state for each network
  const [ethereumForm, setEthereumForm] = useState({
    transactionType: 'transfer',
    priority: 'average',
    gasLimit: 21000,
    customGasPrice: 35,
    useCustomGasPrice: false
  });
  
  const [polygonForm, setPolygonForm] = useState({
    transactionType: 'transfer',
    priority: 'average',
    gasLimit: 21000,
    customGasPrice: 90,
    useCustomGasPrice: false
  });
  
  const [arbitrumForm, setArbitrumForm] = useState({
    transactionType: 'transfer',
    priority: 'average',
    gasLimit: 21000,
    customGasPrice: 0.25,
    useCustomGasPrice: false
  });
  
  // Transaction types and their gas limits
  const transactionTypes = {
    ethereum: [
      { name: 'ETH Transfer', value: 'transfer', gasLimit: 21000 },
      { name: 'ERC20 Transfer', value: 'erc20', gasLimit: 65000 },
      { name: 'Swap on Uniswap', value: 'uniswap', gasLimit: 180000 },
      { name: 'NFT Minting', value: 'nft', gasLimit: 150000 },
      { name: 'Smart Contract Deployment', value: 'contract', gasLimit: 800000 }
    ],
    polygon: [
      { name: 'MATIC Transfer', value: 'transfer', gasLimit: 21000 },
      { name: 'ERC20 Transfer', value: 'erc20', gasLimit: 65000 },
      { name: 'Swap on QuickSwap', value: 'quickswap', gasLimit: 140000 },
      { name: 'NFT Minting', value: 'nft', gasLimit: 120000 },
      { name: 'Smart Contract Deployment', value: 'contract', gasLimit: 500000 }
    ],
    arbitrum: [
      { name: 'ETH Transfer', value: 'transfer', gasLimit: 21000 },
      { name: 'ERC20 Transfer', value: 'erc20', gasLimit: 60000 },
      { name: 'Swap on GMX', value: 'gmx', gasLimit: 120000 },
      { name: 'NFT Minting', value: 'nft', gasLimit: 100000 },
      { name: 'Smart Contract Deployment', value: 'contract', gasLimit: 400000 }
    ]
  };
  
  // Simulate fetching gas data from an API
  useEffect(() => {
    const fetchGasData = async () => {
      setIsLoading(true);
      // Simulate API call with a delay
      setTimeout(() => {
        // In a real app, this would be an actual API call
        // const response = await fetch('/api/gas-fees');
        // const data = await response.json();
        // setGasData(data);
        setIsLoading(false);
      }, 1000);
    };
    
    fetchGasData();
    
    // Refresh gas data every 30 seconds
    const interval = setInterval(fetchGasData, 30000);
    return () => clearInterval(interval);
  }, []);
  
  // Handle transaction type change
  const handleTransactionTypeChange = (network: string, value: string) => {
    const gasLimit = getGasLimitForTransaction(network, value);
    
    switch (network) {
      case 'ethereum':
        setEthereumForm(prev => ({ ...prev, transactionType: value, gasLimit }));
        break;
      case 'polygon':
        setPolygonForm(prev => ({ ...prev, transactionType: value, gasLimit }));
        break;
      case 'arbitrum':
        setArbitrumForm(prev => ({ ...prev, transactionType: value, gasLimit }));
        break;
    }
  };
  
  // Handle priority change
  const handlePriorityChange = (network: string, value: string) => {
    switch (network) {
      case 'ethereum':
        setEthereumForm(prev => ({ 
          ...prev, 
          priority: value,
          customGasPrice: gasData.ethereum[value as keyof typeof gasData.ethereum]?.price || prev.customGasPrice
        }));
        break;
      case 'polygon':
        setPolygonForm(prev => ({ 
          ...prev, 
          priority: value,
          customGasPrice: gasData.polygon[value as keyof typeof gasData.polygon]?.price || prev.customGasPrice
        }));
        break;
      case 'arbitrum':
        setArbitrumForm(prev => ({ 
          ...prev, 
          priority: value,
          customGasPrice: gasData.arbitrum[value as keyof typeof gasData.arbitrum]?.price || prev.customGasPrice
        }));
        break;
    }
  };
  
  // Handle gas limit change
  const handleGasLimitChange = (network: string, value: string) => {
    const gasLimit = parseInt(value) || 0;
    
    switch (network) {
      case 'ethereum':
        setEthereumForm(prev => ({ ...prev, gasLimit }));
        break;
      case 'polygon':
        setPolygonForm(prev => ({ ...prev, gasLimit }));
        break;
      case 'arbitrum':
        setArbitrumForm(prev => ({ ...prev, gasLimit }));
        break;
    }
  };
  
  // Handle custom gas price change
  const handleCustomGasPriceChange = (network: string, value: string) => {
    const gasPrice = parseFloat(value) || 0;
    
    switch (network) {
      case 'ethereum':
        setEthereumForm(prev => ({ ...prev, customGasPrice: gasPrice }));
        break;
      case 'polygon':
        setPolygonForm(prev => ({ ...prev, customGasPrice: gasPrice }));
        break;
      case 'arbitrum':
        setArbitrumForm(prev => ({ ...prev, customGasPrice: gasPrice }));
        break;
    }
  };
  
  // Toggle custom gas price
  const toggleCustomGasPrice = (network: string) => {
    switch (network) {
      case 'ethereum':
        setEthereumForm(prev => ({ ...prev, useCustomGasPrice: !prev.useCustomGasPrice }));
        break;
      case 'polygon':
        setPolygonForm(prev => ({ ...prev, useCustomGasPrice: !prev.useCustomGasPrice }));
        break;
      case 'arbitrum':
        setArbitrumForm(prev => ({ ...prev, useCustomGasPrice: !prev.useCustomGasPrice }));
        break;
    }
  };
  
  // Get gas limit for a specific transaction type
  const getGasLimitForTransaction = (network: string, type: string) => {
    const networkTransactions = transactionTypes[network as keyof typeof transactionTypes];
    const transaction = networkTransactions.find(t => t.value === type);
    return transaction ? transaction.gasLimit : 21000;
  };
  
  // Calculate gas fee in native token
  const calculateGasFee = (network: string) => {
    let gasPrice = 0;
    let gasLimit = 0;
    
    switch (network) {
      case 'ethereum':
        gasPrice = ethereumForm.useCustomGasPrice 
          ? ethereumForm.customGasPrice 
          : gasData.ethereum[ethereumForm.priority as keyof typeof gasData.ethereum]?.price || 0;
        gasLimit = ethereumForm.gasLimit;
        break;
      case 'polygon':
        gasPrice = polygonForm.useCustomGasPrice 
          ? polygonForm.customGasPrice 
          : gasData.polygon[polygonForm.priority as keyof typeof gasData.polygon]?.price || 0;
        gasLimit = polygonForm.gasLimit;
        break;
      case 'arbitrum':
        gasPrice = arbitrumForm.useCustomGasPrice 
          ? arbitrumForm.customGasPrice 
          : gasData.arbitrum[arbitrumForm.priority as keyof typeof gasData.arbitrum]?.price || 0;
        gasLimit = arbitrumForm.gasLimit;
        break;
      default:
        return 0;
    }
    
    // Gas fee in Gwei = gas price (Gwei) * gas limit
    const gasFeeGwei = gasPrice * gasLimit;
    
    // Gas fee in ETH/MATIC = gas fee in Gwei / 1e9
    return gasFeeGwei / 1e9;
  };
  
  // Calculate gas fee in USD
  const calculateGasFeeUSD = (network: string) => {
    const gasFeeNative = calculateGasFee(network);
    
    switch (network) {
      case 'ethereum':
      case 'arbitrum':
        return gasFeeNative * gasData.ethereum.ethPrice;
      case 'polygon':
        return gasFeeNative * gasData.polygon.maticPrice;
      default:
        return 0;
    }
  };
  
  // Get current form for active tab
  const getActiveForm = () => {
    switch (activeTab) {
      case 'ethereum':
        return ethereumForm;
      case 'polygon':
        return polygonForm;
      case 'arbitrum':
        return arbitrumForm;
      default:
        return ethereumForm;
    }
  };
  
  // Get network label
  const getNetworkLabel = (network: string) => {
    switch (network) {
      case 'ethereum':
        return 'Ethereum';
      case 'polygon':
        return 'Polygon';
      case 'arbitrum':
        return 'Arbitrum';
      default:
        return 'Network';
    }
  };
  
  // Get network token
  const getNetworkToken = (network: string) => {
    switch (network) {
      case 'ethereum':
        return 'ETH';
      case 'polygon':
        return 'MATIC';
      case 'arbitrum':
        return 'ETH';
      default:
        return 'Token';
    }
  };
  
  return (
    <div>
      <h3 className="text-lg font-bold mb-4">Gas Fee Estimator</h3>
      
      <Tabs defaultValue="ethereum" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-6 grid grid-cols-3 h-auto">
          <TabsTrigger value="ethereum" className="py-2 data-[state=active]:bg-accent">
            <div className="flex flex-col md:flex-row items-center gap-2">
              <svg 
                width="20" 
                height="20" 
                viewBox="0 0 784 784" 
                xmlns="http://www.w3.org/2000/svg"
                className="text-gray-400"
              >
                <path d="M392 0C175.36 0 0 175.36 0 392s175.36 392 392 392 392-175.36 392-392S608.64 0 392 0zm117.12 522.24-19.04 56-118.4-173.44 118.24-173.44 19.04 56.16L426.24 392l82.88 130.24zm-236.64 0L354.88 392l-82.88-130.24-19.04-56 118.24 173.44-118.4 173.44-19.04-56.16z" fill="currentColor"/>
              </svg>
              <span>Ethereum</span>
            </div>
          </TabsTrigger>
          <TabsTrigger value="polygon" className="py-2 data-[state=active]:bg-purple-600">
            <div className="flex flex-col md:flex-row items-center gap-2">
              <svg 
                width="20" 
                height="20" 
                viewBox="0 0 38 33" 
                xmlns="http://www.w3.org/2000/svg"
                className="text-gray-400"
              >
                <path d="M19 0l19 12.334L28.5 33l-19-12.334L19 0zM9.5 24.926l19 12.334L19 16.926 9.5 24.926zM19 0L0 12.334l9.5 20.666L19 0z" fill="currentColor"/>
              </svg>
              <span>Polygon</span>
            </div>
          </TabsTrigger>
          <TabsTrigger value="arbitrum" className="py-2 data-[state=active]:bg-blue-600">
            <div className="flex flex-col md:flex-row items-center gap-2">
              <svg 
                width="20" 
                height="20" 
                viewBox="0 0 300 300" 
                xmlns="http://www.w3.org/2000/svg"
                className="text-gray-400"
              >
                <path d="M150 300C67.157 300 0 232.843 0 150S67.157 0 150 0s150 67.157 150 150-67.157 150-150 150zm-45.976-75h22.138l20.605-35 38.35-65h23.767L169.25 75H130.9l-38.25 65-11.377 19.25 22.75 38.5h41.75l22.75-38.5-22.75-38.5h-22.138l22.75 38.5-11.375 19.25h-20.875l-22.75-38.5 34.125-57.75h20.875l38.25 65 11.375 19.25-22.75 38.5h-85.625z" fill="currentColor"/>
              </svg>
              <span>Arbitrum</span>
            </div>
          </TabsTrigger>
        </TabsList>
        
        {['ethereum', 'polygon', 'arbitrum'].map((network) => (
          <TabsContent key={network} value={network}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-6">
                <Card className="bg-primary border-border">
                  <CardContent className="p-6">
                    <h4 className="font-medium mb-4">Current {getNetworkLabel(network)} Gas Prices</h4>
                    
                    {isLoading ? (
                      <div className="h-32 flex items-center justify-center">
                        <div className="loader"></div>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <div className="flex items-center justify-between pb-2 border-b border-border">
                          <div className="flex items-center">
                            <div className="w-3 h-3 rounded-full bg-red-500 mr-2"></div>
                            <span>Slow</span>
                          </div>
                          <div>
                            <span className="font-mono">
                              {gasData[network as keyof typeof gasData]?.slow.price} Gwei
                            </span>
                            <span className="text-sm text-gray-400 ml-2">
                              (~{gasData[network as keyof typeof gasData]?.slow.time})
                            </span>
                          </div>
                        </div>
                        
                        <div className="flex items-center justify-between pb-2 border-b border-border">
                          <div className="flex items-center">
                            <div className="w-3 h-3 rounded-full bg-yellow-500 mr-2"></div>
                            <span>Average</span>
                          </div>
                          <div>
                            <span className="font-mono">
                              {gasData[network as keyof typeof gasData]?.average.price} Gwei
                            </span>
                            <span className="text-sm text-gray-400 ml-2">
                              (~{gasData[network as keyof typeof gasData]?.average.time})
                            </span>
                          </div>
                        </div>
                        
                        <div className="flex items-center justify-between pb-2 border-b border-border">
                          <div className="flex items-center">
                            <div className="w-3 h-3 rounded-full bg-green-500 mr-2"></div>
                            <span>Fast</span>
                          </div>
                          <div>
                            <span className="font-mono">
                              {gasData[network as keyof typeof gasData]?.fast.price} Gwei
                            </span>
                            <span className="text-sm text-gray-400 ml-2">
                              (~{gasData[network as keyof typeof gasData]?.fast.time})
                            </span>
                          </div>
                        </div>
                        
                        <div className="flex items-center justify-between pt-2">
                          <span className="text-gray-400">Base Fee</span>
                          <span className="font-mono">
                            {gasData[network as keyof typeof gasData]?.baseFee.toFixed(2)} Gwei
                          </span>
                        </div>
                        
                        <div className="mt-4 text-xs text-gray-400 text-center">
                          Last updated: {new Date().toLocaleTimeString()}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
                
                <div className="space-y-4">
                  <div>
                    <Label htmlFor={`${network}-transaction-type`}>Transaction Type</Label>
                    <Select 
                      value={getActiveForm().transactionType} 
                      onValueChange={(value) => handleTransactionTypeChange(network, value)}
                    >
                      <SelectTrigger id={`${network}-transaction-type`} className="mt-1 bg-primary border-border">
                        <SelectValue placeholder="Select transaction type" />
                      </SelectTrigger>
                      <SelectContent>
                        {transactionTypes[network as keyof typeof transactionTypes].map((type) => (
                          <SelectItem key={type.value} value={type.value}>
                            {type.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-gray-400 mt-1">
                      Estimated gas limit: {getActiveForm().gasLimit.toLocaleString()} units
                    </p>
                  </div>
                  
                  <div>
                    <Label htmlFor={`${network}-priority`}>Transaction Priority</Label>
                    <Select 
                      value={getActiveForm().priority} 
                      onValueChange={(value) => handlePriorityChange(network, value)}
                      disabled={getActiveForm().useCustomGasPrice}
                    >
                      <SelectTrigger id={`${network}-priority`} className="mt-1 bg-primary border-border">
                        <SelectValue placeholder="Select priority" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="slow">Slow (Cheaper)</SelectItem>
                        <SelectItem value="average">Average</SelectItem>
                        <SelectItem value="fast">Fast (Recommended)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id={`${network}-custom-gas`}
                      checked={getActiveForm().useCustomGasPrice}
                      onChange={() => toggleCustomGasPrice(network)}
                      className="rounded border-gray-400 bg-primary text-accent focus:ring-accent"
                    />
                    <Label htmlFor={`${network}-custom-gas`} className="text-sm">
                      Use custom gas price
                    </Label>
                  </div>
                  
                  {getActiveForm().useCustomGasPrice && (
                    <div>
                      <Label htmlFor={`${network}-gas-price`}>Custom Gas Price (Gwei)</Label>
                      <Input
                        id={`${network}-gas-price`}
                        type="number"
                        value={getActiveForm().customGasPrice}
                        onChange={(e) => handleCustomGasPriceChange(network, e.target.value)}
                        className="mt-1 bg-primary border-border"
                      />
                    </div>
                  )}
                  
                  <div>
                    <Label htmlFor={`${network}-gas-limit`}>Gas Limit</Label>
                    <Input
                      id={`${network}-gas-limit`}
                      type="number"
                      value={getActiveForm().gasLimit}
                      onChange={(e) => handleGasLimitChange(network, e.target.value)}
                      className="mt-1 bg-primary border-border"
                    />
                  </div>
                </div>
              </div>
              
              <Card className="bg-primary border-border h-fit">
                <CardContent className="p-6">
                  <h4 className="font-medium mb-4">Estimated Transaction Fee</h4>
                  
                  {isLoading ? (
                    <div className="h-32 flex items-center justify-center">
                      <div className="loader"></div>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="flex flex-col items-center mb-6">
                        <div className="text-3xl font-bold mb-2">
                          {calculateGasFee(network).toFixed(6)} {getNetworkToken(network)}
                        </div>
                        <div className="text-lg text-gray-400">
                          ${calculateGasFeeUSD(network).toFixed(2)} USD
                        </div>
                      </div>
                      
                      <div className="space-y-3">
                        <div className="flex justify-between pb-2 border-b border-border">
                          <span className="text-gray-400">Gas Price</span>
                          <span className="font-mono">
                            {getActiveForm().useCustomGasPrice 
                              ? getActiveForm().customGasPrice 
                              : gasData[network as keyof typeof gasData][getActiveForm().priority as keyof typeof gasData.ethereum].price} Gwei
                          </span>
                        </div>
                        
                        <div className="flex justify-between pb-2 border-b border-border">
                          <span className="text-gray-400">Gas Limit</span>
                          <span className="font-mono">{getActiveForm().gasLimit.toLocaleString()} units</span>
                        </div>
                        
                        <div className="flex justify-between pb-2 border-b border-border">
                          <span className="text-gray-400">{getNetworkToken(network)} Price</span>
                          <span className="font-mono">
                            ${network === 'polygon' 
                              ? gasData.polygon.maticPrice.toFixed(2) 
                              : gasData.ethereum.ethPrice.toFixed(2)}
                          </span>
                        </div>
                        
                        <div className="flex justify-between pb-2 border-b border-border">
                          <span className="text-gray-400">Max Fee</span>
                          <span className="font-mono">
                            {(calculateGasFee(network) * 1.1).toFixed(6)} {getNetworkToken(network)}
                          </span>
                        </div>
                      </div>
                      
                      <div className="pt-4 text-sm">
                        <p className="text-gray-400 mb-2">Tips to reduce gas fees:</p>
                        <ul className="list-disc pl-5 space-y-1 text-gray-300">
                          <li>Transact during periods of low network congestion</li>
                          <li>Optimize your smart contract interactions</li>
                          <li>Consider using {network === 'ethereum' ? 'Layer 2 solutions like Arbitrum or Optimism' : 'other networks for certain operations'}</li>
                          <li>Batch multiple transactions when possible</li>
                        </ul>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
};

export default GasFeeEstimator;
