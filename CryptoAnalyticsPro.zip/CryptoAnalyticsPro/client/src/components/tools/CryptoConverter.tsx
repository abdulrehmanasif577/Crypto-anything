import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useLanguage } from '@/hooks/use-language';

const CryptoConverter = () => {
  const { t, isRTL } = useLanguage();
  const [activeTab, setActiveTab] = useState('crypto-to-fiat');
  
  const { data: coins, isLoading: isLoadingCoins } = useQuery({
    queryKey: ['/api/coins/top'],
    staleTime: 300000 // 5 minutes
  });
  
  // Crypto to Fiat conversion state
  const [cryptoToFiat, setCryptoToFiat] = useState({
    fromCoin: '',
    amount: 1,
    toFiat: 'USD',
    result: 0
  });
  
  // Crypto to Crypto conversion state
  const [cryptoToCrypto, setCryptoToCrypto] = useState({
    fromCoin: '',
    amount: 1,
    toCoin: '',
    result: 0
  });
  
  // Fiat currencies
  const fiatCurrencies = [
    { code: 'USD', name: 'US Dollar', symbol: '$' },
    { code: 'EUR', name: 'Euro', symbol: '€' },
    { code: 'GBP', name: 'British Pound', symbol: '£' },
    { code: 'JPY', name: 'Japanese Yen', symbol: '¥' },
    { code: 'AUD', name: 'Australian Dollar', symbol: 'A$' },
    { code: 'CAD', name: 'Canadian Dollar', symbol: 'C$' },
    { code: 'CHF', name: 'Swiss Franc', symbol: 'Fr' },
    { code: 'CNY', name: 'Chinese Yuan', symbol: '¥' },
    { code: 'INR', name: 'Indian Rupee', symbol: '₹' },
    { code: 'AED', name: 'UAE Dirham', symbol: 'د.إ' }
  ];
  
  // Fiat conversion rates to USD (fixed rates for simplicity)
  // In a real app, these would come from an API
  const fiatRates = {
    USD: 1,
    EUR: 0.93,
    GBP: 0.80,
    JPY: 149.5,
    AUD: 1.54,
    CAD: 1.38,
    CHF: 0.90,
    CNY: 7.22,
    INR: 83.34,
    AED: 3.67
  };
  
  // Set initial values once coins are loaded
  useEffect(() => {
    if (coins && coins.length > 1) {
      setCryptoToFiat(prev => ({
        ...prev,
        fromCoin: coins[0].coinId
      }));
      
      setCryptoToCrypto(prev => ({
        ...prev,
        fromCoin: coins[0].coinId,
        toCoin: coins[1].coinId
      }));
    }
  }, [coins]);
  
  // Calculate crypto to fiat conversion
  useEffect(() => {
    if (coins && cryptoToFiat.fromCoin && cryptoToFiat.amount && cryptoToFiat.toFiat) {
      const selectedCoin = coins.find((c: any) => c.coinId === cryptoToFiat.fromCoin);
      if (selectedCoin) {
        // Convert to USD first, then to target fiat
        const usdValue = selectedCoin.currentPrice * cryptoToFiat.amount;
        const fiatValue = usdValue / (fiatRates[cryptoToFiat.toFiat as keyof typeof fiatRates] || 1);
        setCryptoToFiat(prev => ({ ...prev, result: fiatValue }));
      }
    }
  }, [coins, cryptoToFiat.fromCoin, cryptoToFiat.amount, cryptoToFiat.toFiat]);
  
  // Calculate crypto to crypto conversion
  useEffect(() => {
    if (coins && cryptoToCrypto.fromCoin && cryptoToCrypto.amount && cryptoToCrypto.toCoin) {
      const fromCoin = coins.find((c: any) => c.coinId === cryptoToCrypto.fromCoin);
      const toCoin = coins.find((c: any) => c.coinId === cryptoToCrypto.toCoin);
      
      if (fromCoin && toCoin && toCoin.currentPrice) {
        // Convert through USD
        const usdValue = fromCoin.currentPrice * cryptoToCrypto.amount;
        const cryptoValue = usdValue / toCoin.currentPrice;
        setCryptoToCrypto(prev => ({ ...prev, result: cryptoValue }));
      }
    }
  }, [coins, cryptoToCrypto.fromCoin, cryptoToCrypto.amount, cryptoToCrypto.toCoin]);
  
  // Handle input changes for crypto to fiat
  const handleCryptoToFiatChange = (field: string, value: any) => {
    setCryptoToFiat(prev => ({ ...prev, [field]: value }));
  };
  
  // Handle input changes for crypto to crypto
  const handleCryptoToCryptoChange = (field: string, value: any) => {
    setCryptoToCrypto(prev => ({ ...prev, [field]: value }));
  };
  
  // Handle swapping currencies in crypto to crypto
  const handleSwapCryptos = () => {
    setCryptoToCrypto(prev => ({
      ...prev,
      fromCoin: prev.toCoin,
      toCoin: prev.fromCoin,
      amount: prev.result,
      result: prev.amount
    }));
  };
  
  // Get symbol for selected fiat currency
  const getFiatSymbol = (code: string) => {
    const currency = fiatCurrencies.find(c => c.code === code);
    return currency ? currency.symbol : '$';
  };
  
  return (
    <div>
      <h3 className="text-lg font-bold mb-4">Crypto Converter</h3>
      
      <Tabs defaultValue="crypto-to-fiat" value={activeTab} onValueChange={setActiveTab} className="mb-6">
        <TabsList className="w-full">
          <TabsTrigger value="crypto-to-fiat" className="flex-1">Crypto to Fiat</TabsTrigger>
          <TabsTrigger value="crypto-to-crypto" className="flex-1">Crypto to Crypto</TabsTrigger>
        </TabsList>
        
        <TabsContent value="crypto-to-fiat" className="mt-4">
          <Card className="bg-primary border-border">
            <CardContent className="p-4">
              {isLoadingCoins ? (
                <div className="h-40 flex items-center justify-center">
                  <div className="loader"></div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="crypto-amount">Amount</Label>
                      <Input
                        id="crypto-amount"
                        type="number"
                        value={cryptoToFiat.amount}
                        onChange={(e) => handleCryptoToFiatChange('amount', parseFloat(e.target.value) || 0)}
                        className="mt-1 bg-secondary border-border"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="from-crypto">From Cryptocurrency</Label>
                      <Select 
                        value={cryptoToFiat.fromCoin} 
                        onValueChange={(value) => handleCryptoToFiatChange('fromCoin', value)}
                      >
                        <SelectTrigger id="from-crypto" className="mt-1 bg-secondary border-border">
                          <SelectValue placeholder="Select a cryptocurrency" />
                        </SelectTrigger>
                        <SelectContent>
                          {coins && coins.map((coin: any) => (
                            <SelectItem key={coin.coinId} value={coin.coinId}>
                              <div className="flex items-center">
                                <img 
                                  src={coin.image} 
                                  alt={coin.name} 
                                  className="w-5 h-5 mr-2"
                                  onError={(e) => {
                                    e.currentTarget.onerror = null;
                                    e.currentTarget.src = 'https://assets.coingecko.com/coins/images/1/thumb/bitcoin.png';
                                  }}
                                />
                                {coin.name} ({coin.symbol.toUpperCase()})
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div className="flex justify-center">
                    <div className="bg-accent bg-opacity-20 text-accent rounded-full p-2">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="m17 20 4-4-4-4"/>
                        <path d="M3 8h18"/>
                        <path d="m7 4-4 4 4 4"/>
                        <path d="M21 16H3"/>
                      </svg>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="to-fiat">To Fiat Currency</Label>
                      <Select 
                        value={cryptoToFiat.toFiat} 
                        onValueChange={(value) => handleCryptoToFiatChange('toFiat', value)}
                      >
                        <SelectTrigger id="to-fiat" className="mt-1 bg-secondary border-border">
                          <SelectValue placeholder="Select a fiat currency" />
                        </SelectTrigger>
                        <SelectContent>
                          {fiatCurrencies.map((currency) => (
                            <SelectItem key={currency.code} value={currency.code}>
                              {currency.symbol} {currency.name} ({currency.code})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <Label htmlFor="fiat-result">Result</Label>
                      <div className="relative mt-1">
                        <Input
                          id="fiat-result"
                          value={cryptoToFiat.result.toLocaleString(undefined, { 
                            maximumFractionDigits: 4,
                            minimumFractionDigits: 2
                          })}
                          readOnly
                          className="bg-secondary border-border"
                        />
                        <div className="absolute inset-y-0 right-0 flex items-center px-3 pointer-events-none">
                          <span className="text-gray-400">{getFiatSymbol(cryptoToFiat.toFiat)}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-secondary rounded-lg p-4 mt-4 text-sm">
                    <p>
                      <span className="font-medium">Exchange Rate:</span>{' '}
                      {coins && cryptoToFiat.fromCoin ? (
                        <span>
                          1 {coins.find((c: any) => c.coinId === cryptoToFiat.fromCoin)?.symbol.toUpperCase()} = {' '}
                          {(cryptoToFiat.result / cryptoToFiat.amount).toLocaleString(undefined, { 
                            maximumFractionDigits: 4,
                            minimumFractionDigits: 2
                          })} {cryptoToFiat.toFiat}
                        </span>
                      ) : (
                        <span>-</span>
                      )}
                    </p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="crypto-to-crypto" className="mt-4">
          <Card className="bg-primary border-border">
            <CardContent className="p-4">
              {isLoadingCoins ? (
                <div className="h-40 flex items-center justify-center">
                  <div className="loader"></div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="crypto-amount-from">Amount</Label>
                      <Input
                        id="crypto-amount-from"
                        type="number"
                        value={cryptoToCrypto.amount}
                        onChange={(e) => handleCryptoToCryptoChange('amount', parseFloat(e.target.value) || 0)}
                        className="mt-1 bg-secondary border-border"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="from-crypto-2">From Cryptocurrency</Label>
                      <Select 
                        value={cryptoToCrypto.fromCoin} 
                        onValueChange={(value) => handleCryptoToCryptoChange('fromCoin', value)}
                      >
                        <SelectTrigger id="from-crypto-2" className="mt-1 bg-secondary border-border">
                          <SelectValue placeholder="Select a cryptocurrency" />
                        </SelectTrigger>
                        <SelectContent>
                          {coins && coins.map((coin: any) => (
                            <SelectItem key={`from-${coin.coinId}`} value={coin.coinId}>
                              <div className="flex items-center">
                                <img 
                                  src={coin.image} 
                                  alt={coin.name} 
                                  className="w-5 h-5 mr-2"
                                  onError={(e) => {
                                    e.currentTarget.onerror = null;
                                    e.currentTarget.src = 'https://assets.coingecko.com/coins/images/1/thumb/bitcoin.png';
                                  }}
                                />
                                {coin.name} ({coin.symbol.toUpperCase()})
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div className="flex justify-center">
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={handleSwapCryptos}
                      className="bg-accent bg-opacity-20 text-accent border-none hover:bg-accent hover:bg-opacity-30 hover:text-accent"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="m17 3-5 5-5-5"/>
                        <path d="M7 21l5-5 5 5"/>
                        <path d="M12 3v16"/>
                      </svg>
                    </Button>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="to-crypto">To Cryptocurrency</Label>
                      <Select 
                        value={cryptoToCrypto.toCoin} 
                        onValueChange={(value) => handleCryptoToCryptoChange('toCoin', value)}
                      >
                        <SelectTrigger id="to-crypto" className="mt-1 bg-secondary border-border">
                          <SelectValue placeholder="Select a cryptocurrency" />
                        </SelectTrigger>
                        <SelectContent>
                          {coins && coins.map((coin: any) => (
                            <SelectItem key={`to-${coin.coinId}`} value={coin.coinId}>
                              <div className="flex items-center">
                                <img 
                                  src={coin.image} 
                                  alt={coin.name} 
                                  className="w-5 h-5 mr-2"
                                  onError={(e) => {
                                    e.currentTarget.onerror = null;
                                    e.currentTarget.src = 'https://assets.coingecko.com/coins/images/1/thumb/bitcoin.png';
                                  }}
                                />
                                {coin.name} ({coin.symbol.toUpperCase()})
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <Label htmlFor="crypto-result">Result</Label>
                      <div className="relative mt-1">
                        <Input
                          id="crypto-result"
                          value={cryptoToCrypto.result.toLocaleString(undefined, { 
                            maximumFractionDigits: 8,
                            minimumFractionDigits: cryptoToCrypto.result < 0.01 ? 8 : 4
                          })}
                          readOnly
                          className="bg-secondary border-border"
                        />
                        <div className="absolute inset-y-0 right-0 flex items-center px-3 pointer-events-none">
                          <span className="text-gray-400">
                            {coins && cryptoToCrypto.toCoin ? 
                              coins.find((c: any) => c.coinId === cryptoToCrypto.toCoin)?.symbol.toUpperCase() : ''}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-secondary rounded-lg p-4 mt-4 text-sm">
                    <p>
                      <span className="font-medium">Exchange Rate:</span>{' '}
                      {coins && cryptoToCrypto.fromCoin && cryptoToCrypto.toCoin ? (
                        <span>
                          1 {coins.find((c: any) => c.coinId === cryptoToCrypto.fromCoin)?.symbol.toUpperCase()} = {' '}
                          {(cryptoToCrypto.result / cryptoToCrypto.amount).toLocaleString(undefined, { 
                            maximumFractionDigits: 8,
                            minimumFractionDigits: (cryptoToCrypto.result / cryptoToCrypto.amount) < 0.01 ? 8 : 4
                          })} {coins.find((c: any) => c.coinId === cryptoToCrypto.toCoin)?.symbol.toUpperCase()}
                        </span>
                      ) : (
                        <span>-</span>
                      )}
                    </p>
                    <p className="mt-2 text-xs text-gray-400">
                      * Conversion rates are based on current market prices and may vary slightly from actual exchange rates.
                    </p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default CryptoConverter;
