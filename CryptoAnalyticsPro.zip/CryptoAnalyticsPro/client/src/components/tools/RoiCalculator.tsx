import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Slider } from '@/components/ui/slider';
import { useLanguage } from '@/hooks/use-language';

const RoiCalculator = () => {
  const { t, isRTL } = useLanguage();
  
  const { data: coins, isLoading } = useQuery({
    queryKey: ['/api/coins/top'],
    staleTime: 300000 // 5 minutes
  });
  
  const [formData, setFormData] = useState({
    coin: '',
    initialInvestment: 1000,
    investmentDate: getCurrentDateString(),
    exitDate: getDateString(1),
    additionalInvestment: 0,
    frequency: 'none',
    reinvestProfits: false
  });
  
  const [results, setResults] = useState({
    initialCoinAmount: 0,
    finalCoinAmount: 0,
    initialValue: 0,
    finalValue: 0,
    roi: 0,
    roiPercentage: 0,
    annualizedReturn: 0,
    holdingPeriod: 0
  });
  
  // Get today's date in YYYY-MM-DD format
  function getCurrentDateString() {
    const now = new Date();
    return now.toISOString().split('T')[0];
  }
  
  // Get a date X years from now in YYYY-MM-DD format
  function getDateString(yearsFromNow: number) {
    const now = new Date();
    now.setFullYear(now.getFullYear() + yearsFromNow);
    return now.toISOString().split('T')[0];
  }
  
  // Set initial coin once data is loaded
  useEffect(() => {
    if (coins && coins.length > 0 && !formData.coin) {
      setFormData(prev => ({ ...prev, coin: coins[0].coinId }));
    }
  }, [coins, formData.coin]);
  
  // Calculate ROI on form changes
  useEffect(() => {
    calculateROI();
  }, [formData, coins]);
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type } = e.target;
    
    setFormData(prev => ({
      ...prev,
      [name]: type === 'number' ? parseFloat(value) || 0 : value
    }));
  };
  
  const handleSelectChange = (name: string, value: string) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    
    setFormData(prev => ({ ...prev, [name]: checked }));
  };
  
  const calculateROI = () => {
    if (!coins || !formData.coin) return;
    
    const selectedCoin = coins.find((c: any) => c.coinId === formData.coin);
    if (!selectedCoin) return;
    
    const currentPrice = selectedCoin.currentPrice;
    const initialInvestment = formData.initialInvestment;
    
    // Calculate initial coin amount
    const initialCoinAmount = initialInvestment / currentPrice;
    
    // Calculate holding period in years
    const startDate = new Date(formData.investmentDate);
    const endDate = new Date(formData.exitDate);
    const holdingPeriodDays = Math.max(1, (endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
    const holdingPeriodYears = holdingPeriodDays / 365;
    
    // Simulate price growth (for demo purposes - in a real app this would use historical data)
    // Using 10% annual growth for simulated future performance
    const annualGrowthRate = 0.10;
    const projectedPrice = currentPrice * Math.pow(1 + annualGrowthRate, holdingPeriodYears);
    
    // Calculate additional investments (DCA)
    let totalAdditionalInvestment = 0;
    let additionalCoins = 0;
    
    if (formData.additionalInvestment > 0 && formData.frequency !== 'none') {
      let frequency = 0;
      
      // Convert frequency to days
      switch (formData.frequency) {
        case 'daily':
          frequency = 1;
          break;
        case 'weekly':
          frequency = 7;
          break;
        case 'monthly':
          frequency = 30;
          break;
        case 'quarterly':
          frequency = 90;
          break;
        case 'yearly':
          frequency = 365;
          break;
      }
      
      if (frequency > 0) {
        // Calculate number of additional investments
        const numberOfInvestments = Math.floor(holdingPeriodDays / frequency);
        totalAdditionalInvestment = formData.additionalInvestment * numberOfInvestments;
        
        // Simulate buying at average price (simplified)
        const averagePrice = (currentPrice + projectedPrice) / 2;
        additionalCoins = totalAdditionalInvestment / averagePrice;
      }
    }
    
    // Calculate final coin amount and values
    const finalCoinAmount = initialCoinAmount + additionalCoins;
    const finalValue = finalCoinAmount * projectedPrice;
    const totalInvestment = initialInvestment + totalAdditionalInvestment;
    const roi = finalValue - totalInvestment;
    const roiPercentage = (roi / totalInvestment) * 100;
    
    // Calculate annualized return
    const annualizedReturn = Math.pow(finalValue / totalInvestment, 1 / Math.max(holdingPeriodYears, 0.01)) - 1;
    
    setResults({
      initialCoinAmount,
      finalCoinAmount,
      initialValue: initialInvestment,
      finalValue,
      roi,
      roiPercentage,
      annualizedReturn: annualizedReturn * 100,
      holdingPeriod: holdingPeriodYears
    });
  };
  
  return (
    <div>
      <h3 className="text-lg font-bold mb-4">ROI Calculator</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div>
            <Label htmlFor="coin-select">Select Cryptocurrency</Label>
            <Select 
              value={formData.coin} 
              onValueChange={(value) => handleSelectChange('coin', value)}
              disabled={isLoading}
            >
              <SelectTrigger id="coin-select" className="mt-1 bg-primary border-border">
                <SelectValue placeholder="Select a cryptocurrency" />
              </SelectTrigger>
              <SelectContent>
                {coins && coins.map((coin: any) => (
                  <SelectItem key={coin.coinId} value={coin.coinId}>
                    <div className="flex items-center">
                      <img 
                        src={coin.image} 
                        alt={coin.name} 
                        className="w-5 h-5 mr-2"
                        onError={(e) => {
                          e.currentTarget.onerror = null;
                          e.currentTarget.src = 'https://assets.coingecko.com/coins/images/1/thumb/bitcoin.png';
                        }}
                      />
                      {coin.name} ({coin.symbol.toUpperCase()})
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            {!isLoading && coins && formData.coin && (
              <p className="text-sm text-gray-400 mt-1">
                Current price: $
                {coins.find((c: any) => c.coinId === formData.coin)?.currentPrice.toLocaleString(undefined, {
                  maximumFractionDigits: 8
                })}
              </p>
            )}
          </div>
          
          <div>
            <Label htmlFor="initial-investment">Initial Investment (USD)</Label>
            <div className="relative mt-1">
              <Input
                id="initial-investment"
                name="initialInvestment"
                type="number"
                min="0"
                step="100"
                value={formData.initialInvestment}
                onChange={handleInputChange}
                className="bg-primary border-border"
              />
              <div className="absolute inset-y-0 right-0 flex items-center px-3 pointer-events-none">
                <span className="text-gray-400">$</span>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="investment-date">Investment Date</Label>
              <Input
                id="investment-date"
                name="investmentDate"
                type="date"
                value={formData.investmentDate}
                onChange={handleInputChange}
                className="mt-1 bg-primary border-border"
              />
            </div>
            
            <div>
              <Label htmlFor="exit-date">Exit Date</Label>
              <Input
                id="exit-date"
                name="exitDate"
                type="date"
                value={formData.exitDate}
                min={formData.investmentDate}
                onChange={handleInputChange}
                className="mt-1 bg-primary border-border"
              />
            </div>
          </div>
          
          <div>
            <div className="flex justify-between">
              <Label htmlFor="additional-investment">Additional Investment</Label>
              <span className="text-sm text-gray-400">$ {formData.additionalInvestment}</span>
            </div>
            <Slider
              id="additional-investment"
              value={[formData.additionalInvestment]}
              onValueChange={(value) => setFormData(prev => ({ ...prev, additionalInvestment: value[0] }))}
              min={0}
              max={1000}
              step={10}
              className="mt-2"
            />
          </div>
          
          <div>
            <Label>Investment Frequency</Label>
            <RadioGroup 
              value={formData.frequency} 
              onValueChange={(value) => handleSelectChange('frequency', value)}
              className="mt-2 grid grid-cols-2 sm:grid-cols-3 gap-2"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="none" id="none" />
                <Label htmlFor="none" className="cursor-pointer">None</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="daily" id="daily" />
                <Label htmlFor="daily" className="cursor-pointer">Daily</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="weekly" id="weekly" />
                <Label htmlFor="weekly" className="cursor-pointer">Weekly</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="monthly" id="monthly" />
                <Label htmlFor="monthly" className="cursor-pointer">Monthly</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="quarterly" id="quarterly" />
                <Label htmlFor="quarterly" className="cursor-pointer">Quarterly</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="yearly" id="yearly" />
                <Label htmlFor="yearly" className="cursor-pointer">Yearly</Label>
              </div>
            </RadioGroup>
          </div>
        </div>
        
        <Card className="bg-primary border-border h-fit">
          <CardContent className="p-6">
            <h4 className="text-lg font-medium mb-4">ROI Results</h4>
            
            <div className="space-y-4">
              <div className="flex justify-between pb-2 border-b border-border">
                <span className="text-gray-400">Holding Period</span>
                <span>
                  {results.holdingPeriod.toFixed(2)} years ({Math.round(results.holdingPeriod * 365)} days)
                </span>
              </div>
              
              <div className="flex justify-between pb-2 border-b border-border">
                <span className="text-gray-400">Initial Investment</span>
                <span className="font-mono">${formData.initialInvestment.toLocaleString()}</span>
              </div>
              
              {formData.additionalInvestment > 0 && formData.frequency !== 'none' && (
                <div className="flex justify-between pb-2 border-b border-border">
                  <span className="text-gray-400">Additional Investments</span>
                  <span className="font-mono">
                    ${(formData.additionalInvestment * Math.floor(results.holdingPeriod * 365 / 
                      (formData.frequency === 'daily' ? 1 : 
                       formData.frequency === 'weekly' ? 7 : 
                       formData.frequency === 'monthly' ? 30 : 
                       formData.frequency === 'quarterly' ? 90 : 365))).toLocaleString()}
                  </span>
                </div>
              )}
              
              <div className="flex justify-between pb-2 border-b border-border">
                <span className="text-gray-400">Total Investment</span>
                <span className="font-mono font-medium">
                  ${(results.initialValue + 
                    (formData.additionalInvestment * Math.floor(results.holdingPeriod * 365 / 
                      (formData.frequency === 'daily' ? 1 : 
                       formData.frequency === 'weekly' ? 7 : 
                       formData.frequency === 'monthly' ? 30 : 
                       formData.frequency === 'quarterly' ? 90 : 
                       formData.frequency === 'yearly' ? 365 : Infinity)))).toLocaleString()}
                </span>
              </div>
              
              <div className="flex justify-between pb-2 border-b border-border">
                <span className="text-gray-400">Final Value</span>
                <span className="font-mono">${results.finalValue.toLocaleString(undefined, { maximumFractionDigits: 2 })}</span>
              </div>
              
              <div className="flex justify-between pb-2 border-b border-border">
                <span className="text-gray-400">Profit / Loss</span>
                <span className={`font-mono ${results.roi >= 0 ? 'text-success' : 'text-danger'}`}>
                  {results.roi >= 0 ? '+' : ''}{results.roi.toLocaleString(undefined, { maximumFractionDigits: 2 })} USD
                </span>
              </div>
              
              <div className="flex justify-between pb-2 border-b border-border">
                <span className="text-gray-400">ROI Percentage</span>
                <span className={`font-mono ${results.roiPercentage >= 0 ? 'text-success' : 'text-danger'}`}>
                  {results.roiPercentage >= 0 ? '+' : ''}{results.roiPercentage.toFixed(2)}%
                </span>
              </div>
              
              <div className="flex justify-between pb-2 border-b border-border">
                <span className="text-gray-400">Annualized Return</span>
                <span className={`font-mono ${results.annualizedReturn >= 0 ? 'text-success' : 'text-danger'}`}>
                  {results.annualizedReturn >= 0 ? '+' : ''}{results.annualizedReturn.toFixed(2)}% per year
                </span>
              </div>
              
              <div className="flex justify-between pb-2 border-b border-border">
                <span className="text-gray-400">Coin Amount</span>
                <span className="font-mono">
                  {results.finalCoinAmount.toLocaleString(undefined, { 
                    maximumFractionDigits: 8,
                    minimumFractionDigits: results.finalCoinAmount < 1 ? 8 : 2
                  })}
                </span>
              </div>
              
              <div className="text-center mt-6 text-xs text-gray-400">
                <p>* This calculator provides estimates based on projected growth and does not guarantee future returns.</p>
                <p className="mt-1">Historical performance is not indicative of future results.</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default RoiCalculator;
