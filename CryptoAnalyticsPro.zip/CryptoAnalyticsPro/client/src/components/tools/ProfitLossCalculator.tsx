import { useState, useEffect, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';
import { useLanguage } from '@/hooks/use-language';

// Define currency symbols and conversion rates
const CURRENCIES = {
  USD: { symbol: '$', name: 'USD', rate: 1 },
  EUR: { symbol: '€', name: 'EUR', rate: 0.93 },
  AED: { symbol: 'د.إ', name: 'AED', rate: 3.67 }
};

type Currency = 'USD' | 'EUR' | 'AED';

interface ProfitLossCalculatorProps {
  className?: string;
}

const ProfitLossCalculator = ({ className }: ProfitLossCalculatorProps) => {
  const { t, isRTL } = useLanguage();
  const { toast } = useToast();
  const resultCardRef = useRef<HTMLDivElement>(null);
  
  // Fetch cryptocurrency data
  const { data: coins = [], isLoading } = useQuery<any[]>({
    queryKey: ['/api/coins/top'],
    staleTime: 300000 // 5 minutes
  });

  // State for form data and results
  const [formData, setFormData] = useState({
    coin: 'bitcoin',
    investmentAmount: 1000,
    entryPrice: 0,
    exitPrice: 0,
    coinQuantity: 0,
    tradingFee: 0.1, // Default 0.1% trading fee
    manualCoinInput: false // Toggle between investment amount and coin quantity
  });
  
  const [selectedCurrency, setSelectedCurrency] = useState<Currency>('USD');
  const [showAdvanced, setShowAdvanced] = useState(false);
  
  const [results, setResults] = useState({
    coinsAmount: 0,
    initialValue: 0,
    currentValue: 0,
    profitLoss: 0,
    profitLossPercentage: 0,
    feeAmount: 0,
    finalValue: 0
  });

  // Update entry price when coin changes
  useEffect(() => {
    if (coins && coins.length > 0) {
      const selectedCoin = coins.find((c: any) => c.coinId === formData.coin) || coins[0];
      if (selectedCoin) {
        setFormData(prev => ({
          ...prev,
          entryPrice: selectedCoin.currentPrice,
          exitPrice: selectedCoin.currentPrice * 1.1, // Default 10% higher
          coin: selectedCoin.coinId
        }));
      }
    }
  }, [coins, formData.coin]);

  // Calculate immediately when the form changes
  useEffect(() => {
    calculate();
  }, [formData, selectedCurrency]);

  // Handle input changes with validation
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    
    // Validate to prevent negative numbers
    if (parseFloat(value) < 0) return;
    
    setFormData(prev => ({
      ...prev,
      [name]: value === '' ? 0 : parseFloat(value)
    }));
  };

  // Handle select changes
  const handleCoinChange = (value: string) => {
    setFormData(prev => ({
      ...prev,
      coin: value
    }));
  };

  // Handle currency change
  const handleCurrencyChange = (value: Currency) => {
    setSelectedCurrency(value);
  };

  // Handle fee slider change
  const handleFeeChange = (value: number[]) => {
    setFormData(prev => ({
      ...prev,
      tradingFee: value[0]
    }));
  };

  // Toggle between investment amount and coin quantity input
  const toggleInputMode = () => {
    setFormData(prev => ({
      ...prev,
      manualCoinInput: !prev.manualCoinInput
    }));
  };

  // Copy results to clipboard
  const copyResults = () => {
    const curr = CURRENCIES[selectedCurrency];
    const text = `
Crypto Profit/Loss Calculation:
Coin: ${coins?.find((c: any) => c.coinId === formData.coin)?.name} (${coins?.find((c: any) => c.coinId === formData.coin)?.symbol.toUpperCase()})
Coins Purchased: ${results.coinsAmount.toFixed(8)}
Entry Price: ${curr.symbol}${(formData.entryPrice * curr.rate).toFixed(2)}
Exit Price: ${curr.symbol}${(formData.exitPrice * curr.rate).toFixed(2)}
Initial Investment: ${curr.symbol}${(results.initialValue * curr.rate).toFixed(2)}
Trading Fee: ${formData.tradingFee}% (${curr.symbol}${(results.feeAmount * curr.rate).toFixed(2)})
Final Value: ${curr.symbol}${(results.finalValue * curr.rate).toFixed(2)}
Profit/Loss: ${results.profitLoss >= 0 ? '+' : ''}${curr.symbol}${(results.profitLoss * curr.rate).toFixed(2)} (${results.profitLossPercentage >= 0 ? '+' : ''}${results.profitLossPercentage.toFixed(2)}%)
`;
    
    navigator.clipboard.writeText(text).then(() => {
      toast({
        title: "Copied to clipboard",
        description: "Results have been copied to clipboard",
      });
    });
  };

  // Calculate profit/loss
  const calculate = () => {
    const { investmentAmount, entryPrice, exitPrice, tradingFee, coinQuantity, manualCoinInput } = formData;
    
    if (entryPrice <= 0) return;
    if (manualCoinInput && coinQuantity <= 0) return;
    if (!manualCoinInput && investmentAmount <= 0) return;
    
    // Calculate coins amount based on input mode
    const coinsAmount = manualCoinInput 
      ? coinQuantity 
      : investmentAmount / entryPrice;
    
    // Calculate initial investment value
    const initialValue = manualCoinInput 
      ? coinsAmount * entryPrice 
      : investmentAmount;
    
    // Calculate sell value before fees
    const sellValueBeforeFees = coinsAmount * exitPrice;
    
    // Calculate trading fees
    const entryFee = initialValue * (tradingFee / 100);
    const exitFee = sellValueBeforeFees * (tradingFee / 100);
    const totalFee = entryFee + exitFee;
    
    // Final value after fees
    const finalValue = sellValueBeforeFees - exitFee;
    
    // Calculate profit/loss
    const profitLoss = finalValue - initialValue - entryFee;
    const profitLossPercentage = (profitLoss / initialValue) * 100;
    
    setResults({
      coinsAmount,
      initialValue,
      currentValue: sellValueBeforeFees,
      profitLoss,
      profitLossPercentage,
      feeAmount: totalFee,
      finalValue
    });
    
    // Update coin quantity in form data if calculating from investment amount
    if (!manualCoinInput) {
      setFormData(prev => ({
        ...prev,
        coinQuantity: coinsAmount
      }));
    }
  };

  // Convert USD amount to selected currency
  const formatCurrency = (amount: number) => {
    const currency = CURRENCIES[selectedCurrency];
    return `${currency.symbol}${(amount * currency.rate).toFixed(2)}`;
  };

  return (
    <div className={`${className}`}>
      <Card className="bg-secondary border-border">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
            <h3 className="text-xl font-bold">Crypto Profit/Loss Calculator</h3>
            
            <div className="flex items-center space-x-2">
              {Object.entries(CURRENCIES).map(([code, currency]) => (
                <Button 
                  key={code}
                  variant={selectedCurrency === code ? "default" : "outline"}
                  size="sm"
                  onClick={() => handleCurrencyChange(code as Currency)}
                  className="min-w-[50px]"
                >
                  {currency.symbol} {code}
                </Button>
              ))}
            </div>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Input Form Section */}
            <div className="space-y-6">
              <div className="space-y-4">
                <div>
                  <Label className="text-sm text-gray-400 mb-2 block">Select Cryptocurrency</Label>
                  <Select value={formData.coin} onValueChange={handleCoinChange}>
                    <SelectTrigger className="w-full bg-primary border border-border">
                      <SelectValue placeholder="Select a cryptocurrency" />
                    </SelectTrigger>
                    <SelectContent className="max-h-[300px]">
                      {isLoading ? (
                        <div className="p-2 text-center">Loading coins...</div>
                      ) : (
                        coins && coins.map((coin: any) => (
                          <SelectItem key={coin.coinId} value={coin.coinId}>
                            <div className="flex items-center">
                              <img 
                                src={coin.image} 
                                alt={coin.name} 
                                className="w-5 h-5 mr-2"
                                onError={(e) => {
                                  e.currentTarget.onerror = null;
                                  e.currentTarget.src = 'https://assets.coingecko.com/coins/images/1/thumb/bitcoin.png';
                                }}
                              />
                              {coin.name} ({coin.symbol.toUpperCase()})
                            </div>
                          </SelectItem>
                        ))
                      )}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex items-center justify-between">
                  <Label className="text-sm text-gray-400">
                    {formData.manualCoinInput ? "Enter Coin Amount" : "Enter Investment Amount"}
                  </Label>
                  <div className="flex items-center space-x-2">
                    <Label className="text-xs text-gray-400">
                      {formData.manualCoinInput ? "Coin Amount" : "Investment"}
                    </Label>
                    <Switch 
                      checked={formData.manualCoinInput}
                      onCheckedChange={toggleInputMode}
                    />
                  </div>
                </div>
                
                {formData.manualCoinInput ? (
                  <div className="relative">
                    <Input
                      type="number"
                      placeholder="Amount of coins"
                      name="coinQuantity"
                      value={formData.coinQuantity}
                      onChange={handleInputChange}
                      className="w-full bg-primary border border-border"
                    />
                    <div className="absolute inset-y-0 right-0 flex items-center px-3 pointer-events-none">
                      <span className="text-gray-400">
                        {coins && coins.find((c: any) => c.coinId === formData.coin)?.symbol.toUpperCase()}
                      </span>
                    </div>
                  </div>
                ) : (
                  <div className="relative">
                    <Input
                      type="number"
                      placeholder="Investment amount"
                      name="investmentAmount"
                      value={formData.investmentAmount}
                      onChange={handleInputChange}
                      className="w-full bg-primary border border-border"
                    />
                    <div className="absolute inset-y-0 right-0 flex items-center px-3 pointer-events-none">
                      <span className="text-gray-400">{selectedCurrency}</span>
                    </div>
                  </div>
                )}
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm text-gray-400 mb-2 block">Entry Price</Label>
                  <div className="relative">
                    <Input
                      type="number"
                      placeholder="Entry price"
                      name="entryPrice"
                      value={formData.entryPrice}
                      onChange={handleInputChange}
                      className="w-full bg-primary border border-border"
                    />
                    <div className="absolute inset-y-0 right-0 flex items-center px-3 pointer-events-none">
                      <span className="text-gray-400">{CURRENCIES[selectedCurrency].symbol}</span>
                    </div>
                  </div>
                </div>
                
                <div>
                  <Label className="text-sm text-gray-400 mb-2 block">Exit Price</Label>
                  <div className="relative">
                    <Input
                      type="number"
                      placeholder="Exit price"
                      name="exitPrice"
                      value={formData.exitPrice}
                      onChange={handleInputChange}
                      className="w-full bg-primary border border-border"
                    />
                    <div className="absolute inset-y-0 right-0 flex items-center px-3 pointer-events-none">
                      <span className="text-gray-400">{CURRENCIES[selectedCurrency].symbol}</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div>
                <div className="flex items-center justify-between mb-2">
                  <Label className="text-sm text-gray-400 cursor-pointer" onClick={() => setShowAdvanced(!showAdvanced)}>
                    Advanced Options
                  </Label>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setShowAdvanced(!showAdvanced)}
                    className="h-6 px-2"
                  >
                    {showAdvanced ? "Hide" : "Show"}
                  </Button>
                </div>
                
                {showAdvanced && (
                  <div className="bg-primary rounded-md p-4 border border-border">
                    <div className="mb-4">
                      <div className="flex justify-between items-center mb-2">
                        <Label className="text-sm text-gray-400">Trading Fee (%)</Label>
                        <span className="text-sm font-mono bg-secondary px-2 py-1 rounded">
                          {formData.tradingFee}%
                        </span>
                      </div>
                      <Slider
                        defaultValue={[formData.tradingFee]}
                        max={5}
                        step={0.05}
                        onValueChange={handleFeeChange}
                        className="py-2"
                      />
                      <div className="flex justify-between text-xs text-gray-400 mt-1">
                        <span>0%</span>
                        <span>2.5%</span>
                        <span>5%</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
            
            {/* Results Section */}
            <div 
              ref={resultCardRef}
              className="bg-primary rounded-lg border border-border p-6 shadow-lg"
            >
              <div className="flex justify-between items-center mb-4">
                <h4 className="font-medium">Results</h4>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={copyResults}
                  className="text-xs h-7 px-2"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                    <rect width="14" height="14" x="8" y="8" rx="2" ry="2" />
                    <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2" />
                  </svg>
                  Copy
                </Button>
              </div>
              
              <div className="space-y-4">
                {/* Primary Result */}
                <div 
                  className={`rounded-lg p-4 ${
                    results.profitLoss >= 0 
                      ? 'bg-success/10 border border-success/30' 
                      : 'bg-danger/10 border border-danger/30'
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <span className="text-gray-300">Profit/Loss</span>
                    <div className="text-right">
                      <div className={`text-xl font-bold ${
                        results.profitLoss >= 0 ? 'text-success' : 'text-danger'
                      }`}>
                        {results.profitLoss >= 0 ? '+' : ''}{formatCurrency(results.profitLoss)}
                      </div>
                      <div className={`text-sm ${
                        results.profitLossPercentage >= 0 ? 'text-success' : 'text-danger'
                      }`}>
                        {results.profitLossPercentage >= 0 ? (
                          <span className="flex items-center justify-end">
                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                              <path d="m18 15-6-6-6 6"/>
                            </svg>
                            {results.profitLossPercentage.toFixed(2)}%
                          </span>
                        ) : (
                          <span className="flex items-center justify-end">
                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                              <path d="m6 9 6 6 6-6"/>
                            </svg>
                            {Math.abs(results.profitLossPercentage).toFixed(2)}%
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Detailed Results */}
                <div className="space-y-3">
                  <div className="flex justify-between items-center pb-3 border-b border-border">
                    <span className="text-gray-400">Coins Purchased</span>
                    <span className="font-mono">
                      {results.coinsAmount.toFixed(8)} {coins && coins.find((c: any) => c.coinId === formData.coin)?.symbol.toUpperCase()}
                    </span>
                  </div>
                  
                  <div className="flex justify-between items-center pb-3 border-b border-border">
                    <span className="text-gray-400">Entry Price per Coin</span>
                    <span className="font-mono">{formatCurrency(formData.entryPrice)}</span>
                  </div>
                  
                  <div className="flex justify-between items-center pb-3 border-b border-border">
                    <span className="text-gray-400">Exit Price per Coin</span>
                    <span className="font-mono">{formatCurrency(formData.exitPrice)}</span>
                  </div>
                  
                  <div className="flex justify-between items-center pb-3 border-b border-border">
                    <span className="text-gray-400">Initial Investment</span>
                    <span className="font-mono">{formatCurrency(results.initialValue)}</span>
                  </div>
                  
                  <div className="flex justify-between items-center pb-3 border-b border-border">
                    <span className="text-gray-400">Trading Fee ({formData.tradingFee}%)</span>
                    <span className="font-mono">{formatCurrency(results.feeAmount)}</span>
                  </div>
                  
                  <div className="flex justify-between items-center pb-3 border-b border-border">
                    <span className="text-gray-400">Final Value (After Fees)</span>
                    <span className="font-mono">{formatCurrency(results.finalValue)}</span>
                  </div>
                </div>
                
                {/* Visual Indicator */}
                <div className="mt-4">
                  <div className="bg-secondary rounded-full h-5 overflow-hidden border border-border">
                    <div 
                      className={`h-full ${results.profitLossPercentage >= 0 
                        ? 'bg-gradient-to-r from-accent to-success' 
                        : 'bg-gradient-to-r from-danger to-orange-600'}`} 
                      style={{ 
                        width: `${Math.min(Math.max(Math.abs(results.profitLossPercentage), 2), 100)}%`,
                        transition: 'width 0.5s ease-in-out'
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ProfitLossCalculator;
