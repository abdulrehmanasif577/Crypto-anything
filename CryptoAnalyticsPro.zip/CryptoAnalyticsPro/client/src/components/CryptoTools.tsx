import { Link } from "wouter";

const CryptoTools = () => {
  const tools = [
    {
      icon: "calculator",
      title: "Profit/Loss Calculator",
      description: "Calculate your crypto investment returns in real-time.",
      color: "blue-500",
      url: "/tools/profit-loss"
    },
    {
      icon: "exchange-alt",
      title: "Crypto Converter",
      description: "Convert between crypto and fiat currencies instantly.",
      color: "green-500",
      url: "/tools/converter" 
    },
    {
      icon: "chart-line",
      title: "ROI Calculator",
      description: "Track Return on Investment for your crypto portfolio.",
      color: "purple-500",
      url: "/tools/roi"
    },
    {
      icon: "gas-pump",
      title: "Gas Fee Estimator",
      description: "Check current Ethereum gas fees and optimize transactions.",
      color: "amber-500",
      url: "/tools/gas-fees"
    }
  ];
  
  const getIcon = (name: string) => {
    switch (name) {
      case 'calculator':
        return (
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <rect width="16" height="20" x="4" y="2" rx="2"/>
            <line x1="8" x2="16" y1="6" y2="6"/>
            <line x1="16" x2="16" y1="14" y2="18"/>
            <path d="M16 10h.01"/>
            <path d="M12 10h.01"/>
            <path d="M8 10h.01"/>
            <path d="M12 14h.01"/>
            <path d="M8 14h.01"/>
            <path d="M12 18h.01"/>
            <path d="M8 18h.01"/>
          </svg>
        );
      case 'exchange-alt':
        return (
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="m17 20 4-4-4-4"/>
            <path d="M3 8h18"/>
            <path d="m7 4-4 4 4 4"/>
            <path d="M21 16H3"/>
          </svg>
        );
      case 'chart-line':
        return (
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21 21H4.6a2.6 2.6 0 0 1-2.6-2.6V3"/>
            <path d="m6 16 6-8 6 8"/>
            <path d="M12 8v8"/>
          </svg>
        );
      case 'gas-pump':
        return (
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M10 8V5a2 2 0 0 1 2-2h6.5L22 6.5V16a2 2 0 0 1-2 2h-1"/>
            <path d="M8 5v10"/>
            <path d="M2 12a4 4 0 0 1 4-4h8"/>
            <path d="M6 16h4"/>
            <circle cx="6" cy="15" r="3"/>
          </svg>
        );
      default:
        return (
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="12" r="10"/>
            <path d="M12 8v4l3 3"/>
          </svg>
        );
    }
  };
  
  return (
    <div className="mb-8">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold">Crypto Tools</h2>
        <Link href="/tools" className="text-sm text-accent hover:underline">
          View All Tools 
          <svg xmlns="http://www.w3.org/2000/svg" className="inline ml-1" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M5 12h14"/>
            <path d="m12 5 7 7-7 7"/>
          </svg>
        </Link>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {tools.map((tool) => (
          <Link key={tool.title} href={tool.url} className="bg-secondary rounded-lg p-4 border border-border card">
            <div className={`flex items-center justify-center h-12 w-12 rounded-full bg-${tool.color} bg-opacity-20 text-${tool.color} mb-4`}>
              {getIcon(tool.icon)}
            </div>
            <h3 className="font-medium mb-2">{tool.title}</h3>
            <p className="text-gray-400 text-sm">{tool.description}</p>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default CryptoTools;
