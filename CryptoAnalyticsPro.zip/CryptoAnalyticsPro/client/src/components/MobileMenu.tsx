import { Link, useLocation } from "wouter";
import { useEffect } from "react";
import { useLanguage } from "../hooks/use-language";

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

const MobileMenu = ({ isOpen, onClose }: MobileMenuProps) => {
  const [location] = useLocation();
  const { currentLanguage, changeLanguage } = useLanguage();
  
  // Close menu when route changes
  useEffect(() => {
    onClose();
  }, [location, onClose]);
  
  // Prevent scrolling when menu is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);
  
  if (!isOpen) return null;
  
  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-50 z-50"
      onClick={onClose}
    >
      <div 
        className={`bg-secondary h-full w-3/4 max-w-xs p-5 transform transition-transform duration-300 ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}
        onClick={e => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-6">
          <span className="text-accent text-xl font-bold">Market<span className="text-white">Pro</span></span>
          <button 
            onClick={onClose} 
            className="text-gray-400 hover:text-white"
            aria-label="Close menu"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M18 6 6 18"/>
              <path d="m6 6 12 12"/>
            </svg>
          </button>
        </div>
        
        <nav className="flex flex-col space-y-4 text-gray-300">
          <Link href="/" className={`py-2 px-3 rounded-md ${location === '/' ? 'bg-primary bg-opacity-50 text-white' : 'hover:bg-primary hover:bg-opacity-50'}`}>
            Dashboard
          </Link>
          <Link href="/charts" className={`py-2 px-3 rounded-md ${location === '/charts' ? 'bg-primary bg-opacity-50 text-white' : 'hover:bg-primary hover:bg-opacity-50'}`}>
            Charts
          </Link>

          <Link href="/analytics" className={`py-2 px-3 rounded-md ${location === '/analytics' ? 'bg-primary bg-opacity-50 text-white' : 'hover:bg-primary hover:bg-opacity-50'}`}>
            Analytics
          </Link>
          <Link href="/learn" className={`py-2 px-3 rounded-md ${location === '/learn' ? 'bg-primary bg-opacity-50 text-white' : 'hover:bg-primary hover:bg-opacity-50'}`}>
            Learn
          </Link>
          <Link href="/about" className={`py-2 px-3 rounded-md ${location === '/about' ? 'bg-primary bg-opacity-50 text-white' : 'hover:bg-primary hover:bg-opacity-50'}`}>
            About
          </Link>
        </nav>
        
        <div className="mt-6 pt-6 border-t border-border">
          <button 
            className="flex items-center space-x-2 text-gray-300 py-2 px-3 rounded-md hover:bg-primary hover:bg-opacity-50 w-full"
            onClick={() => changeLanguage(currentLanguage === 'en' ? 'ar' : 'en')}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="10"/>
              <path d="m2 12 20 0"/>
              <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>
            </svg>
            <span>Language: <span>{currentLanguage === 'en' ? 'English' : 'العربية'}</span></span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default MobileMenu;
