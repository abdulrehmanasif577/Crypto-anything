import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';

const MarketInsights = () => {
  const [activePair, setActivePair] = useState('BTCUSD');
  const [activeTimeframe, setActiveTimeframe] = useState('4H');
  
  const { data: topPerformers, isLoading: loadingPerformers } = useQuery({
    queryKey: ['/api/coins/top'],
    staleTime: 300000 // 5 minutes
  });
  
  // Chart will be a TradingView widget
  useEffect(() => {
    if (typeof window.TradingView === 'undefined') {
      const script = document.createElement('script');
      script.src = 'https://s3.tradingview.com/tv.js';
      script.async = true;
      script.onload = initChart;
      document.head.appendChild(script);
      
      return () => {
        document.head.removeChild(script);
      };
    } else {
      initChart();
    }
  }, [activePair, activeTimeframe]);
  
  function initChart() {
    if (typeof window.TradingView !== 'undefined' && document.getElementById('tradingview_chart')) {
      new window.TradingView.widget({
        autosize: true,
        symbol: `BINANCE:${activePair}`,
        interval: activeTimeframe === '1H' ? '60' : 
                  activeTimeframe === '4H' ? '240' : 
                  activeTimeframe === '1D' ? 'D' : 
                  activeTimeframe === '1W' ? 'W' : 'M',
        theme: 'dark',
        style: '1',
        toolbar_bg: '#111417',
        enable_publishing: false,
        hide_top_toolbar: false,
        hide_legend: false,
        container_id: 'tradingview_chart',
        withdateranges: true,
        allow_symbol_change: true,
        save_image: false,
        timezone: 'exchange',
      });
    }
  }
  
  const topGainers = topPerformers?.filter((coin: any) => coin.priceChangePercentage24h > 0)
    .sort((a: any, b: any) => b.priceChangePercentage24h - a.priceChangePercentage24h)
    .slice(0, 2);
    
  const topLosers = topPerformers?.filter((coin: any) => coin.priceChangePercentage24h < 0)
    .sort((a: any, b: any) => a.priceChangePercentage24h - b.priceChangePercentage24h)
    .slice(0, 2);
  
  const trendingSearches = ['Bitcoin ETF', 'Memecoin', 'Layer 2', 'Solana', 'NFT', 'DeFi'];
  
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
      <div className="lg:col-span-2">
        <div className="bg-secondary rounded-lg border border-border p-4 h-full">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-bold">Featured Chart</h2>
            <div className="flex space-x-2">
              <button 
                className={`px-3 py-1 text-xs rounded-md ${activePair === 'BTCUSD' ? 'bg-accent' : 'bg-primary hover:bg-accent transition-colors'}`}
                onClick={() => setActivePair('BTCUSD')}
              >
                BTC/USD
              </button>
              <button 
                className={`px-3 py-1 text-xs rounded-md ${activePair === 'ETHUSD' ? 'bg-accent' : 'bg-primary hover:bg-accent transition-colors'}`}
                onClick={() => setActivePair('ETHUSD')}
              >
                ETH/USD
              </button>
              <button 
                className={`px-3 py-1 text-xs rounded-md ${activePair === 'BNBUSD' ? 'bg-accent' : 'bg-primary hover:bg-accent transition-colors'}`}
                onClick={() => setActivePair('BNBUSD')}
              >
                BNB/USD
              </button>
            </div>
          </div>
          
          <div className="relative rounded-lg overflow-hidden bg-primary h-80 flex items-center justify-center">
            <div id="tradingview_chart" className="absolute inset-0 w-full h-full"></div>
            
            {/* Loading state */}
            <div className="text-center z-10">
              <div className="mb-4">
                <div className="mx-auto loader"></div>
              </div>
              <p className="text-gray-400">Loading TradingView Chart...</p>
              <p className="text-xs text-gray-500 mt-2">{activePair} • {activeTimeframe} Timeframe</p>
            </div>
          </div>
          
          <div className="flex justify-center space-x-2 mt-4">
            <button 
              className={`px-3 py-1 text-xs rounded-md ${activeTimeframe === '1H' ? 'bg-accent' : 'bg-primary hover:bg-accent transition-colors'}`}
              onClick={() => setActiveTimeframe('1H')}
            >
              1H
            </button>
            <button 
              className={`px-3 py-1 text-xs rounded-md ${activeTimeframe === '4H' ? 'bg-accent' : 'bg-primary hover:bg-accent transition-colors'}`}
              onClick={() => setActiveTimeframe('4H')}
            >
              4H
            </button>
            <button 
              className={`px-3 py-1 text-xs rounded-md ${activeTimeframe === '1D' ? 'bg-accent' : 'bg-primary hover:bg-accent transition-colors'}`}
              onClick={() => setActiveTimeframe('1D')}
            >
              1D
            </button>
            <button 
              className={`px-3 py-1 text-xs rounded-md ${activeTimeframe === '1W' ? 'bg-accent' : 'bg-primary hover:bg-accent transition-colors'}`}
              onClick={() => setActiveTimeframe('1W')}
            >
              1W
            </button>
            <button 
              className={`px-3 py-1 text-xs rounded-md ${activeTimeframe === '1M' ? 'bg-accent' : 'bg-primary hover:bg-accent transition-colors'}`}
              onClick={() => setActiveTimeframe('1M')}
            >
              1M
            </button>
          </div>
        </div>
      </div>
      
      <div>
        <div className="bg-secondary rounded-lg border border-border p-4 h-full">
          <h2 className="text-lg font-bold mb-4">Top Performers</h2>
          
          <div className="space-y-4">
            <div>
              <h3 className="text-sm text-gray-400 mb-2">Top Gainers (24h)</h3>
              <div className="space-y-3">
                {loadingPerformers ? (
                  Array(2).fill(0).map((_, i) => (
                    <div key={i} className="flex items-center justify-between p-2 rounded bg-primary animate-pulse">
                      <div className="flex items-center">
                        <div className="w-6 h-6 bg-muted rounded-full mr-2"></div>
                        <div>
                          <div className="h-4 bg-muted rounded w-20 mb-1"></div>
                          <div className="h-3 bg-muted rounded w-10"></div>
                        </div>
                      </div>
                      <div className="h-4 bg-muted rounded w-16"></div>
                    </div>
                  ))
                ) : (
                  topGainers?.map((coin: any) => (
                    <div key={coin.id} className="flex items-center justify-between p-2 rounded bg-primary">
                      <div className="flex items-center">
                        <img 
                          src={coin.image} 
                          alt={coin.name} 
                          className="w-6 h-6 mr-2"
                          onError={(e) => {
                            e.currentTarget.onerror = null;
                            e.currentTarget.src = 'https://assets.coingecko.com/coins/images/1/thumb/bitcoin.png';
                          }}
                        />
                        <div>
                          <div className="font-medium">{coin.name}</div>
                          <div className="text-gray-400 text-xs">{coin.symbol.toUpperCase()}</div>
                        </div>
                      </div>
                      <div className="text-success font-medium">+{coin.priceChangePercentage24h.toFixed(1)}%</div>
                    </div>
                  ))
                )}
              </div>
            </div>
            
            <div>
              <h3 className="text-sm text-gray-400 mb-2">Top Losers (24h)</h3>
              <div className="space-y-3">
                {loadingPerformers ? (
                  Array(2).fill(0).map((_, i) => (
                    <div key={i} className="flex items-center justify-between p-2 rounded bg-primary animate-pulse">
                      <div className="flex items-center">
                        <div className="w-6 h-6 bg-muted rounded-full mr-2"></div>
                        <div>
                          <div className="h-4 bg-muted rounded w-20 mb-1"></div>
                          <div className="h-3 bg-muted rounded w-10"></div>
                        </div>
                      </div>
                      <div className="h-4 bg-muted rounded w-16"></div>
                    </div>
                  ))
                ) : (
                  topLosers?.map((coin: any) => (
                    <div key={coin.id} className="flex items-center justify-between p-2 rounded bg-primary">
                      <div className="flex items-center">
                        <img 
                          src={coin.image} 
                          alt={coin.name} 
                          className="w-6 h-6 mr-2"
                          onError={(e) => {
                            e.currentTarget.onerror = null;
                            e.currentTarget.src = 'https://assets.coingecko.com/coins/images/1/thumb/bitcoin.png';
                          }}
                        />
                        <div>
                          <div className="font-medium">{coin.name}</div>
                          <div className="text-gray-400 text-xs">{coin.symbol.toUpperCase()}</div>
                        </div>
                      </div>
                      <div className="text-danger font-medium">{coin.priceChangePercentage24h.toFixed(1)}%</div>
                    </div>
                  ))
                )}
              </div>
            </div>
            
            <div>
              <h3 className="text-sm text-gray-400 mb-2">Trending Searches</h3>
              <div className="flex flex-wrap gap-2">
                {trendingSearches.map((term) => (
                  <span key={term} className="px-2 py-1 bg-primary rounded-full text-xs">{term}</span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

declare global {
  interface Window {
    TradingView: any;
  }
}

export default MarketInsights;
