import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import Sparkline from "./ui/sparkline";

const TopCoins = () => {
  const { data: coins, isLoading, error } = useQuery({
    queryKey: ['/api/coins'],
    staleTime: 60000 // 1 minute
  });
  
  if (isLoading) {
    return (
      <div className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold">Top Cryptocurrencies</h2>
          <Link to="/markets" className="text-sm text-accent hover:underline">
            View All 
            <svg xmlns="http://www.w3.org/2000/svg" className="inline ml-1" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M5 12h14"/>
              <path d="m12 5 7 7-7 7"/>
            </svg>
          </Link>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-gray-400 border-b border-border">
                <th className="pb-3 text-left pl-4">#</th>
                <th className="pb-3 text-left">Coin</th>
                <th className="pb-3 text-right">Price</th>
                <th className="pb-3 text-right">24h</th>
                <th className="pb-3 text-right">7d</th>
                <th className="pb-3 text-right">Market Cap</th>
                <th className="pb-3 text-right pr-4">Last 7 Days</th>
              </tr>
            </thead>
            <tbody>
              {[1, 2, 3, 4, 5].map((i) => (
                <tr key={i} className="border-b border-border animate-pulse">
                  <td className="py-4 pl-4">{i}</td>
                  <td className="py-4">
                    <div className="flex items-center">
                      <div className="w-6 h-6 bg-muted rounded-full mr-3"></div>
                      <div>
                        <div className="h-4 bg-muted rounded w-24 mb-1"></div>
                        <div className="h-3 bg-muted rounded w-10"></div>
                      </div>
                    </div>
                  </td>
                  <td className="py-4 text-right">
                    <div className="h-4 bg-muted rounded w-20 ml-auto"></div>
                  </td>
                  <td className="py-4 text-right">
                    <div className="h-4 bg-muted rounded w-12 ml-auto"></div>
                  </td>
                  <td className="py-4 text-right">
                    <div className="h-4 bg-muted rounded w-12 ml-auto"></div>
                  </td>
                  <td className="py-4 text-right">
                    <div className="h-4 bg-muted rounded w-20 ml-auto"></div>
                  </td>
                  <td className="py-4 text-right pr-4">
                    <div className="h-8 bg-muted rounded w-24 ml-auto"></div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }
  
  if (error || !coins) {
    return (
      <div className="mb-8">
        <h2 className="text-xl font-bold mb-4">Top Cryptocurrencies</h2>
        <div className="bg-secondary rounded-lg p-4 border border-border">
          <p className="text-center text-gray-400">Unable to load cryptocurrency data</p>
        </div>
      </div>
    );
  }
  
  const formatMarketCap = (value: number) => {
    if (!value) return "$0";
    
    if (value >= 1e12) {
      return "$" + (value / 1e12).toFixed(2) + "T";
    } else if (value >= 1e9) {
      return "$" + (value / 1e9).toFixed(2) + "B";
    } else if (value >= 1e6) {
      return "$" + (value / 1e6).toFixed(2) + "M";
    } else {
      return "$" + value.toFixed(2);
    }
  };
  
  return (
    <div className="mb-8">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold">Top Cryptocurrencies</h2>
        <Link href="/markets" className="text-sm text-accent hover:underline">
          View All 
          <svg xmlns="http://www.w3.org/2000/svg" className="inline ml-1" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M5 12h14"/>
            <path d="m12 5 7 7-7 7"/>
          </svg>
        </Link>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-gray-400 border-b border-border">
              <th className="pb-3 text-left pl-4">#</th>
              <th className="pb-3 text-left">Coin</th>
              <th className="pb-3 text-right">Price</th>
              <th className="pb-3 text-right">24h</th>
              <th className="pb-3 text-right">7d</th>
              <th className="pb-3 text-right">Market Cap</th>
              <th className="pb-3 text-right pr-4">Last 7 Days</th>
            </tr>
          </thead>
          <tbody>
            {coins.slice(0, 5).map((coin: any) => (
              <tr key={coin.id} className="border-b border-border hover:bg-primary">
                <td className="py-4 pl-4">{coin.marketCapRank || '-'}</td>
                <td className="py-4">
                  <div className="flex items-center">
                    <img 
                      src={coin.image} 
                      alt={coin.name} 
                      className="w-6 h-6 mr-3"
                      onError={(e) => {
                        e.currentTarget.onerror = null;
                        e.currentTarget.src = 'https://assets.coingecko.com/coins/images/1/thumb/bitcoin.png';
                      }}
                    />
                    <div>
                      <div className="font-medium">{coin.name}</div>
                      <div className="text-gray-400 text-xs">{coin.symbol.toUpperCase()}</div>
                    </div>
                  </div>
                </td>
                <td className="py-4 text-right font-mono">
                  ${coin.currentPrice?.toLocaleString(undefined, { 
                    minimumFractionDigits: coin.currentPrice < 1 ? 4 : 2,
                    maximumFractionDigits: coin.currentPrice < 1 ? 6 : 2
                  })}
                </td>
                <td className={`py-4 text-right ${
                  coin.priceChangePercentage24h > 0 
                    ? 'text-success' 
                    : coin.priceChangePercentage24h < 0 
                      ? 'text-danger' 
                      : 'text-gray-400'
                }`}>
                  {coin.priceChangePercentage24h > 0 ? '+' : ''}
                  {coin.priceChangePercentage24h?.toFixed(2)}%
                </td>
                <td className={`py-4 text-right ${
                  coin.priceChangePercentage7d > 0 
                    ? 'text-success' 
                    : coin.priceChangePercentage7d < 0 
                      ? 'text-danger' 
                      : 'text-gray-400'
                }`}>
                  {coin.priceChangePercentage7d > 0 ? '+' : ''}
                  {coin.priceChangePercentage7d?.toFixed(2)}%
                </td>
                <td className="py-4 text-right font-mono">{formatMarketCap(coin.marketCap)}</td>
                <td className="py-4 text-right pr-4">
                  <Sparkline 
                    data={coin.sparklineData || []} 
                    color={coin.priceChangePercentage7d >= 0 ? "#10B981" : "#EF4444"}
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default TopCoins;
