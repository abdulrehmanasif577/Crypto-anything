import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import ProfitLossCalculator from './tools/ProfitLossCalculator';

const FeaturedTools = () => {
  return (
    <div className="mb-8">
      <h2 className="text-xl font-bold mb-6">Featured Tool</h2>
      
      <div className="gradient-border">
        <div className="bg-secondary rounded-lg p-6">
          <ProfitLossCalculator />
        </div>
      </div>
    </div>
  );
};

export default FeaturedTools;
