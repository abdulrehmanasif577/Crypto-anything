import React, { useEffect, useRef } from 'react';

interface SparklineProps {
  data: number[];
  color?: string;
  height?: number;
  width?: number;
  lineWidth?: number;
}

const Sparkline: React.FC<SparklineProps> = ({ 
  data, 
  color = '#10B981', 
  height = 30, 
  width = 100,
  lineWidth = 2
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!canvasRef.current || !data || data.length === 0) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Set up dimensions with device pixel ratio for sharpness
    const dpr = window.devicePixelRatio || 1;
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;
    ctx.scale(dpr, dpr);
    
    // Find min and max values for scaling
    const minValue = Math.min(...data);
    const maxValue = Math.max(...data);
    const range = maxValue - minValue;
    
    // Set line style
    ctx.lineWidth = lineWidth;
    ctx.strokeStyle = color;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    
    // Start drawing path
    ctx.beginPath();
    
    // Calculate x and y step size
    const xStep = width / (data.length - 1);
    const availableHeight = height - lineWidth * 2; // Account for line width
    
    // Move to first point
    if (data.length > 0) {
      // Normalize first point
      const y = range === 0
        ? availableHeight / 2
        : availableHeight - ((data[0] - minValue) / range) * availableHeight;
      
      ctx.moveTo(0, y + lineWidth);
      
      // Draw lines to each data point
      for (let i = 1; i < data.length; i++) {
        // Normalize y position
        const normalizedY = range === 0
          ? availableHeight / 2
          : availableHeight - ((data[i] - minValue) / range) * availableHeight;
        
        ctx.lineTo(i * xStep, normalizedY + lineWidth);
      }
    }
    
    ctx.stroke();
  }, [data, color, height, width, lineWidth]);

  // Display fallback if no data
  if (!data || data.length === 0) {
    return (
      <svg 
        className="inline-block" 
        width={width} 
        height={height} 
        viewBox={`0 0 ${width} ${height}`} 
        preserveAspectRatio="none"
      >
        <path 
          d={`M0,${height/2} L${width},${height/2}`} 
          stroke="#9CA3AF" 
          strokeWidth={lineWidth} 
          fill="none"
        />
      </svg>
    );
  }

  return (
    <canvas
      ref={canvasRef}
      width={width}
      height={height}
      className="inline-block"
    />
  );
};

export default Sparkline;
