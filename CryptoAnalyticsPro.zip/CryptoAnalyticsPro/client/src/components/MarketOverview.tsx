import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";

const MarketOverview = () => {
  const { data: marketStats, isLoading, error } = useQuery({
    queryKey: ['/api/market-stats'],
    staleTime: 300000 // 5 minutes
  });

  // Auto-refresh every 5 minutes
  const [refresh, setRefresh] = useState(0);
  
  useEffect(() => {
    const timer = setInterval(() => {
      setRefresh(prev => prev + 1);
    }, 300000);
    
    return () => clearInterval(timer);
  }, []);
  
  const formatMarketCap = (value: number) => {
    if (!value) return "$0";
    
    if (value >= 1e12) {
      return "$" + (value / 1e12).toFixed(2) + "T";
    } else if (value >= 1e9) {
      return "$" + (value / 1e9).toFixed(2) + "B";
    } else if (value >= 1e6) {
      return "$" + (value / 1e6).toFixed(2) + "M";
    } else {
      return "$" + value.toFixed(2);
    }
  };
  
  if (isLoading) {
    return (
      <div className="mb-8">
        <h2 className="text-xl font-bold mb-4">Market Overview</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-secondary rounded-lg p-4 border border-border animate-pulse h-32">
              <div className="h-4 bg-muted rounded w-32 mb-4"></div>
              <div className="h-6 bg-muted rounded w-20 mb-4"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }
  
  if (error || !marketStats) {
    return (
      <div className="mb-8">
        <h2 className="text-xl font-bold mb-4">Market Overview</h2>
        <div className="bg-secondary rounded-lg p-4 border border-border">
          <p className="text-center text-gray-400">Unable to load market data</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="mb-8">
      <h2 className="text-xl font-bold mb-4">Market Overview</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-secondary rounded-lg p-4 border border-border card">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-gray-400 text-sm">Global Market Cap</h3>
            <span className="text-success text-xs">
              <svg xmlns="http://www.w3.org/2000/svg" className="inline mr-1" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="m18 15-6-6-6 6"/>
              </svg>
              2.8%
            </span>
          </div>
          <p className="text-xl font-mono font-medium">{formatMarketCap(marketStats.totalMarketCap)}</p>
          <div className="mt-3 h-10 bg-primary rounded overflow-hidden">
            <div className="h-full bg-gradient-to-r from-accent to-blue-400 w-3/4"></div>
          </div>
        </div>
        
        <div className="bg-secondary rounded-lg p-4 border border-border card">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-gray-400 text-sm">24h Volume</h3>
            <span className="text-danger text-xs">
              <svg xmlns="http://www.w3.org/2000/svg" className="inline mr-1" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="m6 9 6 6 6-6"/>
              </svg>
              4.1%
            </span>
          </div>
          <p className="text-xl font-mono font-medium">{formatMarketCap(marketStats.totalVolume24h)}</p>
          <div className="mt-3 h-10 bg-primary rounded overflow-hidden">
            <div className="h-full bg-gradient-to-r from-purple-500 to-accent w-2/3"></div>
          </div>
        </div>
        
        <div className="bg-secondary rounded-lg p-4 border border-border card">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-gray-400 text-sm">BTC Dominance</h3>
            <span className="text-success text-xs">
              <svg xmlns="http://www.w3.org/2000/svg" className="inline mr-1" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="m18 15-6-6-6 6"/>
              </svg>
              0.7%
            </span>
          </div>
          <p className="text-xl font-mono font-medium">{marketStats.btcDominance.toFixed(1)}%</p>
          <div className="mt-3 h-10 bg-primary rounded overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-amber-500 to-orange-600" 
              style={{ width: `${marketStats.btcDominance}%` }}
            ></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MarketOverview;
