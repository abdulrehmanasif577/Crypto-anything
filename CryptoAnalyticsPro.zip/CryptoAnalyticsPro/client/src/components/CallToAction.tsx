import { Link } from "wouter";

const CallToAction = () => {
  return (
    <div className="bg-gradient-to-r from-blue-900 to-accent rounded-lg p-8 text-center mb-8">
      <h2 className="text-2xl font-bold mb-4">Access More Advanced Crypto Tools</h2>
      <p className="text-gray-300 mb-6 max-w-lg mx-auto">
        Get access to enhanced analytics, real-time market alerts, and professional trading tools to stay ahead in the crypto markets.
      </p>
      <div className="flex flex-col sm:flex-row justify-center gap-4">
        <Link href="/tools" className="bg-white text-accent font-medium py-3 px-6 rounded-md hover:bg-gray-100 transition-colors">
          Explore All Tools
        </Link>
        <Link href="/learn" className="bg-accent/20 text-white border border-white/20 font-medium py-3 px-6 rounded-md hover:bg-accent/30 transition-colors">
          Learn How It Works
        </Link>
      </div>
    </div>
  );
};

export default CallToAction;
