import { createRoot } from "react-dom/client";
import "./index.css";
import { StrictMode } from "react";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { LanguageProvider } from "./context/LanguageContext";
import App from "./App";

// Initialize the application
const initialize = () => {
  // Create a root element for React to render into
  const container = document.getElementById("root");
  if (!container) throw new Error("Root element not found!");
  
  const root = createRoot(container);

  // Render with proper provider hierarchy
  // Ensure that the LanguageProvider is fully initialized before components try to use it
  root.render(
    <StrictMode>
      <QueryClientProvider client={queryClient}>
        <LanguageProvider>
          <App />
        </LanguageProvider>
      </QueryClientProvider>
    </StrictMode>
  );
};

// Start the application
initialize();
