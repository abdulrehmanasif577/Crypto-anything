import PriceTicker from "@/components/PriceTicker";
import MarketOverview from "@/components/MarketOverview";
import TopCoins from "@/components/TopCoins";
import MarketInsights from "@/components/MarketInsights";
import CryptoTools from "@/components/CryptoTools";
import LatestNews from "@/components/LatestNews";
import FeaturedTools from "@/components/FeaturedTools";
import CallToAction from "@/components/CallToAction";

const HomePage = () => {
  return (
    <main className="container mx-auto px-4 py-6">
      <PriceTicker />
      <MarketOverview />
      <TopCoins />
      <MarketInsights />
      <CryptoTools />
      <LatestNews />
      <FeaturedTools />
      <CallToAction />
    </main>
  );
};

export default HomePage;
