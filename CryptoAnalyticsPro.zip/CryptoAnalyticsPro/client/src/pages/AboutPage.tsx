import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useState } from 'react';

const AboutPage = () => {
  const [activeTab, setActiveTab] = useState('about');
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real application, you would send this data to your backend
    console.log('Form data submitted:', formData);
    setFormSubmitted(true);
    // Reset form after submission
    setFormData({
      name: '',
      email: '',
      subject: '',
      message: ''
    });
  };

  const features = [
    {
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-accent">
          <path d="M6 18h8"/>
          <path d="M6 14h12"/>
          <path d="M6 10h12"/>
          <path d="M6 6h12"/>
        </svg>
      ),
      title: 'Real-time Market Data',
      description: 'Access current cryptocurrency prices, market caps, and trading volumes updated in real time.'
    },
    {
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-accent">
          <path d="M3 9h18v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9Z"/>
          <path d="m3 9 2.45-4.9A2 2 0 0 1 7.24 3h9.52a2 2 0 0 1 1.8 1.1L21 9"/>
          <path d="M12 3v6"/>
        </svg>
      ),
      title: 'Crypto Portfolio Tools',
      description: 'Calculate profit/loss, ROI, and manage your crypto investments with our specialized tools.'
    },
    {
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-accent">
          <path d="m3 3 7.07 16.97 2.51-7.39 7.39-2.51L3 3z"/>
          <path d="m13 13 6 6"/>
        </svg>
      ),
      title: 'Market Analysis',
      description: 'Dive into detailed market trends, top performers, and gain insights with advanced analytics.'
    },
    {
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-accent">
          <rect width="18" height="18" x="3" y="3" rx="2"/>
          <path d="M7 7h10v2H7z"/>
          <path d="M7 13h4v2H7z"/>
        </svg>
      ),
      title: 'Educational Resources',
      description: 'Learn about cryptocurrencies, blockchain technology, and trading strategies with our guides.'
    },
    {
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-accent">
          <circle cx="12" cy="12" r="10"/>
          <path d="m4.93 4.93 14.14 14.14"/>
        </svg>
      ),
      title: 'Multilingual Support',
      description: 'Access all our tools and resources in multiple languages including English and Arabic.'
    },
    {
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-accent">
          <path d="M2 13a12 12 0 0 0 8 8m15-15a12 12 0 0 0-8-8"/>
          <path d="M2 2a12 12 0 0 1 19 9"/>
          <path d="M11 1c4 0 7 4 9 4-4 1-7 4-9 4m-7 5c4 0 7 4 9 4-1 1-2 3-3 4"/>
        </svg>
      ),
      title: 'Interactive Charts',
      description: 'Visualize price movements, historical data, and technical indicators with interactive charting.'
    }
  ];

  const faqItems = [
    {
      question: 'What is MarketPro?',
      answer: 'MarketPro is a comprehensive cryptocurrency analytics platform that provides real-time market data, trading tools, educational resources, and insights for crypto traders and investors of all levels.'
    },
    {
      question: 'Is MarketPro free to use?',
      answer: 'Yes! MarketPro is completely free to use. All tools and features are accessible without any premium restrictions or subscriptions.'
    },
    {
      question: 'Do I need to create an account?',
      answer: 'No, you don\'t need to create an account to use MarketPro. All tools and features are accessible without registration, ensuring your privacy.'
    },
    {
      question: 'Where does MarketPro get its data?',
      answer: 'We source our data from reliable cryptocurrency APIs including CoinGecko, TradingView, CryptoCompare, and DefiLlama to ensure accuracy and reliability.'
    },
    {
      question: 'How often is the price data updated?',
      answer: 'Market data on MarketPro is updated in real-time or near-real-time, depending on the specific data point. Price tickers are generally updated every minute.'
    },
    {
      question: 'Can I access MarketPro on mobile devices?',
      answer: 'Yes, MarketPro is fully responsive and works well on all devices including desktops, tablets, and mobile phones.'
    },
    {
      question: 'How do I report a bug or suggest a feature?',
      answer: 'You can report bugs or suggest features by using our contact form on the "Contact" tab or by emailing us directly at abdulrehmanasif577@gmail.com.'
    }
  ];

  const teamMembers = [
    {
      name: 'Alex Johnson',
      role: 'Lead Developer',
      image: 'https://randomuser.me/api/portraits/men/32.jpg'
    },
    {
      name: 'Sarah Chen',
      role: 'UI/UX Designer',
      image: 'https://randomuser.me/api/portraits/women/44.jpg'
    },
    {
      name: 'Marcus Williams',
      role: 'Crypto Analyst',
      image: 'https://randomuser.me/api/portraits/men/46.jpg'
    },
    {
      name: 'Priya Sharma',
      role: 'Content Creator',
      image: 'https://randomuser.me/api/portraits/women/65.jpg'
    }
  ];

  return (
    <main className="container mx-auto px-4 py-6">
      <div className="mb-8">
        <h1 className="text-2xl font-bold mb-2">About MarketPro</h1>
        <p className="text-gray-400">
          Learn more about our platform, features, and the team behind MarketPro
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
        <TabsList className="bg-secondary border border-border">
          <TabsTrigger value="about">About Us</TabsTrigger>
          <TabsTrigger value="features">Features</TabsTrigger>
          <TabsTrigger value="team">Our Team</TabsTrigger>
          <TabsTrigger value="faq">FAQ</TabsTrigger>
          <TabsTrigger value="contact">Contact</TabsTrigger>
        </TabsList>

        <TabsContent value="about">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div>
              <h2 className="text-xl font-bold mb-4">Our Mission</h2>
              <p className="text-gray-300 mb-4">
                At MarketPro, our mission is to democratize access to cryptocurrency market data and analytics tools. We believe everyone should have access to professional-grade insights and tools regardless of their trading experience or portfolio size.
              </p>
              <p className="text-gray-300 mb-4">
                We're committed to providing a comprehensive, user-friendly platform that empowers individuals to make informed decisions in the rapidly evolving crypto markets.
              </p>

              <h2 className="text-xl font-bold mt-8 mb-4">Why Choose MarketPro?</h2>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-accent mr-2 mt-0.5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  <span className="text-gray-300">Real-time, accurate market data from trusted sources</span>
                </li>
                <li className="flex items-start">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-accent mr-2 mt-0.5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  <span className="text-gray-300">Comprehensive suite of tools for traders and investors</span>
                </li>
                <li className="flex items-start">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-accent mr-2 mt-0.5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  <span className="text-gray-300">No registration required - privacy-focused approach</span>
                </li>
                <li className="flex items-start">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-accent mr-2 mt-0.5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  <span className="text-gray-300">Multilingual support with full RTL capabilities</span>
                </li>
                <li className="flex items-start">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-accent mr-2 mt-0.5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  <span className="text-gray-300">Modern, responsive interface designed for all devices</span>
                </li>
              </ul>
            </div>

            <div className="space-y-6">
              <Card className="bg-secondary border-border overflow-hidden">
                <div className="relative h-60">
                  <img 
                    src="https://images.unsplash.com/photo-1639762681057-408e52192e55" 
                    alt="Crypto analytics dashboard" 
                    className="absolute inset-0 w-full h-full object-cover"
                    onError={(e) => {
                      e.currentTarget.onerror = null;
                      e.currentTarget.src = 'https://images.unsplash.com/photo-1621761191319-c6fb62004040';
                    }}
                  />
                </div>
                <CardContent className="p-4">
                  <h3 className="font-medium mb-2">Built for the Crypto Community</h3>
                  <p className="text-gray-400 text-sm">
                    MarketPro is designed and developed by crypto enthusiasts who understand the needs of traders and investors in this dynamic market.
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-secondary border-border">
                <CardContent className="p-4">
                  <div className="flex flex-col space-y-4">
                    <div className="flex items-center">
                      <div className="h-12 w-12 rounded-full bg-accent/20 flex items-center justify-center mr-4">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-accent" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M12 20a8 8 0 1 0 0-16 8 8 0 0 0 0 16Z"/>
                          <path d="M12 14a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z"/>
                          <path d="M12 2v2"/>
                          <path d="M12 22v-2"/>
                          <path d="m17 20.66-1-1.73"/>
                          <path d="M11 10.27 7 3.34"/>
                          <path d="m20.66 17-1.73-1"/>
                          <path d="m3.34 7 1.73 1"/>
                          <path d="M14 12h8"/>
                          <path d="M2 12h2"/>
                          <path d="m20.66 7-1.73 1"/>
                          <path d="m3.34 17 1.73-1"/>
                          <path d="m17 3.34-1 1.73"/>
                          <path d="m11 13.73-4 6.93"/>
                        </svg>
                      </div>
                      <div>
                        <h3 className="font-medium">Our Vision</h3>
                        <p className="text-gray-400 text-sm">To become the most trusted and accessible crypto analytics platform globally.</p>
                      </div>
                    </div>

                    <div className="flex items-center">
                      <div className="h-12 w-12 rounded-full bg-green-500/20 flex items-center justify-center mr-4">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-green-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M12 2v4"/>
                          <path d="M5 5.3 7.1 7"/>
                          <path d="M2 12h4"/>
                          <path d="M5 18.7 7.1 17"/>
                          <path d="M12 22v-4"/>
                          <path d="m17 18.7-2.1-1.7"/>
                          <path d="M22 12h-4"/>
                          <path d="m17 5.3-2.1 1.7"/>
                          <path d="M12 8a4 4 0 0 0-4 4"/>
                          <path d="M12 8a4 4 0 0 1 4 4"/>
                          <path d="M12 8v8"/>
                        </svg>
                      </div>
                      <div>
                        <h3 className="font-medium">Our Values</h3>
                        <p className="text-gray-400 text-sm">Transparency, accuracy, accessibility, and continuous improvement.</p>
                      </div>
                    </div>

                    <div className="flex items-center">
                      <div className="h-12 w-12 rounded-full bg-purple-500/20 flex items-center justify-center mr-4">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-purple-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M21 5v14l-9 -7z"/>
                          <path d="M3 5v14l9 -7z"/>
                        </svg>
                      </div>
                      <div>
                        <h3 className="font-medium">Looking Forward</h3>
                        <p className="text-gray-400 text-sm">Continuously expanding our tools and features based on community feedback.</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="features">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <Card key={index} className="bg-secondary border-border hover:shadow-md transition-shadow card">
                <CardContent className="p-6">
                  <div className="h-12 w-12 rounded-full bg-accent/10 flex items-center justify-center mb-4">
                    {feature.icon}
                  </div>
                  <h3 className="text-lg font-medium mb-2">{feature.title}</h3>
                  <p className="text-gray-400">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="mt-12">
            <h2 className="text-xl font-bold mb-6">Our Technology Stack</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <Card className="bg-secondary border-border">
                <CardContent className="p-4 text-center">
                  <div className="h-16 w-16 mx-auto mb-4 flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-500 h-10 w-10">
                      <circle cx="12" cy="12" r="10"/>
                      <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/>
                      <path d="M12 17h.01"/>
                    </svg>
                  </div>
                  <h3 className="font-medium">APIs</h3>
                  <p className="text-sm text-gray-400 mt-2">CoinGecko, TradingView, CryptoCompare, DefiLlama</p>
                </CardContent>
              </Card>

              <Card className="bg-secondary border-border">
                <CardContent className="p-4 text-center">
                  <div className="h-16 w-16 mx-auto mb-4 flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-cyan-500 h-10 w-10">
                      <path d="M12 3h.393a7.5 7.5 0 0 0 7.92 12.446A9 9 0 1 1 12 2.992z"/>
                    </svg>
                  </div>
                  <h3 className="font-medium">Frontend</h3>
                  <p className="text-sm text-gray-400 mt-2">React, TailwindCSS, TypeScript</p>
                </CardContent>
              </Card>

              <Card className="bg-secondary border-border">
                <CardContent className="p-4 text-center">
                  <div className="h-16 w-16 mx-auto mb-4 flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-500 h-10 w-10">
                      <path d="M20.38 3.46 16 2a4 4 0 0 1-8 0L3.62 3.46a2 2 0 0 0-1.34 2.23l.58 3.47a1 1 0 0 0 .99.84H6v10c0 1.1.9 2 2 2h8a2 2 0 0 0 2-2V10h2.15a1 1 0 0 0 .99-.84l.58-3.47a2 2 0 0 0-1.34-2.23z"/>
                    </svg>
                  </div>
                  <h3 className="font-medium">Charts</h3>
                  <p className="text-sm text-gray-400 mt-2">TradingView Widgets, ApexCharts</p>
                </CardContent>
              </Card>

              <Card className="bg-secondary border-border">
                <CardContent className="p-4 text-center">
                  <div className="h-16 w-16 mx-auto mb-4 flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-purple-500 h-10 w-10">
                      <path d="m16 6 4 14"/>
                      <path d="M12 6v14"/>
                      <path d="M8 8v12"/>
                      <path d="M4 4v16"/>
                    </svg>
                  </div>
                  <h3 className="font-medium">Data Processing</h3>
                  <p className="text-sm text-gray-400 mt-2">React Query, Express, Drizzle ORM</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="team">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {teamMembers.map((member, index) => (
              <Card key={index} className="bg-secondary border-border overflow-hidden card">
                <div className="h-48 overflow-hidden">
                  <img 
                    src={member.image} 
                    alt={member.name} 
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      e.currentTarget.onerror = null;
                      e.currentTarget.src = 'https://via.placeholder.com/150';
                    }}
                  />
                </div>
                <CardContent className="p-4 text-center">
                  <h3 className="font-medium text-lg">{member.name}</h3>
                  <p className="text-gray-400">{member.role}</p>
                  <div className="flex justify-center mt-3 space-x-2">
                    <button className="text-gray-400 hover:text-white">
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/>
                        <rect width="4" height="12" x="2" y="9"/>
                        <circle cx="4" cy="4" r="2"/>
                      </svg>
                    </button>
                    <button className="text-gray-400 hover:text-white">
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"/>
                      </svg>
                    </button>
                    <button className="text-gray-400 hover:text-white">
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <rect width="20" height="20" x="2" y="2" rx="5" ry="5"/>
                        <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/>
                        <line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/>
                      </svg>
                    </button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="mt-12 bg-secondary rounded-lg border border-border p-8 text-center">
            <h2 className="text-xl font-bold mb-4">Join Our Team</h2>
            <p className="text-gray-300 max-w-2xl mx-auto mb-6">
              We're always looking for talented individuals who are passionate about cryptocurrency and blockchain technology to join our team. If you're interested in contributing to MarketPro, get in touch with us!
            </p>
            <Button className="bg-accent">View Openings</Button>
          </div>
        </TabsContent>

        <TabsContent value="faq">
          <div className="max-w-3xl mx-auto">
            <div className="space-y-6">
              {faqItems.map((item, index) => (
                <Card key={index} className="bg-secondary border-border">
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium mb-2 flex items-center">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-accent mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <circle cx="12" cy="12" r="10"/>
                        <path d="M12 16v.01"/>
                        <path d="M12 8a2 2 0 0 1 2 2v1a2 2 0 1 1-4 0v-1a2 2 0 0 1 2-2z"/>
                      </svg>
                      {item.question}
                    </h3>
                    <p className="text-gray-300 pl-7">{item.answer}</p>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="mt-8 p-6 bg-primary rounded-lg border border-border">
              <h3 className="text-lg font-medium mb-3">Still have questions?</h3>
              <p className="text-gray-400 mb-4">
                If you couldn't find the answer to your question in our FAQ, please feel free to reach out to us directly.
              </p>
              <Button variant="outline" onClick={() => setActiveTab('contact')}>
                Contact Us
              </Button>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="contact">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div>
              <h2 className="text-xl font-bold mb-4">Get in Touch</h2>
              <p className="text-gray-300 mb-6">
                Have questions, feedback, or need assistance? We'd love to hear from you. Fill out the form and we'll get back to you as soon as possible.
              </p>

              {formSubmitted ? (
                <Card className="bg-secondary border-border">
                  <CardContent className="p-6 text-center">
                    <div className="h-16 w-16 mx-auto mb-4 flex items-center justify-center bg-green-500/20 rounded-full">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-green-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
                        <path d="m9 11 3 3L22 4"/>
                      </svg>
                    </div>
                    <h3 className="text-lg font-medium mb-2">Message Sent!</h3>
                    <p className="text-gray-400">
                      Thank you for reaching out. We'll get back to you as soon as possible.
                    </p>
                    <Button 
                      variant="outline" 
                      className="mt-4"
                      onClick={() => setFormSubmitted(false)}
                    >
                      Send Another Message
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                <form onSubmit={handleSubmit}>
                  <div className="space-y-4">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium mb-1">
                        Name
                      </label>
                      <Input
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        className="bg-secondary border-border"
                        required
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium mb-1">
                        Email
                      </label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleChange}
                        className="bg-secondary border-border"
                        required
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="subject" className="block text-sm font-medium mb-1">
                        Subject
                      </label>
                      <Input
                        id="subject"
                        name="subject"
                        value={formData.subject}
                        onChange={handleChange}
                        className="bg-secondary border-border"
                        required
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="message" className="block text-sm font-medium mb-1">
                        Message
                      </label>
                      <Textarea
                        id="message"
                        name="message"
                        value={formData.message}
                        onChange={handleChange}
                        className="bg-secondary border-border min-h-32"
                        required
                      />
                    </div>
                    
                    <Button type="submit" className="w-full">
                      Send Message
                    </Button>
                  </div>
                </form>
              )}
            </div>

            <div>
              <Card className="bg-secondary border-border mb-6">
                <CardContent className="p-6">
                  <h3 className="text-lg font-medium mb-4">Contact Information</h3>
                  
                  <div className="space-y-4">
                    <div className="flex items-start">
                      <div className="h-10 w-10 rounded-full bg-accent/10 flex items-center justify-center mr-4 flex-shrink-0">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-accent" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <rect width="20" height="16" x="2" y="4" rx="2"/>
                          <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>
                        </svg>
                      </div>
                      <div>
                        <h4 className="font-medium text-sm mb-1">Email</h4>
                        <a href="mailto:abdulrehmanasif577@gmail.com" className="text-accent hover:underline">
                          abdulrehmanasif577@gmail.com
                        </a>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div className="flex items-start">
                      <div className="h-10 w-10 rounded-full bg-accent/10 flex items-center justify-center mr-4 flex-shrink-0">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-accent" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
                        </svg>
                      </div>
                      <div>
                        <h4 className="font-medium text-sm mb-1">Support Hours</h4>
                        <p className="text-gray-400">
                          Monday - Friday: 9:00 AM - 6:00 PM (EST)
                        </p>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div className="flex items-start">
                      <div className="h-10 w-10 rounded-full bg-accent/10 flex items-center justify-center mr-4 flex-shrink-0">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-accent" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="m3 21 1.9-5.7a8.5 8.5 0 1 1 3.8 3.8z"/>
                        </svg>
                      </div>
                      <div>
                        <h4 className="font-medium text-sm mb-1">Social Media</h4>
                        <div className="flex space-x-3 mt-2">
                          <a href="#" className="text-gray-400 hover:text-white">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"/>
                            </svg>
                          </a>
                          <a href="#" className="text-gray-400 hover:text-white">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <path d="M22 4.01c-1 .49-1.98.689-3 .99-1.121-1.265-2.783-1.335-4.38-.737S11.977 6.323 12 8v1c-3.245.083-6.135-1.395-8-4 0 0-4.182 7.433 4 11-1.872 1.247-3.739 2.088-6 2 3.308 1.803 6.913 2.423 10.034 1.517 3.58-1.04 6.522-3.723 7.651-7.742a13.84 13.84 0 0 0 .497-3.753C20.18 7.773 21.692 5.25 22 4.009z"/>
                            </svg>
                          </a>
                          <a href="#" className="text-gray-400 hover:text-white">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/>
                            </svg>
                          </a>
                          <a href="#" className="text-gray-400 hover:text-white">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <rect width="20" height="20" x="2" y="2" rx="5" ry="5"/>
                              <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/>
                              <line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/>
                            </svg>
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-secondary border-border">
                <CardContent className="p-6">
                  <h3 className="text-lg font-medium mb-4">Report an Issue</h3>
                  <p className="text-gray-400 mb-4">
                    Found a bug or experiencing technical issues? Let us know so we can improve your experience.
                  </p>
                  <Button variant="outline" className="w-full" onClick={() => {
                    setFormData({
                      ...formData,
                      subject: 'Bug Report / Technical Issue'
                    });
                  }}>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="m21 2-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0 2 2L22 5l-3-3-3 3z"/>
                    </svg>
                    Report Issue
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </main>
  );
};

export default AboutPage;
