import { useState } from 'react';
import ProfitLossCalculator from '@/components/tools/ProfitLossCalculator';
import CryptoConverter from '@/components/tools/CryptoConverter';
import RoiCalculator from '@/components/tools/RoiCalculator';
import GasFeeEstimator from '@/components/tools/GasFeeEstimator';

const ToolsPage = () => {
  const [activeTab, setActiveTab] = useState<string>('profit-loss');
  
  const tools = [
    {
      id: 'profit-loss',
      name: 'Profit/Loss Calculator',
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <rect width="16" height="20" x="4" y="2" rx="2"/>
          <line x1="8" x2="16" y1="6" y2="6"/>
          <line x1="16" x2="16" y1="14" y2="18"/>
          <path d="M16 10h.01"/>
          <path d="M12 10h.01"/>
          <path d="M8 10h.01"/>
          <path d="M12 14h.01"/>
          <path d="M8 14h.01"/>
          <path d="M12 18h.01"/>
          <path d="M8 18h.01"/>
        </svg>
      ),
      component: <ProfitLossCalculator />
    },
    {
      id: 'converter',
      name: 'Crypto Converter',
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="m17 20 4-4-4-4"/>
          <path d="M3 8h18"/>
          <path d="m7 4-4 4 4 4"/>
          <path d="M21 16H3"/>
        </svg>
      ),
      component: <CryptoConverter />
    },
    {
      id: 'roi',
      name: 'ROI Calculator',
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M21 21H4.6a2.6 2.6 0 0 1-2.6-2.6V3"/>
          <path d="m6 16 6-8 6 8"/>
          <path d="M12 8v8"/>
        </svg>
      ),
      component: <RoiCalculator />
    },
    {
      id: 'gas-fees',
      name: 'Gas Fee Estimator',
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M10 8V5a2 2 0 0 1 2-2h6.5L22 6.5V16a2 2 0 0 1-2 2h-1"/>
          <path d="M8 5v10"/>
          <path d="M2 12a4 4 0 0 1 4-4h8"/>
          <path d="M6 16h4"/>
          <circle cx="6" cy="15" r="3"/>
        </svg>
      ),
      component: <GasFeeEstimator />
    },
    {
      id: 'staking',
      name: 'Staking Rewards Estimator',
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="8" cy="8" r="6"/>
          <path d="M18.09 10.37A6 6 0 1 1 10.34 18"/>
          <path d="M7 6h2v4"/>
          <path d="m16 16 2 2 4-4"/>
        </svg>
      ),
      component: <div className="p-6 text-center text-gray-400">Staking Rewards Estimator - Coming Soon</div>
    },
    {
      id: 'mining',
      name: 'Mining Profitability Calculator',
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M19 6v4.8s-2.2-1.8-3.6-1.8c-2 0-3.8 1.3-5.2 3.5 0 0-2.3-1.7-6.2-1.7V6a2 2 0 0 1 2-2h11a2 2 0 0 1 2 2Z"/>
          <path d="M19 15.7c-2.2 0-4.5 1-6.8 2.3-2.3-1.3-4.6-2.3-6.8-2.3-1.7 0-3.4.3-5.4.8V18a2 2 0 0 0 2 2h10c2 0 2-1.4 4-1a4 4 0 0 1 4 4v.5"/>
          <path d="M13.8 13.6c.7-1.4 1.8-2.6 3.2-3.6"/>
        </svg>
      ),
      component: <div className="p-6 text-center text-gray-400">Mining Profitability Calculator - Coming Soon</div>
    }
  ];
  
  const activeTool = tools.find(tool => tool.id === activeTab) || tools[0];
  
  return (
    <main className="container mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold mb-6">Crypto Tools</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        <div className="lg:col-span-1 bg-secondary rounded-lg p-4 border border-border">
          <h2 className="text-lg font-bold mb-4">Available Tools</h2>
          <div className="space-y-2">
            {tools.map((tool) => (
              <button
                key={tool.id}
                className={`flex items-center space-x-3 w-full p-3 rounded-md text-left ${
                  activeTab === tool.id
                    ? 'bg-accent bg-opacity-20 text-accent'
                    : 'hover:bg-primary text-gray-300'
                }`}
                onClick={() => setActiveTab(tool.id)}
              >
                <span className="flex-shrink-0">{tool.icon}</span>
                <span>{tool.name}</span>
              </button>
            ))}
          </div>
        </div>
        
        <div className="lg:col-span-4">
          <div className="bg-secondary rounded-lg border border-border">
            <div className="border-b border-border px-6 py-4">
              <h2 className="text-lg font-bold flex items-center">
                <span className="mr-2">{activeTool.icon}</span>
                {activeTool.name}
              </h2>
            </div>
            <div className="p-4">
              {activeTool.component}
            </div>
          </div>
        </div>
      </div>
    </main>
  );
};

export default ToolsPage;
