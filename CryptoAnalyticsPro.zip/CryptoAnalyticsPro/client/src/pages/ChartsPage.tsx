import { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';

const ChartsPage = () => {
  const [activePair, setActivePair] = useState('BTCUSD');
  const [activeTimeframe, setActiveTimeframe] = useState('1D');
  
  const { data: tradingPairs, isLoading: loadingPairs } = useQuery({
    queryKey: ['/api/trading-pairs'],
    staleTime: 3600000 // 1 hour
  });
  
  // Set up TradingView chart
  useEffect(() => {
    if (typeof window.TradingView === 'undefined') {
      const script = document.createElement('script');
      script.src = 'https://s3.tradingview.com/tv.js';
      script.async = true;
      script.onload = initChart;
      document.head.appendChild(script);
      
      return () => {
        document.head.removeChild(script);
      };
    } else {
      initChart();
    }
  }, [activePair, activeTimeframe]);
  
  function initChart() {
    if (typeof window.TradingView !== 'undefined' && document.getElementById('tradingview_chart_full')) {
      new window.TradingView.widget({
        autosize: true,
        symbol: `BINANCE:${activePair}`,
        interval: activeTimeframe === '15M' ? '15' :
                  activeTimeframe === '1H' ? '60' : 
                  activeTimeframe === '4H' ? '240' : 
                  activeTimeframe === '1D' ? 'D' : 
                  activeTimeframe === '1W' ? 'W' : 'M',
        theme: 'dark',
        style: '1',
        toolbar_bg: '#111417',
        enable_publishing: false,
        hide_top_toolbar: false,
        hide_legend: false,
        container_id: 'tradingview_chart_full',
        withdateranges: true,
        allow_symbol_change: true,
        save_image: true,
        studies: ['RSI@tv-basicstudies', 'MAExp@tv-basicstudies', 'MACD@tv-basicstudies'],
        timezone: 'exchange',
      });
    }
  }
  
  // Default trading pairs if API doesn't return any
  const defaultPairs = [
    { baseSymbol: 'BTC', quoteSymbol: 'USD', displayName: 'Bitcoin / US Dollar', isPopular: true },
    { baseSymbol: 'ETH', quoteSymbol: 'USD', displayName: 'Ethereum / US Dollar', isPopular: true },
    { baseSymbol: 'BNB', quoteSymbol: 'USD', displayName: 'BNB / US Dollar', isPopular: true },
    { baseSymbol: 'XRP', quoteSymbol: 'USD', displayName: 'XRP / US Dollar', isPopular: true },
    { baseSymbol: 'ADA', quoteSymbol: 'USD', displayName: 'Cardano / US Dollar', isPopular: false },
    { baseSymbol: 'SOL', quoteSymbol: 'USD', displayName: 'Solana / US Dollar', isPopular: false },
    { baseSymbol: 'DOT', quoteSymbol: 'USD', displayName: 'Polkadot / US Dollar', isPopular: false },
    { baseSymbol: 'DOGE', quoteSymbol: 'USD', displayName: 'Dogecoin / US Dollar', isPopular: false }
  ];
  
  // Use either API data or default pairs
  const pairsToDisplay = tradingPairs && tradingPairs.length > 0 ? tradingPairs : defaultPairs;
  const popularPairs = pairsToDisplay.filter((pair: any) => pair.isPopular);
  
  const timeframes = [
    { value: '15M', label: '15m' },
    { value: '1H', label: '1h' },
    { value: '4H', label: '4h' },
    { value: '1D', label: '1d' },
    { value: '1W', label: '1w' },
    { value: '1M', label: '1m' }
  ];
  
  return (
    <main className="container mx-auto px-4 py-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Live Charts</h1>
        <div className="flex space-x-2">
          {timeframes.map((timeframe) => (
            <button
              key={timeframe.value}
              className={`px-3 py-1 text-sm rounded-md ${
                activeTimeframe === timeframe.value
                  ? 'bg-accent'
                  : 'bg-secondary hover:bg-primary'
              }`}
              onClick={() => setActiveTimeframe(timeframe.value)}
            >
              {timeframe.label}
            </button>
          ))}
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        <div className="lg:col-span-1 bg-secondary rounded-lg p-4 border border-border">
          <h2 className="text-lg font-bold mb-4">Trading Pairs</h2>
          
          {loadingPairs ? (
            // Loading state
            <div className="space-y-3">
              {Array(8).fill(0).map((_, i) => (
                <div key={i} className="p-3 rounded-md animate-pulse">
                  <div className="h-5 bg-muted rounded w-32"></div>
                </div>
              ))}
            </div>
          ) : (
            <>
              {popularPairs.length > 0 && (
                <div className="mb-4">
                  <h3 className="text-sm text-gray-400 mb-2">Popular</h3>
                  <div className="space-y-1">
                    {popularPairs.map((pair: any) => (
                      <button
                        key={`${pair.baseSymbol}${pair.quoteSymbol}`}
                        className={`w-full text-left p-3 rounded-md ${
                          activePair === `${pair.baseSymbol}${pair.quoteSymbol}`
                            ? 'bg-accent bg-opacity-20 text-accent'
                            : 'hover:bg-primary'
                        }`}
                        onClick={() => setActivePair(`${pair.baseSymbol}${pair.quoteSymbol}`)}
                      >
                        {pair.displayName}
                      </button>
                    ))}
                  </div>
                </div>
              )}
              
              <h3 className="text-sm text-gray-400 mb-2">All Pairs</h3>
              <div className="space-y-1 max-h-96 overflow-y-auto pr-1">
                {pairsToDisplay.map((pair: any) => (
                  <button
                    key={`${pair.baseSymbol}${pair.quoteSymbol}`}
                    className={`w-full text-left p-3 rounded-md ${
                      activePair === `${pair.baseSymbol}${pair.quoteSymbol}`
                        ? 'bg-accent bg-opacity-20 text-accent'
                        : 'hover:bg-primary'
                    }`}
                    onClick={() => setActivePair(`${pair.baseSymbol}${pair.quoteSymbol}`)}
                  >
                    {pair.displayName}
                  </button>
                ))}
              </div>
            </>
          )}
        </div>
        
        <div className="lg:col-span-4 bg-secondary rounded-lg p-4 border border-border">
          <div className="relative bg-primary rounded-lg overflow-hidden" style={{ height: 'calc(100vh - 260px)', minHeight: '500px' }}>
            <div id="tradingview_chart_full" className="absolute inset-0 w-full h-full"></div>
            
            {/* Loading state */}
            <div className="absolute inset-0 flex items-center justify-center z-10 pointer-events-none">
              <div className="text-center">
                <div className="mb-4">
                  <div className="mx-auto loader"></div>
                </div>
                <p className="text-gray-400">Loading TradingView Chart...</p>
                <p className="text-xs text-gray-500 mt-2">{activePair} • {activeTimeframe} Timeframe</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
};

declare global {
  interface Window {
    TradingView: any;
  }
}

export default ChartsPage;
