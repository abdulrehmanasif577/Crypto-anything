import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Button } from '@/components/ui/button';
import Sparkline from '@/components/ui/sparkline';

const AnalyticsPage = () => {
  const [timeframe, setTimeframe] = useState('24h');
  const [activeTab, setActiveTab] = useState('gainers-losers');

  const { data: coins, isLoading } = useQuery({
    queryKey: ['/api/coins'],
    staleTime: 60000 // 1 minute
  });

  // Sort coins by 24h price change (for gainers/losers)
  const sortedCoins = coins ? [...coins].sort((a, b) => 
    b.priceChangePercentage24h - a.priceChangePercentage24h
  ) : [];

  const topGainers = sortedCoins.filter(coin => coin.priceChangePercentage24h > 0).slice(0, 5);
  const topLosers = sortedCoins.filter(coin => coin.priceChangePercentage24h < 0)
    .sort((a, b) => a.priceChangePercentage24h - b.priceChangePercentage24h)
    .slice(0, 5);

  // Format large numbers
  const formatLargeNumber = (num: number) => {
    if (num >= 1e9) return `$${(num / 1e9).toFixed(2)}B`;
    if (num >= 1e6) return `$${(num / 1e6).toFixed(2)}M`;
    if (num >= 1e3) return `$${(num / 1e3).toFixed(2)}K`;
    return `$${num.toFixed(2)}`;
  };

  // Whale transactions (sample data since we don't have a real whale tracking API)
  const whaleTransactions = [
    { id: 1, coin: 'Bitcoin', amount: '321 BTC', usdValue: '$17,432,650', time: '2 hours ago', type: 'transfer' },
    { id: 2, coin: 'Ethereum', amount: '4,210 ETH', usdValue: '$12,015,780', time: '4 hours ago', type: 'exchange' },
    { id: 3, coin: 'Solana', amount: '25,000 SOL', usdValue: '$6,234,500', time: '6 hours ago', type: 'transfer' },
    { id: 4, coin: 'BNB', amount: '8,400 BNB', usdValue: '$3,462,800', time: '10 hours ago', type: 'exchange' },
    { id: 5, coin: 'XRP', amount: '2,750,000 XRP', usdValue: '$1,848,250', time: '12 hours ago', type: 'transfer' },
  ];

  // DeFi stats
  const defiPlatforms = [
    { id: 1, name: 'Uniswap', tvl: '$5.12B', change24h: '+2.6%', volume24h: '$821M' },
    { id: 2, name: 'Aave', tvl: '$3.84B', change24h: '-1.2%', volume24h: '$483M' },
    { id: 3, name: 'Curve', tvl: '$3.24B', change24h: '+0.7%', volume24h: '$412M' },
    { id: 4, name: 'MakerDAO', tvl: '$2.87B', change24h: '+1.2%', volume24h: '$278M' },
    { id: 5, name: 'Compound', tvl: '$2.32B', change24h: '-0.8%', volume24h: '$195M' },
  ];

  // Correlation data
  const correlationMatrix = [
    { id: 1, asset1: 'BTC', asset2: 'ETH', correlation: '0.84', trend: 'increasing' },
    { id: 2, asset1: 'BTC', asset2: 'SOL', correlation: '0.72', trend: 'stable' },
    { id: 3, asset1: 'BTC', asset2: 'BNB', correlation: '0.68', trend: 'decreasing' },
    { id: 4, asset1: 'ETH', asset2: 'SOL', correlation: '0.81', trend: 'increasing' },
    { id: 5, asset1: 'ETH', asset2: 'BNB', correlation: '0.63', trend: 'stable' },
  ];

  // Upcoming ICOs & Airdrops
  const upcomingEvents = [
    { id: 1, name: 'DefiChain Network', type: 'ICO', date: 'May 15, 2023', website: 'defichain.io' },
    { id: 2, name: 'Metaverse Token', type: 'Airdrop', date: 'May 22, 2023', website: 'metaverse.io' },
    { id: 3, name: 'LayerZero Protocol', type: 'ICO', date: 'June 3, 2023', website: 'layerzero.network' },
    { id: 4, name: 'GameFi Alliance', type: 'Airdrop', date: 'June 10, 2023', website: 'gamefi.world' },
    { id: 5, name: 'ZK Finance', type: 'ICO', date: 'June 18, 2023', website: 'zkfinance.io' },
  ];

  return (
    <main className="container mx-auto px-4 py-6">
      <div className="flex flex-col lg:flex-row justify-between items-start md:items-center gap-4 mb-6">
        <h1 className="text-2xl font-bold">Analytics & Insights</h1>
        <div className="flex flex-col sm:flex-row gap-3">
          <Select value={timeframe} onValueChange={setTimeframe}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Timeframe" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="24h">Last 24 hours</SelectItem>
              <SelectItem value="7d">Last 7 days</SelectItem>
              <SelectItem value="30d">Last 30 days</SelectItem>
              <SelectItem value="all">All time</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" className="hidden md:flex">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
              <polyline points="17 8 12 3 7 8"/>
              <line x1="12" y1="3" x2="12" y2="15"/>
            </svg>
            Export Data
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="bg-secondary border border-border">
          <TabsTrigger value="gainers-losers">Gainers & Losers</TabsTrigger>
          <TabsTrigger value="whale-tracker">Whale Tracker</TabsTrigger>
          <TabsTrigger value="defi-stats">DeFi Stats</TabsTrigger>
          <TabsTrigger value="correlation">Correlation</TabsTrigger>
          <TabsTrigger value="ico-calendar">ICO & Airdrop</TabsTrigger>
        </TabsList>

        <TabsContent value="gainers-losers" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex justify-between items-center">
                  <span>Top Gainers ({timeframe})</span>
                  <span className="text-success text-sm font-medium">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="inline mr-1">
                      <path d="m18 15-6-6-6 6"/>
                    </svg>
                    Ascending
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="animate-pulse space-y-3">
                    {Array(5).fill(0).map((_, i) => (
                      <div key={i} className="flex items-center justify-between p-2 bg-primary rounded">
                        <div className="flex items-center">
                          <div className="w-8 h-8 bg-muted rounded-full mr-3"></div>
                          <div>
                            <div className="h-4 bg-muted rounded w-24 mb-1"></div>
                            <div className="h-3 bg-muted rounded w-16"></div>
                          </div>
                        </div>
                        <div className="h-5 bg-muted rounded w-20"></div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-3">
                    {topGainers.map((coin) => (
                      <div key={coin.id} className="flex items-center justify-between p-2 bg-primary hover:bg-primary/80 rounded cursor-pointer">
                        <div className="flex items-center">
                          <img 
                            src={coin.image} 
                            alt={coin.name} 
                            className="w-8 h-8 rounded-full mr-3" 
                            onError={(e) => {
                              e.currentTarget.onerror = null;
                              e.currentTarget.src = 'https://assets.coingecko.com/coins/images/1/thumb/bitcoin.png';
                            }}
                          />
                          <div>
                            <div className="font-medium">{coin.name}</div>
                            <div className="text-gray-400 text-xs">{coin.symbol.toUpperCase()}</div>
                          </div>
                        </div>
                        <div className="text-success font-medium">+{coin.priceChangePercentage24h.toFixed(2)}%</div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex justify-between items-center">
                  <span>Top Losers ({timeframe})</span>
                  <span className="text-danger text-sm font-medium">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="inline mr-1">
                      <path d="m6 9 6 6 6-6"/>
                    </svg>
                    Descending
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="animate-pulse space-y-3">
                    {Array(5).fill(0).map((_, i) => (
                      <div key={i} className="flex items-center justify-between p-2 bg-primary rounded">
                        <div className="flex items-center">
                          <div className="w-8 h-8 bg-muted rounded-full mr-3"></div>
                          <div>
                            <div className="h-4 bg-muted rounded w-24 mb-1"></div>
                            <div className="h-3 bg-muted rounded w-16"></div>
                          </div>
                        </div>
                        <div className="h-5 bg-muted rounded w-20"></div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-3">
                    {topLosers.map((coin) => (
                      <div key={coin.id} className="flex items-center justify-between p-2 bg-primary hover:bg-primary/80 rounded cursor-pointer">
                        <div className="flex items-center">
                          <img 
                            src={coin.image} 
                            alt={coin.name} 
                            className="w-8 h-8 rounded-full mr-3" 
                            onError={(e) => {
                              e.currentTarget.onerror = null;
                              e.currentTarget.src = 'https://assets.coingecko.com/coins/images/1/thumb/bitcoin.png';
                            }}
                          />
                          <div>
                            <div className="font-medium">{coin.name}</div>
                            <div className="text-gray-400 text-xs">{coin.symbol.toUpperCase()}</div>
                          </div>
                        </div>
                        <div className="text-danger font-medium">{coin.priceChangePercentage24h.toFixed(2)}%</div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Market Performance Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {!isLoading && sortedCoins.slice(0, 8).map((coin) => (
                  <div key={coin.id} className="bg-primary p-4 rounded-lg">
                    <div className="flex items-center mb-2">
                      <img 
                        src={coin.image} 
                        alt={coin.name} 
                        className="w-6 h-6 mr-2" 
                        onError={(e) => {
                          e.currentTarget.onerror = null;
                          e.currentTarget.src = 'https://assets.coingecko.com/coins/images/1/thumb/bitcoin.png';
                        }}
                      />
                      <span className="font-medium">{coin.symbol.toUpperCase()}</span>
                      <span className={`ml-auto ${coin.priceChangePercentage24h >= 0 ? 'text-success' : 'text-danger'}`}>
                        {coin.priceChangePercentage24h >= 0 ? '+' : ''}{coin.priceChangePercentage24h.toFixed(2)}%
                      </span>
                    </div>
                    <div className="font-mono text-sm mb-2">${coin.currentPrice?.toLocaleString()}</div>
                    <Sparkline 
                      data={coin.sparklineData || []}
                      color={coin.priceChangePercentage24h >= 0 ? "#10B981" : "#EF4444"}
                      height={30}
                    />
                    <div className="mt-2 text-xs text-gray-400">
                      Volume: {formatLargeNumber(coin.marketCap * 0.1)} • Cap: {formatLargeNumber(coin.marketCap)}
                    </div>
                  </div>
                ))}
                {isLoading && Array(8).fill(0).map((_, i) => (
                  <div key={i} className="bg-primary p-4 rounded-lg animate-pulse">
                    <div className="flex items-center mb-2">
                      <div className="w-6 h-6 bg-muted rounded-full mr-2"></div>
                      <div className="h-4 bg-muted rounded w-12"></div>
                      <div className="h-4 bg-muted rounded w-16 ml-auto"></div>
                    </div>
                    <div className="h-5 bg-muted rounded w-24 mb-2"></div>
                    <div className="h-8 bg-muted rounded w-full mb-2"></div>
                    <div className="h-3 bg-muted rounded w-32 mt-2"></div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="whale-tracker">
          <Card>
            <CardHeader>
              <CardTitle>Large Transaction Tracker</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="text-left text-gray-400 border-b border-border">
                      <th className="pb-3 pl-4">Asset</th>
                      <th className="pb-3">Amount</th>
                      <th className="pb-3">USD Value</th>
                      <th className="pb-3">Type</th>
                      <th className="pb-3">Time</th>
                      <th className="pb-3 pr-4">Transaction</th>
                    </tr>
                  </thead>
                  <tbody>
                    {whaleTransactions.map((tx) => (
                      <tr key={tx.id} className="border-b border-border hover:bg-primary">
                        <td className="py-4 pl-4">{tx.coin}</td>
                        <td className="py-4 font-mono">{tx.amount}</td>
                        <td className="py-4 font-mono">{tx.usdValue}</td>
                        <td className="py-4">
                          <span className={`px-2 py-1 text-xs rounded-full ${
                            tx.type === 'transfer' ? 'bg-blue-500/20 text-blue-400' : 'bg-purple-500/20 text-purple-400'
                          }`}>
                            {tx.type}
                          </span>
                        </td>
                        <td className="py-4 text-gray-400">{tx.time}</td>
                        <td className="py-4 pr-4">
                          <Button variant="ghost" size="sm" className="text-xs">
                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                              <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>
                              <polyline points="15 3 21 3 21 9"/>
                              <line x1="10" y1="14" x2="21" y2="3"/>
                            </svg>
                            View
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="mt-4 flex justify-center">
                <Button variant="outline" className="text-accent">
                  Load More Transactions
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="defi-stats">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>DeFi Platforms - Total Value Locked</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="text-left text-gray-400 border-b border-border">
                          <th className="pb-3 pl-4">Platform</th>
                          <th className="pb-3">TVL</th>
                          <th className="pb-3">24h Change</th>
                          <th className="pb-3 pr-4">Volume (24h)</th>
                        </tr>
                      </thead>
                      <tbody>
                        {defiPlatforms.map((platform) => (
                          <tr key={platform.id} className="border-b border-border hover:bg-primary">
                            <td className="py-4 pl-4 font-medium">{platform.name}</td>
                            <td className="py-4 font-mono">{platform.tvl}</td>
                            <td className={`py-4 ${platform.change24h.startsWith('+') ? 'text-success' : 'text-danger'}`}>
                              {platform.change24h}
                            </td>
                            <td className="py-4 pr-4 font-mono">{platform.volume24h}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>DeFi Sector Breakdown</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">DEXes</span>
                      <span className="text-sm font-mono">$14.82B</span>
                    </div>
                    <div className="w-full bg-primary rounded-full h-2.5">
                      <div className="bg-blue-500 h-2.5 rounded-full" style={{ width: '38%' }}></div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">Lending</span>
                      <span className="text-sm font-mono">$10.45B</span>
                    </div>
                    <div className="w-full bg-primary rounded-full h-2.5">
                      <div className="bg-green-500 h-2.5 rounded-full" style={{ width: '26%' }}></div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">Yield</span>
                      <span className="text-sm font-mono">$6.21B</span>
                    </div>
                    <div className="w-full bg-primary rounded-full h-2.5">
                      <div className="bg-purple-500 h-2.5 rounded-full" style={{ width: '16%' }}></div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">Assets</span>
                      <span className="text-sm font-mono">$4.53B</span>
                    </div>
                    <div className="w-full bg-primary rounded-full h-2.5">
                      <div className="bg-amber-500 h-2.5 rounded-full" style={{ width: '12%' }}></div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">Others</span>
                      <span className="text-sm font-mono">$3.19B</span>
                    </div>
                    <div className="w-full bg-primary rounded-full h-2.5">
                      <div className="bg-red-500 h-2.5 rounded-full" style={{ width: '8%' }}></div>
                    </div>
                  </div>
                </div>

                <Separator className="my-6" />

                <div className="text-sm text-gray-400">
                  <div className="flex justify-between mb-2">
                    <span>Total Value Locked:</span>
                    <span className="font-mono font-medium text-white">$39.2 Billion</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Last updated:</span>
                    <span>3 minutes ago</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="correlation">
          <Card>
            <CardHeader>
              <CardTitle>Asset Correlation Matrix</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="text-left text-gray-400 border-b border-border">
                      <th className="pb-3 pl-4">Asset Pair</th>
                      <th className="pb-3">Correlation Coefficient</th>
                      <th className="pb-3">Trend</th>
                      <th className="pb-3 pr-4">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {correlationMatrix.map((item) => (
                      <tr key={item.id} className="border-b border-border hover:bg-primary">
                        <td className="py-4 pl-4 font-medium">
                          {item.asset1} / {item.asset2}
                        </td>
                        <td className="py-4 font-mono">{item.correlation}</td>
                        <td className="py-4">
                          <span className={`inline-flex items-center px-2 py-1 text-xs rounded-full ${
                            item.trend === 'increasing' 
                              ? 'bg-success/20 text-success' 
                              : item.trend === 'decreasing'
                                ? 'bg-danger/20 text-danger'
                                : 'bg-amber-500/20 text-amber-500'
                          }`}>
                            {item.trend === 'increasing' && (
                              <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                                <path d="m18 15-6-6-6 6"/>
                              </svg>
                            )}
                            {item.trend === 'decreasing' && (
                              <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                                <path d="m6 9 6 6 6-6"/>
                              </svg>
                            )}
                            {item.trend === 'stable' && (
                              <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                                <path d="M8 12h8"/>
                              </svg>
                            )}
                            {item.trend}
                          </span>
                        </td>
                        <td className="py-4 pr-4">
                          <Button variant="outline" size="sm" className="text-xs">
                            View Analysis
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-primary p-4 rounded-lg">
                  <h3 className="text-md font-medium mb-3">What is Correlation?</h3>
                  <p className="text-sm text-gray-400 mb-2">
                    Correlation coefficient is a statistical measure that expresses the extent to which two assets move in relation to each other.
                  </p>
                  <ul className="text-sm text-gray-400 list-disc pl-5 space-y-1">
                    <li>1.0 means perfect positive correlation</li>
                    <li>-1.0 means perfect negative correlation</li>
                    <li>0 means no correlation</li>
                  </ul>
                </div>

                <div className="bg-primary p-4 rounded-lg">
                  <h3 className="text-md font-medium mb-3">How To Use This Data</h3>
                  <p className="text-sm text-gray-400 mb-2">
                    Asset correlation data can be useful for:
                  </p>
                  <ul className="text-sm text-gray-400 list-disc pl-5 space-y-1">
                    <li>Portfolio diversification</li>
                    <li>Risk management strategies</li>
                    <li>Identifying market patterns</li>
                    <li>Planning hedging strategies</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="ico-calendar">
          <Card>
            <CardHeader>
              <CardTitle>Upcoming ICOs & Airdrops</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="text-left text-gray-400 border-b border-border">
                      <th className="pb-3 pl-4">Project</th>
                      <th className="pb-3">Type</th>
                      <th className="pb-3">Date</th>
                      <th className="pb-3">Website</th>
                      <th className="pb-3 pr-4">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {upcomingEvents.map((event) => (
                      <tr key={event.id} className="border-b border-border hover:bg-primary">
                        <td className="py-4 pl-4 font-medium">{event.name}</td>
                        <td className="py-4">
                          <span className={`px-2 py-1 text-xs rounded-full ${
                            event.type === 'ICO' 
                              ? 'bg-blue-500/20 text-blue-400' 
                              : 'bg-green-500/20 text-green-400'
                          }`}>
                            {event.type}
                          </span>
                        </td>
                        <td className="py-4">{event.date}</td>
                        <td className="py-4 text-accent">{event.website}</td>
                        <td className="py-4 pr-4">
                          <Button variant="outline" size="sm" className="text-xs">
                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                              <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/>
                              <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>
                            </svg>
                            Details
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="mt-6 p-4 bg-primary rounded-lg">
                <h3 className="text-md font-medium mb-2">Want to submit your project?</h3>
                <p className="text-sm text-gray-400 mb-3">
                  If you have an upcoming ICO or airdrop that you'd like to be featured in our calendar, please submit it for review.
                </p>
                <Button className="bg-accent">Submit Project</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </main>
  );
};

export default AnalyticsPage;
