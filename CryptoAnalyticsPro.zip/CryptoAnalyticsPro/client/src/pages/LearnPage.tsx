import { useState } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const LearnPage = () => {
  const [searchTerm, setSearchTerm] = useState('');

  // Articles for different categories
  const articles = {
    basics: [
      {
        id: 1,
        title: 'What is Bitcoin?',
        description: "Learn about the world's first cryptocurrency and how it works.",
        image: 'https://images.unsplash.com/photo-1516245834210-c4c142787335',
        readTime: '5 min read',
        date: 'May 10, 2023'
      },
      {
        id: 2,
        title: 'Blockchain Technology Explained',
        description: 'Understand the technology behind cryptocurrencies and its applications.',
        image: 'https://images.unsplash.com/photo-1639762681057-408e52192e55',
        readTime: '8 min read',
        date: 'May 8, 2023'
      },
      {
        id: 3,
        title: 'How to Create a Crypto Wallet',
        description: 'Step-by-step guide to setting up your first cryptocurrency wallet.',
        image: 'https://images.unsplash.com/photo-1624365169439-535aecff4a04',
        readTime: '7 min read',
        date: 'May 5, 2023'
      },
      {
        id: 4,
        title: 'What are Crypto Exchanges?',
        description: 'Compare different types of exchanges and how to start trading.',
        image: 'https://images.unsplash.com/photo-1605792657660-596af9009e82',
        readTime: '6 min read',
        date: 'May 2, 2023'
      }
    ],
    trading: [
      {
        id: 5,
        title: 'Understanding Crypto Market Orders',
        description: 'Learn about market orders, limit orders, and how to execute trades effectively.',
        image: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3',
        readTime: '10 min read',
        date: 'May 12, 2023'
      },
      {
        id: 6,
        title: 'Technical Analysis for Beginners',
        description: 'Introduction to chart patterns, indicators and technical analysis basics.',
        image: 'https://images.unsplash.com/photo-1642790551116-18a167c18ec4',
        readTime: '12 min read',
        date: 'May 9, 2023'
      },
      {
        id: 7,
        title: 'Risk Management in Crypto Trading',
        description: 'Learn strategies to protect your investments and manage risk.',
        image: 'https://images.unsplash.com/photo-1526304640581-d334cdbbf45e',
        readTime: '8 min read',
        date: 'May 7, 2023'
      },
      {
        id: 8,
        title: 'Psychology of Trading',
        description: 'Understanding the mental aspects of trading and common psychological biases.',
        image: 'https://images.unsplash.com/photo-1579226905180-636b76d96082',
        readTime: '9 min read',
        date: 'May 4, 2023'
      }
    ],
    defi: [
      {
        id: 9,
        title: 'DeFi Explained: What is Decentralized Finance?',
        description: 'Get to know the decentralized financial ecosystem built on blockchain technology.',
        image: 'https://images.unsplash.com/photo-1639322537228-f710d846310a',
        readTime: '11 min read',
        date: 'May 15, 2023'
      },
      {
        id: 10,
        title: 'Yield Farming Strategies',
        description: 'Explore the high-yield investment strategies in the DeFi ecosystem.',
        image: 'https://images.unsplash.com/photo-1620321023374-d1a68fbc720d',
        readTime: '14 min read',
        date: 'May 13, 2023'
      },
      {
        id: 11,
        title: 'What are Smart Contracts?',
        description: 'Understanding the backbone of decentralized applications and DeFi.',
        image: 'https://images.unsplash.com/photo-1622630998477-20aa696ecb05',
        readTime: '7 min read',
        date: 'May 11, 2023'
      },
      {
        id: 12,
        title: 'Understanding Liquidity Pools',
        description: 'How liquidity pools work and their role in decentralized exchanges.',
        image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71',
        readTime: '9 min read',
        date: 'May 3, 2023'
      }
    ],
    security: [
      {
        id: 13,
        title: 'Securing Your Crypto Assets',
        description: 'Best practices for keeping your cryptocurrency investments safe.',
        image: 'https://images.unsplash.com/photo-1563013544-824ae1b704d3',
        readTime: '8 min read',
        date: 'May 14, 2023'
      },
      {
        id: 14,
        title: 'Spotting Crypto Scams',
        description: 'How to identify and avoid common cryptocurrency scams and frauds.',
        image: 'https://images.unsplash.com/photo-1566228015668-4c45dbc4e2f5',
        readTime: '10 min read',
        date: 'May 6, 2023'
      },
      {
        id: 15,
        title: 'Hardware Wallets vs. Software Wallets',
        description: 'Compare the different types of crypto wallets and their security features.',
        image: 'https://images.unsplash.com/photo-1518133835878-5a93cc3f89e5',
        readTime: '7 min read',
        date: 'May 1, 2023'
      },
      {
        id: 16,
        title: 'Private Keys and Seed Phrases',
        description: 'Learn the importance of safeguarding your private keys and recovery phrases.',
        image: 'https://images.unsplash.com/photo-1614064641938-3bbee52942c7',
        readTime: '6 min read',
        date: 'April 28, 2023'
      }
    ]
  };

  // Filter articles based on search term across all categories
  const filterArticles = () => {
    if (!searchTerm) return articles;

    const lowerSearchTerm = searchTerm.toLowerCase();
    const filteredArticles: typeof articles = {
      basics: [],
      trading: [],
      defi: [],
      security: []
    };

    for (const [category, articlesList] of Object.entries(articles)) {
      filteredArticles[category as keyof typeof articles] = articlesList.filter(
        article => 
          article.title.toLowerCase().includes(lowerSearchTerm) || 
          article.description.toLowerCase().includes(lowerSearchTerm)
      );
    }

    return filteredArticles;
  };

  const filteredArticles = filterArticles();

  return (
    <main className="container mx-auto px-4 py-6">
      <div className="mb-8">
        <h1 className="text-2xl font-bold mb-2">Learn Crypto</h1>
        <p className="text-gray-400">
          Educational resources to help you understand cryptocurrency, blockchain technology, and trading strategies.
        </p>
      </div>

      <div className="flex flex-col md:flex-row gap-4 mb-8">
        <div className="flex-1 relative">
          <Input
            type="search"
            placeholder="Search articles..."
            className="bg-secondary border-border"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <svg xmlns="http://www.w3.org/2000/svg" className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="11" cy="11" r="8"/>
            <path d="m21 21-4.3-4.3"/>
          </svg>
        </div>
        <div className="flex-shrink-0">
          <Button className="w-full md:w-auto">Latest Articles</Button>
        </div>
      </div>

      {searchTerm && (
        <div className="mb-8">
          <h2 className="text-lg font-medium mb-4">Search Results for "{searchTerm}"</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {Object.values(filteredArticles).flat().map(article => (
              <Card key={article.id} className="overflow-hidden hover:shadow-lg transition-shadow card">
                <div className="h-40 overflow-hidden">
                  <img 
                    src={article.image} 
                    alt={article.title} 
                    className="w-full h-full object-cover transition-transform hover:scale-105 duration-300"
                    onError={(e) => {
                      e.currentTarget.onerror = null;
                      e.currentTarget.src = 'https://images.unsplash.com/photo-1621761191319-c6fb62004040';
                    }}
                  />
                </div>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg line-clamp-1">{article.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="line-clamp-2 mb-2">{article.description}</CardDescription>
                </CardContent>
                <CardFooter className="pt-0 flex justify-between text-xs text-gray-400">
                  <span>{article.readTime}</span>
                  <span>{article.date}</span>
                </CardFooter>
              </Card>
            ))}
            {Object.values(filteredArticles).flat().length === 0 && (
              <div className="col-span-full text-center py-12">
                <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-12 w-12 text-gray-400 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M12 22c4.5 0 8-2 8-5V7a4 4 0 00-4-4h-8a4 4 0 00-4 4v10c0 3 3.5 5 8 5z" />
                </svg>
                <p className="text-gray-400">No articles found matching your search.</p>
                <Button variant="outline" className="mt-4" onClick={() => setSearchTerm('')}>
                  Clear Search
                </Button>
              </div>
            )}
          </div>
        </div>
      )}

      {!searchTerm && (
        <Tabs defaultValue="basics" className="space-y-8">
          <TabsList>
            <TabsTrigger value="basics">Crypto Basics</TabsTrigger>
            <TabsTrigger value="trading">Trading</TabsTrigger>
            <TabsTrigger value="defi">DeFi</TabsTrigger>
            <TabsTrigger value="security">Security</TabsTrigger>
          </TabsList>

          <TabsContent value="basics">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {articles.basics.map(article => (
                <Card key={article.id} className="overflow-hidden hover:shadow-lg transition-shadow card">
                  <div className="h-40 overflow-hidden">
                    <img 
                      src={article.image} 
                      alt={article.title} 
                      className="w-full h-full object-cover transition-transform hover:scale-105 duration-300"
                      onError={(e) => {
                        e.currentTarget.onerror = null;
                        e.currentTarget.src = 'https://images.unsplash.com/photo-1621761191319-c6fb62004040';
                      }}
                    />
                  </div>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">{article.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="line-clamp-2 mb-2">{article.description}</CardDescription>
                  </CardContent>
                  <CardFooter className="pt-0 flex justify-between text-xs text-gray-400">
                    <span>{article.readTime}</span>
                    <span>{article.date}</span>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="trading">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {articles.trading.map(article => (
                <Card key={article.id} className="overflow-hidden hover:shadow-lg transition-shadow card">
                  <div className="h-40 overflow-hidden">
                    <img 
                      src={article.image} 
                      alt={article.title} 
                      className="w-full h-full object-cover transition-transform hover:scale-105 duration-300"
                      onError={(e) => {
                        e.currentTarget.onerror = null;
                        e.currentTarget.src = 'https://images.unsplash.com/photo-1621761191319-c6fb62004040';
                      }}
                    />
                  </div>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">{article.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="line-clamp-2 mb-2">{article.description}</CardDescription>
                  </CardContent>
                  <CardFooter className="pt-0 flex justify-between text-xs text-gray-400">
                    <span>{article.readTime}</span>
                    <span>{article.date}</span>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="defi">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {articles.defi.map(article => (
                <Card key={article.id} className="overflow-hidden hover:shadow-lg transition-shadow card">
                  <div className="h-40 overflow-hidden">
                    <img 
                      src={article.image} 
                      alt={article.title} 
                      className="w-full h-full object-cover transition-transform hover:scale-105 duration-300"
                      onError={(e) => {
                        e.currentTarget.onerror = null;
                        e.currentTarget.src = 'https://images.unsplash.com/photo-1621761191319-c6fb62004040';
                      }}
                    />
                  </div>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">{article.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="line-clamp-2 mb-2">{article.description}</CardDescription>
                  </CardContent>
                  <CardFooter className="pt-0 flex justify-between text-xs text-gray-400">
                    <span>{article.readTime}</span>
                    <span>{article.date}</span>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="security">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {articles.security.map(article => (
                <Card key={article.id} className="overflow-hidden hover:shadow-lg transition-shadow card">
                  <div className="h-40 overflow-hidden">
                    <img 
                      src={article.image} 
                      alt={article.title} 
                      className="w-full h-full object-cover transition-transform hover:scale-105 duration-300"
                      onError={(e) => {
                        e.currentTarget.onerror = null;
                        e.currentTarget.src = 'https://images.unsplash.com/photo-1621761191319-c6fb62004040';
                      }}
                    />
                  </div>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">{article.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="line-clamp-2 mb-2">{article.description}</CardDescription>
                  </CardContent>
                  <CardFooter className="pt-0 flex justify-between text-xs text-gray-400">
                    <span>{article.readTime}</span>
                    <span>{article.date}</span>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      )}

      <div className="bg-gradient-to-r from-blue-900 to-accent rounded-lg p-8 text-center mt-12">
        <h2 className="text-2xl font-bold mb-4">Join Our Crypto Learning Community</h2>
        <p className="text-gray-300 mb-6 max-w-lg mx-auto">
          Subscribe to our newsletter to receive weekly educational content, market insights, and crypto guides directly to your inbox.
        </p>
        <div className="flex flex-col sm:flex-row justify-center gap-4 max-w-md mx-auto">
          <Input
            type="email"
            placeholder="Your email address"
            className="bg-white/10 border-white/20 text-white placeholder:text-gray-300"
          />
          <Button className="bg-white text-accent hover:bg-gray-100">
            Subscribe
          </Button>
        </div>
      </div>
    </main>
  );
};

export default LearnPage;
