#!/bin/bash
# Build script for Vercel deployment

# Set production environment
export NODE_ENV=production

# Build the client
echo "Building client app..."
npm run build

# Make sure directories exist
mkdir -p api
mkdir -p dist

# Copy files to their correct places if needed
if [ ! -f "api/index.js" ]; then
  echo "Copying API handler..."
  cp server/index.ts api/index.js
fi

echo "Build completed successfully!"