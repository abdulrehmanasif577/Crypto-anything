import { pgTable, text, serial, integer, boolean, timestamp, real, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Crypto coins table
export const coins = pgTable("coins", {
  id: serial("id").primaryKey(),
  coinId: text("coin_id").notNull().unique(), // CoinGecko ID
  symbol: text("symbol").notNull(),
  name: text("name").notNull(),
  image: text("image"),
  currentPrice: real("current_price"),
  marketCap: real("market_cap"),
  marketCapRank: integer("market_cap_rank"),
  priceChange24h: real("price_change_24h"),
  priceChangePercentage24h: real("price_change_percentage_24h"),
  priceChangePercentage7d: real("price_change_percentage_7d"),
  lastUpdated: timestamp("last_updated").defaultNow(),
  sparklineData: json("sparkline_data").$type<number[]>(),
});

// User favorites
export const userFavorites = pgTable("user_favorites", {
  id: serial("id").primaryKey(),
  ipAddress: text("ip_address").notNull(),
  coinId: text("coin_id").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Trading pairs
export const tradingPairs = pgTable("trading_pairs", {
  id: serial("id").primaryKey(),
  baseSymbol: text("base_symbol").notNull(),
  quoteSymbol: text("quote_symbol").notNull(),
  displayName: text("display_name").notNull(),
  isPopular: boolean("is_popular").default(false),
});

// News articles
export const newsArticles = pgTable("news_articles", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  summary: text("summary").notNull(),
  url: text("url").notNull(),
  imageUrl: text("image_url"),
  source: text("source"),
  category: text("category"),
  publishedAt: timestamp("published_at").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Market Stats
export const marketStats = pgTable("market_stats", {
  id: serial("id").primaryKey(),
  totalMarketCap: real("total_market_cap"),
  totalVolume24h: real("total_volume_24h"),
  btcDominance: real("btc_dominance"),
  ethDominance: real("eth_dominance"),
  totalCryptocurrencies: integer("total_cryptocurrencies"),
  totalExchanges: integer("total_exchanges"),
  lastUpdated: timestamp("last_updated").defaultNow(),
});

// Schemas for inserting data
export const insertCoinSchema = createInsertSchema(coins).omit({ id: true });
export const insertUserFavoriteSchema = createInsertSchema(userFavorites).omit({ id: true, createdAt: true });
export const insertTradingPairSchema = createInsertSchema(tradingPairs).omit({ id: true });
export const insertNewsArticleSchema = createInsertSchema(newsArticles).omit({ id: true, createdAt: true });
export const insertMarketStatsSchema = createInsertSchema(marketStats).omit({ id: true });

// Types for the schemas
export type InsertCoin = z.infer<typeof insertCoinSchema>;
export type InsertUserFavorite = z.infer<typeof insertUserFavoriteSchema>;
export type InsertTradingPair = z.infer<typeof insertTradingPairSchema>;
export type InsertNewsArticle = z.infer<typeof insertNewsArticleSchema>;
export type InsertMarketStats = z.infer<typeof insertMarketStatsSchema>;

export type Coin = typeof coins.$inferSelect;
export type UserFavorite = typeof userFavorites.$inferSelect;
export type TradingPair = typeof tradingPairs.$inferSelect;
export type NewsArticle = typeof newsArticles.$inferSelect;
export type MarketStats = typeof marketStats.$inferSelect;
