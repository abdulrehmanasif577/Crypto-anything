import { Switch, Route } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useEffect, useState } from "react";
import { useLanguage } from "./hooks/use-language";
import Header from "./components/Header";
import MobileMenu from "./components/MobileMenu";
import Footer from "./components/Footer";
import NotFound from "@/pages/not-found";
import HomePage from "./pages/HomePage";
import ChartsPage from "./pages/ChartsPage";
import ToolsPage from "./pages/ToolsPage";
import AnalyticsPage from "./pages/AnalyticsPage";
import LearnPage from "./pages/LearnPage";
import AboutPage from "./pages/AboutPage";

// Back to top button component
function BackToTopButton() {
  const [visible, setVisible] = useState(false);
  
  useEffect(() => {
    const handleScroll = () => {
      setVisible(window.pageYOffset > 300);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };
  
  return (
    <button 
      onClick={scrollToTop}
      className={`fixed bottom-6 right-6 bg-accent hover:bg-accent/90 text-white rounded-full p-3 shadow-lg transition-opacity duration-300 ${
        visible ? 'opacity-100 visible' : 'opacity-0 invisible'
      }`}
    >
      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="m18 15-6-6-6 6"/>
      </svg>
    </button>
  );
}

// Main App component
function App() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { currentLanguage } = useLanguage();
  
  useEffect(() => {
    // Set document direction based on language
    document.documentElement.dir = currentLanguage === 'ar' ? 'rtl' : 'ltr';
    // Log successful initialization
    console.log('App initialized with language:', currentLanguage);
  }, [currentLanguage]);
  
  return (
    <TooltipProvider>
      <div className="min-h-screen bg-primary text-foreground">
        <Header onMenuToggle={() => setIsMobileMenuOpen(true)} />
        <MobileMenu isOpen={isMobileMenuOpen} onClose={() => setIsMobileMenuOpen(false)} />
        
        <Switch>
          <Route path="/" component={HomePage} />
          <Route path="/charts" component={ChartsPage} />
          <Route path="/tools" component={ToolsPage} />
          <Route path="/analytics" component={AnalyticsPage} />
          <Route path="/learn" component={LearnPage} />
          <Route path="/about" component={AboutPage} />
          <Route component={NotFound} />
        </Switch>
        
        <Footer />
        <BackToTopButton />
        <Toaster />
      </div>
    </TooltipProvider>
  );
}

export default App;
