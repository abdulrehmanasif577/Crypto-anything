import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/hooks/use-language';

const ProfitLossCalculator = () => {
  const { t, isRTL } = useLanguage();
  
  const { data: coins, isLoading } = useQuery({
    queryKey: ['/api/coins/top'],
    staleTime: 300000 // 5 minutes
  });

  const [formData, setFormData] = useState({
    coin: 'bitcoin',
    investmentAmount: 1000,
    entryPrice: 0,
    exitPrice: 0,
    coinQuantity: 0
  });
  
  const [results, setResults] = useState({
    coinsAmount: 0,
    initialValue: 0,
    currentValue: 0,
    profitLoss: 0,
    profitLossPercentage: 0
  });

  // Update entry price when coin changes
  useEffect(() => {
    if (coins && coins.length > 0) {
      const selectedCoin = coins.find((c: any) => c.coinId === formData.coin) || coins[0];
      if (selectedCoin) {
        setFormData(prev => ({
          ...prev,
          entryPrice: selectedCoin.currentPrice,
          exitPrice: selectedCoin.currentPrice * 1.1, // Default 10% higher
          coin: selectedCoin.coinId
        }));
      }
    }
  }, [coins, formData.coin]);

  // Calculate immediately when the form changes
  useEffect(() => {
    calculate();
  }, [formData]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: parseFloat(value) || 0
    }));
  };

  const handleCoinChange = (value: string) => {
    setFormData(prev => ({
      ...prev,
      coin: value
    }));
  };

  const calculate = () => {
    const { investmentAmount, entryPrice, exitPrice } = formData;
    
    if (entryPrice <= 0 || investmentAmount <= 0) return;
    
    const coinsAmount = investmentAmount / entryPrice;
    const initialValue = investmentAmount;
    const currentValue = coinsAmount * exitPrice;
    const profitLoss = currentValue - initialValue;
    const profitLossPercentage = (profitLoss / initialValue) * 100;
    
    setResults({
      coinsAmount,
      initialValue,
      currentValue,
      profitLoss,
      profitLossPercentage
    });
    
    setFormData(prev => ({
      ...prev,
      coinQuantity: coinsAmount
    }));
  };

  return (
    <div>
      <h3 className="text-lg font-bold mb-4">Crypto Profit/Loss Calculator</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div>
            <label className="block text-sm text-gray-400 mb-2">Select Cryptocurrency</label>
            <div className="relative">
              <Select value={formData.coin} onValueChange={handleCoinChange}>
                <SelectTrigger className="w-full bg-primary border border-border">
                  <SelectValue placeholder="Select a cryptocurrency" />
                </SelectTrigger>
                <SelectContent>
                  {isLoading ? (
                    <div className="p-2 text-center">Loading coins...</div>
                  ) : (
                    coins && coins.map((coin: any) => (
                      <SelectItem key={coin.coinId} value={coin.coinId}>
                        <div className="flex items-center">
                          <img 
                            src={coin.image} 
                            alt={coin.name} 
                            className="w-5 h-5 mr-2"
                            onError={(e) => {
                              e.currentTarget.onerror = null;
                              e.currentTarget.src = 'https://assets.coingecko.com/coins/images/1/thumb/bitcoin.png';
                            }}
                          />
                          {coin.name} ({coin.symbol.toUpperCase()})
                        </div>
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div>
            <label className="block text-sm text-gray-400 mb-2">Investment Amount</label>
            <div className="relative">
              <Input
                type="number"
                placeholder="1000"
                name="investmentAmount"
                value={formData.investmentAmount}
                onChange={handleInputChange}
                className="w-full bg-primary border border-border"
              />
              <div className="absolute inset-y-0 right-0 flex items-center px-3 pointer-events-none">
                <span className="text-gray-400">USD</span>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm text-gray-400 mb-2">Entry Price</label>
              <div className="relative">
                <Input
                  type="number"
                  placeholder="Entry price"
                  name="entryPrice"
                  value={formData.entryPrice}
                  onChange={handleInputChange}
                  className="w-full bg-primary border border-border"
                />
                <div className="absolute inset-y-0 right-0 flex items-center px-3 pointer-events-none">
                  <span className="text-gray-400">$</span>
                </div>
              </div>
            </div>
            
            <div>
              <label className="block text-sm text-gray-400 mb-2">Exit Price</label>
              <div className="relative">
                <Input
                  type="number"
                  placeholder="Exit price"
                  name="exitPrice"
                  value={formData.exitPrice}
                  onChange={handleInputChange}
                  className="w-full bg-primary border border-border"
                />
                <div className="absolute inset-y-0 right-0 flex items-center px-3 pointer-events-none">
                  <span className="text-gray-400">$</span>
                </div>
              </div>
            </div>
          </div>
          
          <Button 
            className="w-full bg-accent hover:bg-accent/90 text-white" 
            onClick={calculate}
          >
            Calculate Profit/Loss
          </Button>
        </div>
        
        <div className="bg-primary rounded-lg p-4">
          <h4 className="text-center font-medium mb-4">Results</h4>
          
          <div className="space-y-4">
            <div className="flex justify-between items-center pb-3 border-b border-border">
              <span className="text-gray-400">Coins Purchased</span>
              <span className="font-mono">
                {results.coinsAmount.toFixed(8)} {coins && coins.find((c: any) => c.coinId === formData.coin)?.symbol.toUpperCase()}
              </span>
            </div>
            
            <div className="flex justify-between items-center pb-3 border-b border-border">
              <span className="text-gray-400">Initial Investment</span>
              <span className="font-mono">${results.initialValue.toFixed(2)}</span>
            </div>
            
            <div className="flex justify-between items-center pb-3 border-b border-border">
              <span className="text-gray-400">Current Value</span>
              <span className="font-mono">${results.currentValue.toFixed(2)}</span>
            </div>
            
            <div className="flex justify-between items-center pb-3 border-b border-border">
              <span className="text-gray-400">Profit/Loss ($)</span>
              <span className={`font-mono ${results.profitLoss >= 0 ? 'text-success' : 'text-danger'}`}>
                {results.profitLoss >= 0 ? '+' : ''}{results.profitLoss.toFixed(2)} USD
              </span>
            </div>
            
            <div className="flex justify-between items-center pb-3 border-b border-border">
              <span className="text-gray-400">Profit/Loss (%)</span>
              <span className={`font-mono ${results.profitLossPercentage >= 0 ? 'text-success' : 'text-danger'}`}>
                {results.profitLossPercentage >= 0 ? '+' : ''}{results.profitLossPercentage.toFixed(2)}%
              </span>
            </div>
            
            <div className="pt-2">
              <div className="bg-primary rounded-full h-4 overflow-hidden border border-border">
                <div 
                  className={`h-full ${results.profitLossPercentage >= 0 
                    ? 'bg-gradient-to-r from-accent to-success' 
                    : 'bg-gradient-to-r from-danger to-orange-600'}`} 
                  style={{ 
                    width: `${Math.min(Math.max(Math.abs(results.profitLossPercentage), 1), 100)}%`,
                    transition: 'width 0.5s ease-in-out'
                  }}
                ></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfitLossCalculator;
